import { useEffect, useMemo, useRef, useState } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import * as api from "../../lib/api";
import { addDarkTiles } from "../../shared/mapTiles";
import { Badge, Card, Empty, ErrorBox, Loading, inputCls, statusTone, useLoad } from "../../shared/ui";
import { isValidLat, isValidLng } from "./MapPicker";

// ============================================================================
// صفحة عرض جميع مكاتب الأحزاب على خريطة تفاعلية داكنة:
// فلاتر (حزب / حالة / بحث) + Marker ملوّن حسب الحالة + نافذة معلومات
// ============================================================================

const STATUS_COLORS: Record<string, string> = {
  planned: "#94a3b8",
  open: "#16a34a",
  counting: "#d97706",
  closed: "#64748b",
  report_received: "#2563eb",
};


export default function StationsMapTab() {
  const stations = useLoad(() => api.listStations(null)); // RLS: superadmin يرى الكل
  const parties = useLoad(api.listParties);
  const [partyFilter, setPartyFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [q, setQ] = useState("");

  const filtered = (stations.data ?? []).filter((s) =>
    (!partyFilter || s.party_id === partyFilter) &&
    (!statusFilter || s.status === statusFilter) &&
    (!q || s.name_ar.includes(q) || s.station_number.includes(q) || (s.city ?? "").includes(q))
  );
  const located = filtered.filter((s) => isValidLat(s.lat) && isValidLng(s.lng));
  const unlocated = filtered.filter((s) => !isValidLat(s.lat) || !isValidLng(s.lng));

  const allIds = useMemo(() => (stations.data ?? []).map((s) => s.id), [stations.data]);
  const counts = useLoad(() => api.countAssignmentsByStation(allIds), [allIds]);
  const partyName = (id: string) => parties.data?.find((p) => p.id === id)?.name_ar ?? "—";

  const [mapEl, setMapEl] = useState<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const layerRef = useRef<L.LayerGroup | null>(null);
  const [tileFallback, setTileFallback] = useState(false);

  useEffect(() => {
    if (!mapEl || mapRef.current) return;
    const map = L.map(mapEl).setView([33.8, -7.2], 8);
    addDarkTiles(map, () => setTileFallback(true));
    layerRef.current = L.layerGroup().addTo(map);
    mapRef.current = map;
    const t1 = setTimeout(() => map.invalidateSize(), 100);
    const t2 = setTimeout(() => map.invalidateSize(), 500);
    const onResize = () => map.invalidateSize();
    window.addEventListener("resize", onResize);
    return () => {
      clearTimeout(t1); clearTimeout(t2);
      window.removeEventListener("resize", onResize);
      map.remove(); mapRef.current = null;
    };
  }, [mapEl]);

  useEffect(() => {
    const layer = layerRef.current, map = mapRef.current;
    if (!layer || !map) return;
    layer.clearLayers();
    located.forEach((s) => {
      const c = STATUS_COLORS[s.status] ?? "#94a3b8";
      L.circleMarker([s.lat!, s.lng!], {
        radius: 8, color: "#0f172a", weight: 2, fillColor: c, fillOpacity: 0.95,
      })
        .bindPopup(
          `<b>${s.name_ar}</b><br>` +
          `${s.station_number} — ${s.city ?? ""} ${s.region ?? ""}<br>` +
          `الحزب: ${partyName(s.party_id)}<br>` +
          `الحالة: ${s.status}<br>` +
          `المراقبون: ${counts.data?.[s.id] ?? 0}`
        )
        .addTo(layer);
    });
    if (located.length) {
      map.fitBounds(located.map((s) => [s.lat!, s.lng!] as [number, number]), { padding: [40, 40] });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [located, counts.data]);

  return (
    <div className="space-y-4">
      {stations.error && <ErrorBox message={stations.error} onRetry={stations.reload} />}

      <Card>
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <select className={`${inputCls} max-w-[220px]`} value={partyFilter} onChange={(e) => setPartyFilter(e.target.value)}>
            <option value="">كل الأحزاب</option>
            {(parties.data ?? []).map((p) => <option key={p.id} value={p.id}>{p.name_ar}</option>)}
          </select>
          <select className={`${inputCls} max-w-[180px]`} value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
            <option value="">كل الحالات</option>
            {Object.keys(STATUS_COLORS).map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
          <input className={`${inputCls} max-w-xs`} placeholder="بحث باسم المكتب أو العنوان…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div className="mb-3 flex flex-wrap items-center gap-3 text-xs text-slate-400">
          {Object.entries(STATUS_COLORS).map(([k, c]) => (
            <span key={k} className="flex items-center gap-1">
              <i className="inline-block h-3 w-3 rounded-full" style={{ background: c }} /> {k}
            </span>
          ))}
        </div>

        {/* الخريطة تظهر دائماً — حتى بلا مكاتب — لتسهيل تحديد المواقع */}
        {stations.loading ? <Loading /> : (
          <div className="relative">
            <div ref={setMapEl} className="h-[420px] w-full rounded-xl border border-slate-700 sm:h-[520px]" />
            {located.length === 0 && (
              <div className="pointer-events-none absolute inset-0 flex items-center justify-center p-4">
                <div className="rounded-xl border border-slate-700 bg-slate-950/85 px-4 py-3 text-center text-sm text-slate-300 backdrop-blur">
                  {filtered.length > 0
                    ? "المكاتب الموجودة بلا إحداثيات — حدّد مواقعها من صفحة المكاتب (إضافة/تعديل)"
                    : "لا توجد مكاتب بعد — أضف مكتباً وحدّد موقعه ليظهر هنا"}
                </div>
              </div>
            )}
          </div>
        )}
        {tileFallback && (
          <p className="mt-2 text-xs text-slate-500">تعذّر تحميل خادم البلاطات الأساسي — تم التبديل تلقائياً إلى خادم بديف.</p>
        )}
      </Card>

      {unlocated.length > 0 && (
        <Card>
          <h4 className="mb-2 font-bold text-amber-400">⚠ مكاتب تحتاج إلى تحديد موقع ({unlocated.length})</h4>
          <div className="flex flex-wrap gap-2">
            {unlocated.map((s) => (
              <span key={s.id} className="flex items-center gap-2 rounded-full bg-slate-800 px-3 py-1 text-xs text-slate-300">
                {s.name_ar} — {s.station_number}
                <Badge tone={statusTone(s.status)}>{s.status}</Badge>
              </span>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

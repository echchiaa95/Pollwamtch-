import { useI18n } from "../../lib/i18n";
import * as api from "../../lib/api";
import { Badge, Btn, Card, Empty, Loading, StatCard, useLoad } from "../../shared/ui";

function downloadCSV(filename: string, rows: (string | number)[][]) {
  const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" }));
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

export default function StatsTab({ partyId, tick }: { partyId: string; tick: number }) {
  const { lang } = useI18n();
  const stations = useLoad(() => api.listStations(partyId), [partyId, tick]);
  const assignments = useLoad(() => api.listAssignments(partyId), [partyId, tick]);
  const sessions = useLoad(() => api.listPartySessions(partyId), [partyId, tick]);
  const reports = useLoad(() => api.listReports(partyId), [partyId, tick]);
  const observers = useLoad(() => api.listObservers(partyId), [partyId, tick]);
  const locations = useLoad(() => api.listLatestLocations(partyId), [partyId, tick]);

  if (stations.loading || sessions.loading) return <Loading />;
  const s = stations.data ?? [], r = reports.data ?? [], se = sessions.data ?? [];
  const o = observers.data ?? [], loc = locations.data ?? [];

  const assigned = new Set((assignments.data ?? []).map((a) => a.polling_station_id)).size;
  const coverage = s.length ? Math.round((assigned / s.length) * 100) : 0;
  const reviewedRate = r.length ? Math.round((r.filter((x) => x.status === "reviewed").length / r.length) * 100) : 0;
  const supportVotes = se.reduce((acc, x) => acc + Object.values(x.totals ?? {}).reduce((m, n) => m + n, 0), 0);
  const connected = o.filter((ob) => {
    const p = loc.find((x) => x.observer_id === ob.id);
    return p && Date.now() - new Date(p.recorded_at).getTime() < 5 * 60000;
  }).length;
  const regions = [...s.reduce((m, x) => m.set(x.region ?? "—", (m.get(x.region ?? "—") ?? 0) + 1), new Map<string, number>())];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <StatCard label={lang === "ar" ? "نسبة التغطية" : "Couverture"} value={`${coverage}%`} hint={`${assigned}/${s.length}`} />
        <StatCard label={lang === "ar" ? "مراجعة التقارير" : "Révision"} value={`${reviewedRate}%`} hint={`${r.length}`} tone="violet" />
        <StatCard label={lang === "ar" ? "أصوات مساندة (تقديرية)" : "Voix (estimées)"} value={supportVotes} tone="amber" />
        <StatCard label={lang === "ar" ? "مراقبون متصلون" : "Observateurs connectés"} value={`${connected}/${o.length}`} tone="blue" />
        <StatCard label={lang === "ar" ? "نسبة المشاركة الرسمية" : "Participation officielle"} value="—" hint={lang === "ar" ? "تُنشر رسمياً لاحقاً" : "À publier officiellement"} tone="green" />
      </div>

      <Card>
        <h3 className="mb-2 font-bold">{lang === "ar" ? "توزيع المكاتب حسب الجهات" : "Répartition par région"}</h3>
        {regions.length === 0 ? <Empty label={lang === "ar" ? "لا بيانات" : "Aucune donnée"} /> : (
          <div className="space-y-2">
            {regions.map(([rg, n]) => (
              <div key={rg} className="flex items-center gap-2 text-sm">
                <span className="w-40 truncate">{rg}</span>
                <div className="h-3 flex-1 rounded-full bg-slate-100 dark:bg-slate-800">
                  <div className="h-3 rounded-full bg-brand" style={{ width: `${(n / Math.max(1, s.length)) * 100}%` }} />
                </div>
                <span className="tabular-nums">{n}</span>
              </div>
            ))}
          </div>
        )}
        <div className="mt-3">
          <Badge tone="amber">{lang === "ar" ? "المقارنة التاريخية تُفعَّل عند توفر نتائج رسمية في official_results" : "Historique dès données officielles"}</Badge>
        </div>
      </Card>

      <Card>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h3 className="font-bold">{lang === "ar" ? "تصدير" : "Export"}</h3>
          <Btn variant="ghost" onClick={() =>
            downloadCSV("stations.csv", [
              [lang === "ar" ? "الرقم" : "N°", lang === "ar" ? "الاسم" : "Nom", lang === "ar" ? "المدينة" : "Ville", lang === "ar" ? "الجهة" : "Région", lang === "ar" ? "الحالة" : "Statut"],
              ...s.map((x) => [x.station_number, x.name_ar, x.city ?? "", x.region ?? "", x.status]),
            ])
          }>⬇ {lang === "ar" ? "المكاتب (CSV)" : "Bureaux (CSV)"}</Btn>
        </div>
      </Card>
    </div>
  );
}

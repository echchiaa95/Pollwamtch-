import { type ReactNode, useCallback, useEffect, useState } from "react";
import { useI18n } from "../lib/i18n";

// ============================================================================
// نظام التصميم — الوضع المظلم فقط (لا يوجد أي مسار للوضع الفاتح)
// ============================================================================

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div className={`rounded-2xl border border-slate-800 bg-slate-900 p-4 shadow-sm shadow-black/20 ${className}`}>
      {children}
    </div>
  );
}

const statTones: Record<string, string> = {
  brand: "text-teal-400",
  green: "text-green-400",
  red: "text-red-400",
  amber: "text-amber-400",
  blue: "text-blue-400",
  violet: "text-violet-400",
};

export function StatCard({ label, value, hint, tone = "brand", icon }: {
  label: string; value: ReactNode; hint?: string;
  tone?: "brand" | "green" | "red" | "amber" | "blue" | "violet";
  icon?: ReactNode;
}) {
  return (
    <Card className="transition hover:border-slate-700">
      <div className="flex items-center justify-between gap-2">
        <div className="text-sm text-slate-400">{label}</div>
        {icon && <span className="text-lg opacity-80">{icon}</span>}
      </div>
      <div className={`mt-1 text-3xl font-bold tabular-nums ${statTones[tone]}`}>{value}</div>
      {hint && <div className="mt-1 text-xs text-slate-500">{hint}</div>}
    </Card>
  );
}

export function Btn({ children, onClick, variant = "primary", disabled, className = "", type }: {
  children: ReactNode; onClick?: () => void;
  variant?: "primary" | "ghost" | "danger" | "success" | "warn";
  disabled?: boolean; className?: string; type?: "button" | "submit";
}) {
  const variants: Record<string, string> = {
    primary: "bg-teal-600 text-white hover:bg-teal-500 disabled:bg-slate-700 disabled:text-slate-500",
    ghost: "bg-slate-800 text-slate-200 hover:bg-slate-700 disabled:text-slate-500",
    danger: "bg-red-600 text-white hover:bg-red-500 disabled:bg-slate-700",
    success: "bg-green-600 text-white hover:bg-green-500 disabled:bg-slate-700",
    warn: "bg-amber-500 text-slate-950 hover:bg-amber-400 disabled:bg-slate-700",
  };
  return (
    <button
      type={type ?? "button"}
      onClick={onClick}
      disabled={disabled}
      className={`inline-flex items-center justify-center gap-1.5 rounded-xl px-4 py-2 text-sm font-semibold transition disabled:cursor-not-allowed ${variants[variant]} ${className}`}
    >
      {children}
    </button>
  );
}

export function Badge({ children, tone = "slate" }: { children: ReactNode; tone?: string }) {
  const tones: Record<string, string> = {
    slate: "bg-slate-800 text-slate-300",
    green: "bg-green-900/50 text-green-300 ring-1 ring-green-700/40",
    red: "bg-red-900/50 text-red-300 ring-1 ring-red-700/40",
    amber: "bg-amber-900/50 text-amber-300 ring-1 ring-amber-700/40",
    blue: "bg-blue-900/50 text-blue-300 ring-1 ring-blue-700/40",
    violet: "bg-violet-900/50 text-violet-300 ring-1 ring-violet-700/40",
    teal: "bg-teal-900/50 text-teal-300 ring-1 ring-teal-700/40",
  };
  return <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold ${tones[tone] ?? tones.slate}`}>{children}</span>;
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-medium text-slate-300">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-slate-500">{hint}</span>}
    </label>
  );
}

export const inputCls =
  "w-full rounded-xl border border-slate-700 bg-slate-800/80 px-3 py-2 text-sm text-slate-100 placeholder-slate-500 outline-none transition focus:border-teal-500 focus:ring-2 focus:ring-teal-500/30";

export function TopBar({ title, right }: { title: string; right?: ReactNode }) {
  const { t, toggle } = useI18n();
  return (
    <header className="sticky top-0 z-20 flex items-center justify-between gap-2 border-b border-slate-800 bg-slate-950/85 px-4 py-3 backdrop-blur">
      <h1 className="truncate text-lg font-bold">{title}</h1>
      <div className="flex shrink-0 items-center gap-2">
        {right}
        <Btn variant="ghost" onClick={toggle}>{t("language")}</Btn>
      </div>
    </header>
  );
}

export function statusTone(s: string): string {
  switch (s) {
    case "active": case "open": case "validated": case "reviewed": case "issued": case "connected":
      return "green";
    case "counting": case "submitted": case "pending": case "under_review": case "planned":
      return "amber";
    case "suspended": case "returned": case "flagged": case "failed": case "inactive":
      return "red";
    case "report_received": case "closed":
      return "blue";
    default:
      return "slate";
  }
}

export function timeAgo(iso: string, lang: string): string {
  const mins = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
  if (lang === "fr") {
    if (mins < 1) return "à l'instant";
    if (mins < 60) return `il y a ${mins} min`;
    if (mins < 60 * 24) return `il y a ${Math.round(mins / 60)} h`;
    return `il y a ${Math.round(mins / 1440)} j`;
  }
  if (mins < 1) return "الآن";
  if (mins < 60) return `منذ ${mins} دقيقة`;
  if (mins < 60 * 24) return `منذ ${Math.round(mins / 60)} ساعة`;
  return `منذ ${Math.round(mins / 1440)} يوم`;
}

// ---------- حالات العرض (loading / empty / error) ----------
export function Loading({ label }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-2 py-10 text-sm text-slate-400" role="status" aria-live="polite">
      <span className="h-4 w-4 animate-spin rounded-full border-2 border-teal-500 border-t-transparent" />
      {label ?? "جارٍ التحميل…"}
    </div>
  );
}

/** هيكل تحميل احترافي: صفوف رمادية نابضة */
export function Skeleton({ className = "" }: { className?: string }) {
  return <div className={`pw-skeleton rounded-xl ${className}`} aria-hidden="true" />;
}

export function SkeletonTable({ rows = 4 }: { rows?: number }) {
  return (
    <div className="space-y-2" aria-hidden="true">
      {Array.from({ length: rows }).map((_, i) => (
        <Skeleton key={i} className="h-10 w-full" />
      ))}
    </div>
  );
}

export function Empty({ label, hint }: { label: string; hint?: string }) {
  return (
    <div className="rounded-xl border border-dashed border-slate-700 bg-slate-900/60 px-4 py-10 text-center">
      <div className="mb-1 text-2xl opacity-50">🗺️</div>
      <div className="text-sm text-slate-400">{label}</div>
      {hint && <div className="mt-1 text-xs text-slate-500">{hint}</div>}
    </div>
  );
}

export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="rounded-xl border border-red-900 bg-red-950/60 px-4 py-3 text-sm text-red-300">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <span>⚠ {message}</span>
        {onRetry && (
          <button onClick={onRetry} className="rounded-lg bg-red-600 px-3 py-1 text-xs font-semibold text-white transition hover:bg-red-500">
            إعادة المحاولة
          </button>
        )}
      </div>
    </div>
  );
}

/** هوك تحميل: يستدعي loader ويعيد {data, loading, error, reload} */
export function useLoad<T>(loader: () => Promise<T>, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let alive = true;
    setLoading(true);
    setError(null);
    loader()
      .then((d) => { if (alive) setData(d); })
      .catch((e) => { if (alive) setError(e instanceof Error ? e.message : String(e)); })
      .finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick]);
  return { data, loading, error, reload: () => setTick((n) => n + 1) };
}

// ---------- إشعارات Toast ----------
export interface Toast {
  id: number;
  title: string;
  body?: string;
  tone?: "info" | "success" | "warn" | "error";
}

/** هوك إشعارات مركزي: push + إخفاء تلقائي بعد 5 ثوانٍ */
export function useToasts() {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const dismiss = useCallback((id: number) => setToasts((ts) => ts.filter((x) => x.id !== id)), []);
  const push = useCallback((title: string, opts?: { body?: string; tone?: Toast["tone"] }) => {
    const toast: Toast = { id: Date.now() + Math.random(), title, body: opts?.body, tone: opts?.tone ?? "info" };
    setToasts((ts) => [...ts.slice(-4), toast]);
    setTimeout(() => setToasts((ts) => ts.filter((x) => x.id !== toast.id)), 5000);
  }, []);
  return { toasts, push, dismiss };
}

export function Toasts({ toasts, dismiss }: { toasts: Toast[]; dismiss: (id: number) => void }) {
  if (!toasts.length) return null;
  const tones = {
    info: "border-blue-700 bg-blue-950/90 text-blue-200",
    success: "border-green-700 bg-green-950/90 text-green-200",
    warn: "border-amber-700 bg-amber-950/90 text-amber-200",
    error: "border-red-700 bg-red-950/90 text-red-200",
  };
  return (
    <div className="pointer-events-none fixed bottom-4 end-4 z-[100] flex w-80 max-w-[calc(100vw-2rem)] flex-col gap-2">
      {toasts.map((t) => (
        <div key={t.id} className={`pw-toast pointer-events-auto rounded-xl border p-3 text-sm shadow-lg shadow-black/40 backdrop-blur ${tones[t.tone ?? "info"]}`} role="alert">
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="font-bold">{t.title}</div>
              {t.body && <div className="mt-0.5 text-xs opacity-80">{t.body}</div>}
            </div>
            <button onClick={() => dismiss(t.id)} className="opacity-60 transition hover:opacity-100" aria-label="إغلاق">✕</button>
          </div>
        </div>
      ))}
    </div>
  );
}

// ---------- نافذة منبثقة عامة (Modal) ----------
export function Modal({ open, onClose, title, children, wide }: {
  open: boolean; onClose: () => void; title: string; children: ReactNode; wide?: boolean;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="pw-overlay fixed inset-0 z-[90] flex items-end justify-center bg-black/70 p-0 backdrop-blur-sm sm:items-center sm:p-4"
      onClick={onClose} role="dialog" aria-modal="true" aria-label={title}>
      <div className={`pw-modal max-h-[92vh] w-full overflow-y-auto rounded-t-2xl border border-slate-700 bg-slate-900 shadow-2xl shadow-black/60 sm:rounded-2xl ${wide ? "sm:max-w-3xl" : "sm:max-w-lg"}`}
        onClick={(e) => e.stopPropagation()}>
        <div className="sticky top-0 z-10 flex items-center justify-between gap-2 border-b border-slate-800 bg-slate-900/95 px-4 py-3 backdrop-blur">
          <h3 className="font-bold">{title}</h3>
          <button onClick={onClose} className="rounded-lg p-1 text-slate-400 transition hover:bg-slate-800 hover:text-slate-200" aria-label="إغلاق">✕</button>
        </div>
        <div className="p-4">{children}</div>
      </div>
    </div>
  );
}

// ---------- نافذة تأكيد العمليات الحساسة ----------
export function ConfirmDialog({ open, onClose, onConfirm, title, message, confirmLabel, danger, busy }: {
  open: boolean; onClose: () => void; onConfirm: () => void;
  title: string; message: string; confirmLabel?: string; danger?: boolean; busy?: boolean;
}) {
  if (!open) return null;
  return (
    <div className="pw-overlay fixed inset-0 z-[95] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm" role="alertdialog" aria-modal="true">
      <div className="pw-modal w-full max-w-sm rounded-2xl border border-slate-700 bg-slate-900 p-4 shadow-2xl shadow-black/60">
        <h3 className="font-bold">{title}</h3>
        <p className="mt-2 text-sm text-slate-400">{message}</p>
        <div className="mt-4 flex justify-end gap-2">
          <Btn variant="ghost" onClick={onClose} disabled={busy}>إلغاء</Btn>
          <Btn variant={danger ? "danger" : "primary"} onClick={onConfirm} disabled={busy}>
            {busy ? "جارٍ التنفيذ…" : (confirmLabel ?? "تأكيد")}
          </Btn>
        </div>
      </div>
    </div>
  );
}

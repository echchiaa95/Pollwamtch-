import L from "leaflet";

// ============================================================================
// بلاطات خريطة داكنة مع بديل تلقائي:
// 1) CartoDB dark_all (أساسي — داكن أصلاً)
// 2) عند فشل تحميله (حجب/بطء DNS…) يُبدَّل تلقائياً إلى OpenStreetMap
//    مع فلتر CSS داكن (invert) — تُضاف الصف pw-tile-fallback على الحاوية
// ============================================================================

const CARTO_DARK = "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png";
const OSM = "https://tile.openstreetmap.org/{z}/{x}/{y}.png";
const MAX_TILE_ERRORS = 5;

export function addDarkTiles(map: L.Map, onFallback?: () => void): L.TileLayer {
  const carto = L.tileLayer(CARTO_DARK, {
    attribution: "© OSM © CARTO",
    maxZoom: 19,
    subdomains: "abcd",
  });

  let errors = 0;
  let switched = false;
  carto.on("tileerror", () => {
    if (switched) return;
    errors += 1;
    if (errors >= MAX_TILE_ERRORS) {
      switched = true;
      carto.remove();
      const osm = L.tileLayer(OSM, { attribution: "© OpenStreetMap contributors", maxZoom: 19 });
      osm.addTo(map);
      map.getContainer().classList.add("pw-tile-fallback");
      onFallback?.();
    }
  });

  carto.addTo(map);
  return carto;
}

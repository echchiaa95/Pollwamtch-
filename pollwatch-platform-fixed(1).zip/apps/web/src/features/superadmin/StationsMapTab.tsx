import { useEffect, useMemo, useRef, useState } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import * as api from "../../lib/api";
import { Badge, Card, Empty, ErrorBox, Loading, inputCls, statusTone, useLoad } from "../../shared/ui";
import { isValidLat, isValidLng } from "./MapPicker";

// ============================================================================
// صفحة عرض جميع مكاتب الأحزاب على خريطة تفاعلية داكنة:
// فلاتر (حزب / حالة / بحث) + Marker ملوّن حسب الحالة + نافذة معلومات
// ============================================================================

const STATUS_COLORS: Record<string, string> = {
  planned: "#94a3b8",
  open: "#16a34a",
  counting: "#d97706",
  closed: "#64748b",
  report_received: "#2563eb",
};

const DARK_TILES = "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png";

export default function StationsMapTab() {
  const stations = useLoad(() => api.listStations(null)); // RLS: superadmin يرى الكل
  const parties = useLoad(api.listParties);
  const [partyFilter, setPartyFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [q, setQ] = useState("");

  const filtered = (stations.data ?? []).filter((s) =>
    (!partyFilter || s.party_id === partyFilter) &&
    (!statusFilter || s.status === statusFilter) &&
    (!q || s.name_ar.includes(q) || s.station_number.includes(q) || (s.city ?? "").includes(q))
  );
  const located = filtered.filter((s) => isValidLat(s.lat) && isValidLng(s.lng));
  const unlocated = filtered.filter((s) => !isValidLat(s.lat) || !isValidLng(s.lng));

  const allIds = useMemo(() => (stations.data ?? []).map((s) => s.id), [stations.data]);
  const counts = useLoad(() => api.countAssignmentsByStation(allIds), [allIds]);
  const partyName = (id: string) => parties.data?.find((p) => p.id === id)?.name_ar ?? "—";

  const ref = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const layerRef = useRef<L.LayerGroup | null>(null);

  useEffect(() => {
    if (!ref.current || mapRef.current) return;
    const map = L.map(ref.current).setView([33.8, -7.2], 8);
    L.tileLayer(DARK_TILES, { attribution: "© OSM © CARTO", maxZoom: 19 }).addTo(map);
    layerRef.current = L.layerGroup().addTo(map);
    mapRef.current = map;
    setTimeout(() => map.invalidateSize(), 100);
    return () => { map.remove(); mapRef.current = null; };
  }, []);

  useEffect(() => {
    const layer = layerRef.current, map = mapRef.current;
    if (!layer || !map) return;
    layer.clearLayers();
    located.forEach((s) => {
      const c = STATUS_COLORS[s.status] ?? "#94a3b8";
      L.circleMarker([s.lat!, s.lng!], {
        radius: 8, color: "#0f172a", weight: 2, fillColor: c, fillOpacity: 0.95,
      })
        .bindPopup(
          `<b>${s.name_ar}</b><br>` +
          `${s.station_number} — ${s.city ?? ""} ${s.region ?? ""}<br>` +
          `الحزب: ${partyName(s.party_id)}<br>` +
          `الحالة: ${s.status}<br>` +
          `المراقبون: ${counts.data?.[s.id] ?? 0}`
        )
        .addTo(layer);
    });
    if (located.length) {
      map.fitBounds(located.map((s) => [s.lat!, s.lng!] as [number, number]), { padding: [40, 40] });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [located, counts.data]);

  return (
    <div className="space-y-4">
      {stations.error && <ErrorBox message={stations.error} onRetry={stations.reload} />}

      <Card>
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <select className={`${inputCls} max-w-[220px]`} value={partyFilter} onChange={(e) => setPartyFilter(e.target.value)}>
            <option value="">كل الأحزاب</option>
            {(parties.data ?? []).map((p) => <option key={p.id} value={p.id}>{p.name_ar}</option>)}
          </select>
          <select className={`${inputCls} max-w-[180px]`} value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
            <option value="">كل الحالات</option>
            {Object.keys(STATUS_COLORS).map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
          <input className={`${inputCls} max-w-xs`} placeholder="بحث باسم المكتب أو العنوان…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div className="mb-3 flex flex-wrap items-center gap-3 text-xs text-slate-400">
          {Object.entries(STATUS_COLORS).map(([k, c]) => (
            <span key={k} className="flex items-center gap-1">
              <i className="inline-block h-3 w-3 rounded-full" style={{ background: c }} /> {k}
            </span>
          ))}
        </div>

        {stations.loading ? <Loading /> : located.length === 0 ? (
          <Empty label="لا توجد مكاتب على الخريطة بعد"
            hint={filtered.length > 0 ? "المكاتب الموجودة بلا إحداثيات — حدّد مواقعها من صفحة المكاتب" : "أضف مكتباً وحدّد موقعه ليظهر هنا"} />
        ) : (
          <div ref={ref} className="h-[420px] w-full rounded-xl border border-slate-700 sm:h-[520px]" />
        )}
      </Card>

      {unlocated.length > 0 && (
        <Card>
          <h4 className="mb-2 font-bold text-amber-400">⚠ مكاتب تحتاج إلى تحديد موقع ({unlocated.length})</h4>
          <div className="flex flex-wrap gap-2">
            {unlocated.map((s) => (
              <span key={s.id} className="flex items-center gap-2 rounded-full bg-slate-800 px-3 py-1 text-xs text-slate-300">
                {s.name_ar} — {s.station_number}
                <Badge tone={statusTone(s.status)}>{s.status}</Badge>
              </span>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

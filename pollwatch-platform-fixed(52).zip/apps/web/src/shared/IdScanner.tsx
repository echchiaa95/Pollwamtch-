import { useEffect, useRef, useState } from "react";
import { Btn, Modal } from "./ui";

// ============================================================================
// قارئ منطقة MRZ للبطاقة الوطنية المغربية (ICAO 9303 — TD1)
// مسح تلقائي متواصل: التقاط إطارات من الكاميرا كل ~1.4 ثانية + OCR
// مع معالجة مسبقة (تدرج رمادي + تباين مضاعف + تكبير) حتى نجاح القراءة.
// ============================================================================

export interface MrzData {
  idNumber?: string; fullName?: string; dob?: string; expiry?: string;
  sex?: string; nationality?: string; raw: string;
}

const fmtDate = (yyMMdd: string): string | undefined => {
  if (!/^\d{6}$/.test(yyMMdd)) return undefined;
  const yy = +yyMMdd.slice(0, 2);
  const yyyy = yy <= 30 ? 2000 + yy : 1900 + yy;
  return `${yyyy}-${yyMMdd.slice(2, 4)}-${yyMMdd.slice(4, 6)}`;
};

/** تسامح مع أخطاء OCR: تنظيف الأسطر والإبقاء فقط على محارف MRZ الصالحة */
function cleanLines(raw: string): string[] {
  return raw.toUpperCase()
    .split(/[\n\r]+/)
    .map((l) => l.replace(/[^A-Z0-9<]/g, ""))
    .filter((l) => l.length >= 25 && l.length <= 34);
}

/** تحليل MRZ بصيغة ICAO 9303 (TD1: 3 أسطر) — البطاقة المغربية */
export function parseMrz(raw: string): MrzData | null {
  const mrz = cleanLines(raw);
  if (mrz.length < 3) return null;
  const i1 = mrz.findIndex((l) => l.startsWith("ID"));
  const s = i1 >= 0 ? i1 : 0;
  const l1 = (mrz[s] ?? "").padEnd(30, "<");
  const l2 = (mrz[s + 1] ?? "").padEnd(30, "<");
  const l3 = (mrz[s + 2] ?? "").padEnd(30, "<");
  if (!l3.includes("<<")) return null;
  const idRaw = l1.slice(5, 14).replace(/</g, "");
  if (!/^[A-Z0-9]{6,9}$/.test(idRaw)) return null;
  const parts = l3.split("<<");
  const surname = (parts[0] ?? "").replace(/</g, " ").trim();
  const given = parts.slice(1).join(" ").replace(/</g, " ").trim();
  return {
    idNumber: idRaw,
    fullName: [given, surname].filter(Boolean).join(" ") || undefined,
    dob: fmtDate(l2.slice(0, 6)),
    expiry: fmtDate(l2.slice(8, 14)),
    sex: l2.charAt(7) === "M" || l2.charAt(7) === "F" ? l2.charAt(7) : undefined,
    nationality: l2.slice(15, 18).replace(/</g, "") || undefined,
    raw,
  };
}

export function parseIdText(raw: string): MrzData {
  return parseMrz(raw) ?? { idNumber: raw.match(/[A-Z]{1,2}\d{6,8}/)?.[0], raw };
}

// ---------------------------------------------------------------------------
// نافذة مراجعة البيانات قبل التعبئة
// ---------------------------------------------------------------------------
export function MrzReviewModal({ data, onClose, onFill }: {
  data: MrzData | null; onClose: () => void; onFill: (d: MrzData) => void;
}) {
  if (!data) return null;
  const rows: [string, string | undefined][] = [
    ["رقم البطاقة", data.idNumber],
    ["الاسم الكامل", data.fullName],
    ["تاريخ الازدياد", data.dob],
    ["تاريخ الانتهاء", data.expiry],
    ["الجنس", data.sex === "M" ? "ذكر" : data.sex === "F" ? "أنثى" : undefined],
    ["الجنسية", data.nationality],
  ];
  return (
    <Modal open onClose={onClose} title="بيانات البطاقة المقروءة">
      <div className="space-y-2">
        {rows.map(([k, v]) => (
          <div key={k} className="flex items-center justify-between rounded-xl bg-slate-800/60 px-3 py-2 text-sm">
            <span className="text-slate-400">{k}</span>
            <b dir="ltr">{v ?? "—"}</b>
          </div>
        ))}
        <div className="flex justify-end gap-2 pt-2">
          <Btn variant="ghost" onClick={onClose}>إلغاء</Btn>
          <Btn onClick={() => { onFill(data); onClose(); }}>تعبئة النموذج بهذه البيانات</Btn>
        </div>
      </div>
    </Modal>
  );
}

// ---------------------------------------------------------------------------
// نافذة القارئ: كاميرا + مسح تلقائي متواصل حتى النجاح
// ---------------------------------------------------------------------------
type WorkerLike = { recognize: (img: HTMLCanvasElement) => Promise<{ data: { text: string } }>; terminate: () => Promise<void> };

export default function IdScannerModal({ open, onClose, onResult }: {
  open: boolean; onClose: () => void; onResult: (d: MrzData) => void;
}) {
  const [err, setErr] = useState<string | null>(null);
  const [status, setStatus] = useState("تشغيل الكاميرا…");
  const [attempt, setAttempt] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const workerRef = useRef<WorkerLike | null>(null);
  const busyRef = useRef(false);
  const foundRef = useRef(false);

  useEffect(() => {
    if (!open) return;
    let alive = true;
    let timer: ReturnType<typeof setTimeout> | null = null;

    const stopAll = () => {
      if (timer) clearTimeout(timer);
      streamRef.current?.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
      workerRef.current?.terminate().catch(() => {});
      workerRef.current = null;
    };

    (async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
        if (!alive) { stream.getTracks().forEach((t) => t.stop()); return; }
        streamRef.current = stream;
        if (videoRef.current) { videoRef.current.srcObject = stream; await videoRef.current.play().catch(() => {}); }

        setStatus("تحميل محرك القراءة…");
        const { createWorker } = await import("tesseract.js");
        const worker = (await createWorker("eng")) as unknown as WorkerLike;
        if (!alive) { await worker.terminate(); return; }
        workerRef.current = worker;
        setStatus("وجّه الكاميرا نحو الأسطر السفلية (MRZ) — مسح تلقائي…");

        const tick = async () => {
          if (!alive || foundRef.current || busyRef.current) return;
          const v = videoRef.current;
          if (!v || !v.videoWidth) { timer = setTimeout(tick, 800); return; }
          busyRef.current = true;
          setAttempt((a) => a + 1);
          try {
            const canvas = document.createElement("canvas");
            canvas.width = v.videoWidth * 2;
            canvas.height = v.videoHeight * 2;
            const ctx = canvas.getContext("2d")!;
            ctx.filter = "grayscale(1) contrast(1.7)";
            ctx.drawImage(v, 0, 0, canvas.width, canvas.height);
            const { data: { text } } = await worker.recognize(canvas);
            const parsed = parseMrz(text);
            if (parsed?.idNumber) {
              foundRef.current = true;
              setStatus("تمت القراءة ✓");
              onResult(parsed);
              onClose();
              return;
            }
          } catch { /* محاولة لاحقة */ }
          finally { busyRef.current = false; }
          timer = setTimeout(tick, 1400);
        };
        timer = setTimeout(tick, 700);
      } catch (e) {
        setErr(e instanceof Error ? e.message : String(e));
        setStatus("");
      }
    })();

    return () => { alive = false; foundRef.current = false; busyRef.current = false; stopAll(); };
  }, [open]); // eslint-disable-line react-hooks/exhaustive-deps

  const manualRead = async () => {
    const v = videoRef.current;
    if (!v || !v.videoWidth || !workerRef.current) return;
    busyRef.current = true;
    setStatus("قراءة يدوية…");
    try {
      const canvas = document.createElement("canvas");
      canvas.width = v.videoWidth * 2;
      canvas.height = v.videoHeight * 2;
      const ctx = canvas.getContext("2d")!;
      ctx.filter = "grayscale(1) contrast(1.7)";
      ctx.drawImage(v, 0, 0, canvas.width, canvas.height);
      const { data: { text } } = await workerRef.current.recognize(canvas);
      const parsed = parseMrz(text);
      if (parsed?.idNumber) { foundRef.current = true; onResult(parsed); onClose(); return; }
      setErr("تعذّرت القراءة — حسّن الإضاءة، قرّب البطاقة، وتجنّب الظلال");
      setStatus("وجّه الكاميرا نحو الأسطر السفلية (MRZ) — مسح تلقائي…");
    } catch (e) { setErr(String(e)); }
    finally { busyRef.current = false; }
  };

  return (
    <Modal open={open} onClose={onClose} title="قراءة البطاقة الوطنية (MRZ)">
      <p className="mb-3 text-sm text-slate-400">
        وجّه الكاميرا نحو <b>الأسطر الثلاثة السفلية</b> من البطاقة — القراءة تلقائية وتتوقف عند النجاح.
      </p>
      {err && <p className="mb-2 text-sm text-red-400">{err}</p>}
      {status && <p className="mb-2 flex items-center gap-2 text-xs text-teal-300">
        <span className="h-3 w-3 animate-spin rounded-full border-2 border-teal-400 border-t-transparent" />
        {status}{attempt > 0 ? ` — محاولة ${attempt}` : ""}
      </p>}
      <video ref={videoRef} className="mb-3 w-full rounded-xl border border-slate-700" playsInline muted />
      <div className="flex gap-2">
        <Btn variant="ghost" onClick={manualRead}>📸 قراءة الآن</Btn>
        <Btn variant="ghost" onClick={onClose}>إلغاء</Btn>
      </div>
    </Modal>
  );
}

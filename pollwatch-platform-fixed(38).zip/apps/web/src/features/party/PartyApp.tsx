import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import L from "leaflet";
import { useI18n } from "../../lib/i18n";
import * as api from "../../lib/api";
import { subscribeParty } from "../../lib/remote";
import { addMapTiles } from "../../shared/mapTiles";
import { Badge, Btn, Card, ConfirmDialog, Empty, ErrorBox, Field, Loading, Modal, StatCard, TopBar, Toasts, inputCls, statusTone, timeAgo, useLoad, type Toast } from "../../shared/ui";
import StatsTab from "./StatsTab";

type Tab = "dashboard" | "map" | "observers" | "assistants" | "reports" | "stats";

// حالة المكتب على الخريطة
function markerColor(station: api.StationRow, lastMin: number | null, hasReport: boolean, phase: string | null): string {
  if (hasReport) return "#2563eb";                       // أزرق: تقرير مستلم
  if (phase === "counting" || phase === "done") return "#7c3aed"; // بنفسجي: فرز جارٍ/منتهٍ
  if (lastMin === null) return "#dc2626";                // أحمر: غير متصل
  if (lastMin <= 5) return "#16a34a";                    // أخضر: متصل
  if (lastMin <= 30) return "#d97706";                   // أصفر: تحديث قديم
  return "#dc2626";
}

export default function PartyApp({ partyId, logout }: { partyId: string; logout: ReactNode }) {
  const { t, lang } = useI18n();
  const [tab, setTab] = useState<Tab>("dashboard");
  const party = useLoad(() => api.getParty(partyId), [partyId]);
  const [tick, setTick] = useState(0); // نبضة Realtime: كل حدث → إعادة تحميل

  // Realtime فعلي: اشتراك في reports/count_sessions/observer_locations
  // مع إلغاء الاشتراك عند مغادرة الصفحة (unmount).
  useEffect(() => {
    const unsubscribe = subscribeParty(partyId, () => setTick((n) => n + 1));
    return () => unsubscribe();
  }, [partyId]);

  // إشعار فوري عند وصول تقرير جديد (يقرأ من بيانات محمّلة)
  const [toasts, setToasts] = useState<Toast[]>([]);
  const prevReports = useRef<number | null>(null);
  const reportsCount = useLoad(() => api.listReports(partyId).then((r) => r.length), [partyId, tick]);
  useEffect(() => {
    if (prevReports.current !== null && reportsCount.data !== null && reportsCount.data > prevReports.current) {
      const toast: Toast = { id: Date.now(), title: lang === "ar" ? "تقرير ميداني جديد (Realtime)" : "Nouveau rapport (Realtime)", tone: "info" };
      setToasts((ts) => [...ts, toast]);
      setTimeout(() => setToasts((ts) => ts.filter((x) => x.id !== toast.id)), 6000);
    }
    prevReports.current = reportsCount.data ?? prevReports.current;
  }, [reportsCount.data, lang]);

  const notify = (title: string, tone: Toast["tone"] = "info") => {
    const toast: Toast = { id: Date.now() + Math.random(), title, tone };
    setToasts((ts) => [...ts, toast]);
    setTimeout(() => setToasts((ts) => ts.filter((x) => x.id !== toast.id)), 6000);
  };

  const tabs: { key: Tab; label: string }[] = [
    { key: "dashboard", label: t("dashboard") },
    { key: "map", label: t("map") },
    { key: "observers", label: t("observers") },
    { key: "assistants", label: t("assistants") },
    { key: "reports", label: t("reports") },
    { key: "stats", label: t("stats") },
  ];

  return (
    <div className="min-h-screen">
      <TopBar
        logo={party.data?.logo_path}
        title={party.data ? `${party.data.name_ar} — ${t("dashboard")}` : t("dashboard")}
        right={<><Badge tone="green">● Live</Badge>{logout}</>}
      />
      <div className="mx-auto max-w-6xl p-4">
        <div className="mb-4 flex flex-wrap gap-2">
          {tabs.map((x) => (
            <button key={x.key} onClick={() => setTab(x.key)}
              className={`rounded-xl px-4 py-2 text-sm font-semibold transition ${tab === x.key ? "text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300"}`}
              style={tab === x.key ? { background: party.data?.colors?.primary ?? "#0f766e" } : undefined}>
              {x.label}
            </button>
          ))}
        </div>
        {party.error && <ErrorBox message={party.error} onRetry={party.reload} />}
        {tab === "dashboard" && <DashboardTab partyId={partyId} tick={tick} />}
        {tab === "map" && <MapTab partyId={partyId} tick={tick} />}
        {tab === "observers" && <ObserversTab partyId={partyId} tick={tick} notify={notify} />}
        {tab === "assistants" && <AssistantsTab partyId={partyId} tick={tick} notify={notify} />}
        {tab === "reports" && <ReportsTab partyId={partyId} tick={tick} />}
        {tab === "stats" && <StatsTab partyId={partyId} tick={tick} />}
      </div>
      <Toasts toasts={toasts} dismiss={(id) => setToasts((ts) => ts.filter((x) => x.id !== id))} />
    </div>
  );
}

// ---------------------------------------------------------------------------
// لوحة المؤشرات
// ---------------------------------------------------------------------------
function DashboardTab({ partyId, tick }: { partyId: string; tick: number }) {
  const { t, lang } = useI18n();
  const stations = useLoad(() => api.listStations(partyId), [partyId, tick]);
  const observers = useLoad(() => api.listObservers(partyId), [partyId, tick]);
  const support = useLoad(() => api.listSupportMetrics(partyId), [partyId, tick]);
  const assignments = useLoad(() => api.listAssignments(partyId), [partyId, tick]);
  const sessions = useLoad(() => api.listPartySessions(partyId), [partyId, tick]);
  const reports = useLoad(() => api.listReports(partyId), [partyId, tick]);
  const locations = useLoad(() => api.listLatestLocations(partyId), [partyId, tick]);
  const assistants = useLoad(() => api.listAssistants(partyId), [partyId, tick]);

  const loading = stations.loading || observers.loading;
  if (loading) return <Loading />;
  const s = stations.data ?? [], a = assignments.data ?? [], o = observers.data ?? [];
  const se = sessions.data ?? [], r = reports.data ?? [], loc = locations.data ?? [];

  const assignedPct = s.length ? Math.round((new Set(a.map((x) => x.polling_station_id)).size / s.length) * 100) : 0;
  const connected = o.filter((ob) => {
    const p = loc.find((x) => x.observer_id === ob.id);
    if (p && Date.now() - new Date(p.recorded_at).getTime() < 5 * 60000) return true;
    // احتياطي: أي نشاط حديث في جلسة المراقب (تصويت/فرز) يعني أنه متصل ويعمل
    const sess = se.find((x) => x.observer_id === ob.id);
    return !!sess && Date.now() - new Date(sess.updated_at).getTime() < 10 * 60000;
  }).length;

  const emergencies = (reports.data ?? []).filter((x) => x.kind === "incident" && x.status !== "reviewed");
  const counting = new Set(se.filter((x) => x.phase === "counting" || x.phase === "done").map((x) => x.polling_station_id)).size;
  // احتساب الأصوات من أحدث جلسة لكل مكتب فقط (تجنب ازدواج/تراكم الجلسات القديمة)
  const latestByStation = new Map<string, api.SessionRow>();
  for (const x of se) {
    const prev = latestByStation.get(x.polling_station_id);
    if (!prev || x.started_at > prev.started_at) latestByStation.set(x.polling_station_id, x);
  }
  const latestSessions = [...latestByStation.values()];
  // ثلاث قراءات من أحدث جلسة لكل مكتب:
  const grandTotal = latestSessions.reduce((acc, x) => acc + Object.values(x.totals ?? {}).reduce((m, n) => m + n, 0), 0); // أ + ب + بيضاء
  const blankVotes = latestSessions.reduce((acc, x) => acc + ((x.totals as Record<string, number> | null)?.["blank"] ?? 0), 0);
  const supportVotes = grandTotal - blankVotes; // القائمة أ + القائمة ب فقط
  const attendanceTotal = latestSessions.reduce((a, x) => a + (x.male_count ?? 0) + (x.female_count ?? 0), 0); // ما تم عدّه قبل الفرز (حضور)
  const pending = se.filter((x) => x.status === "submitted");
  const partyAdmins = true; // المراجعة تُفرض من RLS؛ هذا لإظهار القسم فقط

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <StatCard label={t("total_stations")} value={s.length} hint={`${t("coverage")}: ${assignedPct}%`} />
        <StatCard label={t("observers_count")} value={o.length} hint={`${t("connected")}: ${connected} / ${t("disconnected")}: ${o.length - connected}`} tone="blue" />
        <StatCard label={t("counting_started")} value={counting} tone="amber" />
        <StatCard label={t("reports_received")} value={r.length} hint={`${t("reports_reviewed")}: ${r.filter((x) => x.status === "reviewed").length}`} tone="violet" />
        <StatCard
          label={lang === "ar" ? "مجموع الأصوات (ما قبل الفرز)" : "Total (avant dépouillement)"}
          value={attendanceTotal} tone="blue"
          hint={lang === "ar" ? "ذكور + إناث — ما تم عدّه أثناء الحضور قبل بدء الفرز" : "Hommes + femmes avant le dépouillement"}
        />
        <StatCard
          label={lang === "ar" ? "الأصوات المحصاة" : "Voix dépouillées"}
          value={grandTotal} tone="green"
          hint={lang === "ar" ? `(أ + ب + بيضاء) — منها أصوات بيضاء: ${blankVotes}` : `(A + B + blancs) dont blancs: ${blankVotes}`}
        />
        <StatCard
          label={lang === "ar" ? "الأصوات المساندة" : "Voix de soutien"}
          value={supportVotes} tone="violet"
          hint={lang === "ar" ? "القائمة أ + القائمة ب (مستثناة منها البيضاء)" : "Liste A + Liste B (blancs exclus)"}
        />
        <StatCard label={t("assistants_active")} value={(assistants.data ?? []).filter((x) => x.status === "active").length} />
        <StatCard label={t("coverage")} value={`${assignedPct}%`} tone={assignedPct >= 80 ? "green" : "amber"} />
      </div>

      {emergencies.length > 0 && (
        <Card className="border-red-900 bg-red-950/40">
          <h3 className="mb-2 font-bold text-red-300">🚨 بلاغات طارئة ({emergencies.length})</h3>
          <div className="space-y-2 text-sm text-red-200">
            {emergencies.slice(0, 3).map((x) => {
              const st = s.find((z) => z.id === x.polling_station_id);
              return (
                <div key={x.id}>
                  • {x.body.slice(0, 120)}
                  {st && <div className="mt-0.5 text-xs font-bold text-red-300">📍 المكتب المعني: {st.name_ar} ({st.station_number})</div>}
                </div>
              );
            })}
          </div>
          <p className="mt-2 text-xs text-red-400">راجع تبويب «التقارير» للتفاصيل</p>
        </Card>
      )}

      {partyAdmins && pending.length > 0 && (
        <Card>
          <h3 className="mb-3 font-bold">{lang === "ar" ? "محاضر بانتظار المراجعة" : "PV en attente"}</h3>
          <div className="space-y-2">
            {pending.map((x) => <PendingSessionRow key={x.id} session={x} stations={s} observers={o} onDone={() => { sessions.reload(); }} />)}
          </div>
        </Card>
      )}
      {(stations.error || sessions.error) && <ErrorBox message={(stations.error ?? sessions.error)!} />}
    </div>
  );
}

function PendingSessionRow({ session, stations, observers, onDone }: {
  session: api.SessionRow; stations: api.StationRow[]; observers: api.ObserverRow[]; onDone: () => void;
}) {
  const { lang } = useI18n();
  const st = stations.find((x) => x.id === session.polling_station_id);
  const ob = observers.find((x) => x.id === session.observer_id);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const act = async (status: "validated" | "returned") => {
    setBusy(true); setErr(null);
    try { await api.reviewSession(session.id, status); onDone(); }
    catch (e) { setErr(e instanceof Error ? e.message : String(e)); }
    finally { setBusy(false); }
  };
  return (
    <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-slate-50 px-3 py-2 text-sm dark:bg-slate-800/60">
      <span>{st?.name_ar} — {ob?.full_name} ({Object.values(session.totals ?? {}).reduce((m, n) => m + n, 0)} {lang === "ar" ? "صوت" : "voix"})</span>
      <div className="flex items-center gap-2">
        {err && <span className="text-xs text-red-600">{err}</span>}
        <Btn variant="success" className="!px-3 !py-1 text-xs" disabled={busy} onClick={() => act("validated")}>اعتماد</Btn>
        <Btn variant="warn" className="!px-3 !py-1 text-xs" disabled={busy} onClick={() => act("returned")}>إرجاع</Btn>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// الخريطة + لوحة تفاصيل المكتب
// ---------------------------------------------------------------------------
function MapTab({ partyId, tick }: { partyId: string; tick: number }) {
  const { t, lang } = useI18n();
  const stations = useLoad(() => api.listStations(partyId), [partyId, tick]);
  const observers = useLoad(() => api.listObservers(partyId), [partyId, tick]);
  const assignments = useLoad(() => api.listAssignments(partyId), [partyId, tick]);
  const locations = useLoad(() => api.listLatestLocations(partyId), [partyId, tick]);
  const sessions = useLoad(() => api.listPartySessions(partyId), [partyId, tick]);
  const reports = useLoad(() => api.listReports(partyId), [partyId, tick]);
  const year = useLoad(api.getActiveElectionYear, []);

  const [mapEl, setMapEl] = useState<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const layerRef = useRef<L.LayerGroup | null>(null);
  const [q, setQ] = useState("");
  const [selected, setSelected] = useState<string | null>(null);
  const [zoom, setZoom] = useState(8);
  const [assignMsg, setAssignMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const filtered = (stations.data ?? []).filter((s) =>
    s.station_number.includes(q) || s.name_ar.includes(q) || (s.city ?? "").includes(q) || (s.region ?? "").includes(q)
  );

  const sessionByStation = useMemo(() => {
    const m = new Map<string, api.SessionRow>();
    (sessions.data ?? []).forEach((s) => { if (!m.has(s.polling_station_id)) m.set(s.polling_station_id, s); });
    return m;
  }, [sessions.data]);

  useEffect(() => {
    if (!mapEl || mapRef.current) return;
    const map = L.map(mapEl).setView([33.8, -7.2], 8);
    addMapTiles(map);
    layerRef.current = L.layerGroup().addTo(map);
    map.on("zoomend", () => setZoom(map.getZoom()));
    mapRef.current = map;
    const t1 = setTimeout(() => map.invalidateSize(), 100);
    const t2 = setTimeout(() => map.invalidateSize(), 500);
    const onResize = () => map.invalidateSize();
    window.addEventListener("resize", onResize);
    return () => { clearTimeout(t1); clearTimeout(t2); window.removeEventListener("resize", onResize); map.remove(); mapRef.current = null; };
  }, [mapEl]);

  useEffect(() => {
    const layer = layerRef.current, map = mapRef.current;
    if (!layer || !map) return;
    layer.clearLayers();
    const hasIncident = (stId: string) =>
      (reports.data ?? []).some((r) => r.polling_station_id === stId && r.kind === "incident" && r.status !== "reviewed");

    const addStation = (s: api.StationRow) => {
      if (s.lat == null || s.lng == null) return;
      if (hasIncident(s.id)) {
        // توهج أحمر نابض يدل على بلاغ طارئ غير مراجَع
        L.marker([s.lat, s.lng], {
          icon: L.divIcon({ className: "", html: `<div class="pw-alert-ring"></div>`, iconSize: [46, 46], iconAnchor: [23, 23] }),
          interactive: false, keyboard: false, zIndexOffset: 1000,
        }).addTo(layer);
      }
      const assign = (assignments.data ?? []).find((a) => a.polling_station_id === s.id);
      const obs = assign ? (observers.data ?? []).find((o) => o.id === assign.observer_id) : undefined;
      const ping = obs ? (locations.data ?? []).find((p) => p.observer_id === obs.id) : undefined;
      const lastMin = ping ? (Date.now() - new Date(ping.recorded_at).getTime()) / 60000 : null;
      const sess = sessionByStation.get(s.id);
      const hasReport = (reports.data ?? []).some((r) => r.polling_station_id === s.id && r.status !== "draft");
      const color = markerColor(s, lastMin, hasReport, sess?.phase ?? null);
      const icon = L.divIcon({
        className: "",
        html: `<div style="background:${color};width:18px;height:18px;border-radius:50%;border:3px solid white;box-shadow:0 1px 4px rgba(0,0,0,.4)"></div>`,
        iconSize: [18, 18], iconAnchor: [9, 9],
      });
      L.marker([s.lat, s.lng], { icon })
        .bindPopup(`<b>${s.name_ar}</b><br>${s.station_number} — ${s.city ?? ""}`)
        .on("click", () => setSelected(s.id))
        .addTo(layer);
    };
    const CLUSTER_ZOOM = 11;
    if (filtered.length > 1 && zoom <= CLUSTER_ZOOM) {
      const cell = 60;
      const clusters = new Map<string, { x: number; y: number; items: api.StationRow[] }>();
      filtered.forEach((s) => {
        if (s.lat == null || s.lng == null) return;
        const pt = map.latLngToContainerPoint([s.lat, s.lng]);
        const key = `${Math.floor(pt.x / cell)},${Math.floor(pt.y / cell)}`;
        const c = clusters.get(key);
        if (c) { c.items.push(s); c.x = (c.x * (c.items.length - 1) + pt.x) / c.items.length; c.y = (c.y * (c.items.length - 1) + pt.y) / c.items.length; }
        else clusters.set(key, { x: pt.x, y: pt.y, items: [s] });
      });
      clusters.forEach((c) => {
        if (c.items.length === 1) { addStation(c.items[0]); return; }
        const ll = map.containerPointToLatLng([c.x, c.y]);
        const size = 30 + Math.min(20, c.items.length * 2);
        const clusterAlert = c.items.some((it) => hasIncident(it.id));
        const icon = L.divIcon({
          className: "",
          html: `<div style="width:${size}px;height:${size}px;border-radius:50%;background:rgba(15,118,110,.9);border:3px solid ${clusterAlert ? "#ef4444" : "white"};color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;${clusterAlert ? "box-shadow:0 0 0 6px rgba(239,68,68,.35);" : ""}">${c.items.length}</div>`,
          iconSize: [size, size], iconAnchor: [size / 2, size / 2],
        });
        L.marker(ll, { icon }).on("click", () => map.setView(ll, Math.min(zoom + 2, CLUSTER_ZOOM + 1))).addTo(layer);
      });
    } else {
      filtered.forEach(addStation);
    }
    const pts = filtered.filter((s) => s.lat != null).map((s) => [s.lat!, s.lng!] as [number, number]);
    if (pts.length && !selected) map.fitBounds(pts, { padding: [40, 40] });
  }, [filtered, assignments.data, observers.data, locations.data, sessionByStation, reports.data, zoom, selected]);

  const sel = filtered.find((s) => s.id === selected) ?? null;
  const selAssign = sel ? (assignments.data ?? []).find((a) => a.polling_station_id === sel.id) : undefined;
  const selObserver = selAssign ? (observers.data ?? []).find((o) => o.id === selAssign.observer_id) : undefined;
  const selPing = selObserver ? (locations.data ?? []).find((p) => p.observer_id === selObserver.id) : undefined;
  const selSession = sel ? sessionByStation.get(sel.id) : undefined;

  const doAssign = async (observerId: string) => {
    setAssignMsg(null);
    if (!sel || !year.data) return;
    try {
      if (observerId) await api.assignObserver(partyId, observerId, sel.id, year.data.id);
      else await api.unassignObserver(selObserver!.id, year.data.id);
      setAssignMsg({ ok: true, text: lang === "ar" ? "تم حفظ التعيين في Supabase" : "Affectation enregistrée" });
      assignments.reload();
    } catch (e) { setAssignMsg({ ok: false, text: e instanceof Error ? e.message : String(e) }); }
  };

  return (
    <div className="space-y-4">
      {stations.error && <ErrorBox message={stations.error} onRetry={stations.reload} />}
      <div className="flex flex-wrap items-center gap-3">
        <input className={`${inputCls} max-w-sm`} placeholder={`${t("search")} (${t("station_number")} / ${t("city")} / ${t("region")})`} value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="flex flex-wrap gap-3 text-xs text-slate-500">
          <span className="flex items-center gap-1"><i className="inline-block h-3 w-3 rounded-full bg-green-600" /> {lang === "ar" ? "متصل" : "Connecté"}</span>
          <span className="flex items-center gap-1"><i className="inline-block h-3 w-3 rounded-full bg-amber-600" /> {lang === "ar" ? "تحديث قديم" : "MAJ ancienne"}</span>
          <span className="flex items-center gap-1"><i className="inline-block h-3 w-3 rounded-full bg-red-600" /> {lang === "ar" ? "غير متصل" : "Hors ligne"}</span>
          <span className="flex items-center gap-1"><i className="inline-block h-3 w-3 rounded-full bg-violet-600" /> {lang === "ar" ? "فرز" : "Dépouillement"}</span>
          <span className="flex items-center gap-1"><i className="inline-block h-3 w-3 rounded-full bg-blue-600" /> {lang === "ar" ? "تقرير" : "Rapport"}</span>
        </div>
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="h-[480px] overflow-hidden p-0 lg:col-span-2">
          {stations.loading ? <Loading /> : <div ref={setMapEl} className="h-full w-full" />}
        </Card>
        <Card>
          {sel ? (
            <StationDetail
              station={sel} observer={selObserver} ping={selPing} session={selSession}
              observers={observers.data ?? []} yearReady={!!year.data}
              onAssign={doAssign} assignMsg={assignMsg} lang={lang}
            />
          ) : (
            <>
              <h3 className="mb-3 font-bold">{t("stations")} ({filtered.length})</h3>
              <div className="max-h-[420px] space-y-2 overflow-y-auto pe-1">
                {filtered.map((s) => (
                  <button key={s.id} onClick={() => setSelected(s.id)}
                    className={`w-full rounded-xl border p-3 text-start text-sm transition ${selected === s.id ? "border-brand bg-brand/5" : "border-slate-200 hover:border-brand dark:border-slate-700"}`}>
                    <div className="flex items-center justify-between">
                      <span className="font-semibold">{s.name_ar}</span>
                      <Badge tone={statusTone(s.status)}>{s.status}</Badge>
                    </div>
                    <div className="mt-1 text-xs text-slate-400">{s.station_number} — {s.city}</div>
                  </button>
                ))}
              </div>
            </>
          )}
        </Card>
      </div>
    </div>
  );
}

function StationDetail({ station, observer, ping, session, observers, yearReady, onAssign, assignMsg, lang }: {
  station: api.StationRow; observer?: api.ObserverRow; ping?: api.LocationRow;
  session?: api.SessionRow; observers: api.ObserverRow[]; yearReady: boolean;
  onAssign: (observerId: string) => void; assignMsg: { ok: boolean; text: string } | null; lang: string;
}) {
  const total = (session?.male_count ?? 0) + (session?.female_count ?? 0);
  return (
    <div className="space-y-3 text-sm">
      <div>
        <div className="flex items-center justify-between">
          <h3 className="font-bold">{station.name_ar}</h3>
          <Badge tone={statusTone(station.status)}>{station.status}</Badge>
        </div>
        <div className="text-xs text-slate-400">{station.station_number}</div>
      </div>
      <dl className="space-y-1.5 rounded-xl bg-slate-50 p-3 text-xs dark:bg-slate-800/60">
        <Row k={lang === "ar" ? "المدينة / الجهة" : "Ville/Région"} v={`${station.city ?? "—"} / ${station.region ?? "—"}`} />
        <Row k={lang === "ar" ? "الإحداثيات" : "Coordonnées"} v={station.lat != null ? `${station.lat}, ${station.lng}` : "—"} dir="ltr" />
        <Row k={lang === "ar" ? "المراقب المعيّن" : "Observateur"} v={observer?.full_name ?? (lang === "ar" ? "بدون تعيين" : "Non affecté")} />
        <Row k={lang === "ar" ? "حالة الاتصال" : "Connexion"}
          v={ping ? (Date.now() - new Date(ping.recorded_at).getTime() < 5 * 60000
            ? (lang === "ar" ? "متصل" : "Connecté")
            : (lang === "ar" ? `غير متصل (آخر ظهور ${timeAgo(ping.recorded_at, lang)})` : "Hors ligne"))
            : (lang === "ar" ? "غير متصل" : "Hors ligne")} />
        <Row k={lang === "ar" ? "آخر موقع" : "Dernière position"} v={ping ? `${ping.lat}, ${ping.lng}` : "—"} dir="ltr" />
        <Row k={lang === "ar" ? "مرحلة التصويت" : "Phase"} v={session?.phase ?? "—"} />
        <Row k={lang === "ar" ? "الذكور / الإناث / المجموع" : "H/F/Total"} v={`${session?.male_count ?? 0} / ${session?.female_count ?? 0} / ${total}`} />
        <Row k={lang === "ar" ? "آخر تحديث" : "Dernière MAJ"} v={session ? timeAgo(session.updated_at, lang) : "—"} />
      </dl>
      <Field label={lang === "ar" ? "تعيين مراقب" : "Affecter un observateur"}>
        <select
          className={inputCls}
          disabled={!yearReady}
          value={observer?.id ?? ""}
          onChange={(e) => onAssign(e.target.value)}
        >
          <option value="">{lang === "ar" ? "— بدون مراقب —" : "— Aucun —"}</option>
          {observers.map((o) => <option key={o.id} value={o.id}>{o.full_name}</option>)}
        </select>
      </Field>
      {!yearReady && <p className="text-xs text-amber-600">{lang === "ar" ? "لا توجد سنة انتخابية نشطة — التعيين معطّل." : "Aucune année électorale active."}</p>}
      {assignMsg && <p className={`text-xs ${assignMsg.ok ? "text-green-600" : "text-red-600"}`}>{assignMsg.ok ? "✓ " : "⚠ "}{assignMsg.text}</p>}
    </div>
  );
}

function Row({ k, v, dir }: { k: string; v: string; dir?: string }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <dt className="text-slate-400">{k}</dt>
      <dd className="font-medium" dir={dir}>{v}</dd>
    </div>
  );
}

// ---------------------------------------------------------------------------
// المراقبون
// ---------------------------------------------------------------------------
// تقليص صورة البطاقة في المتصفح قبل الرفع (canvas → JPEG)
async function compressImage(file: File, maxDim = 1000, quality = 0.75): Promise<Blob> {
  const bmp = await createImageBitmap(file);
  const scale = Math.min(1, maxDim / Math.max(bmp.width, bmp.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(bmp.width * scale);
  canvas.height = Math.round(bmp.height * scale);
  canvas.getContext("2d")!.drawImage(bmp, 0, 0, canvas.width, canvas.height);
  const blob = await new Promise<Blob | null>((r) => canvas.toBlob(r, "image/jpeg", quality));
  if (!blob) throw new Error("تعذّرت معالجة الصورة");
  return blob;
}

function ObserversTab({ partyId, tick, notify }: { partyId: string; tick: number; notify: (title: string, tone?: Toast["tone"]) => void }) {
  const { t, lang } = useI18n();
  const observers = useLoad(() => api.listObservers(partyId), [partyId, tick]);
  const stations = useLoad(() => api.listStations(partyId), [partyId, tick]);
  const assignments = useLoad(() => api.listAssignments(partyId), [partyId, tick]);
  const year = useLoad(api.getActiveElectionYear, []);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [acctFor, setAcctFor] = useState<api.ObserverRow | null>(null);
  const [acctEmail, setAcctEmail] = useState("");
  const [acctPass, setAcctPass] = useState("");

  const rows = (observers.data ?? []).filter((o) => o.full_name.includes(q) || (o.phone ?? "").includes(q));

  const openAccount = async (recordId: string, fullName: string, em: string, pw: string) => {
    const r = await api.createStaffAccount({ party_id: partyId, role: "observer", record_id: recordId, full_name: fullName, email: em, password: pw });
    if (r && r.error) throw new Error(r.error);
  };

  const save = async () => {
    if (!name.trim()) return;
    setBusy(true); setErr(null);
    try {
      const id = await api.createObserver(partyId, name.trim(), phone.trim() || undefined);
      if (email.trim() || password.trim()) {
        await openAccount(id, name.trim(), email.trim(), password.trim());
        notify(lang === "ar" ? "تمت الإضافة وفتح حساب المراقب — يمكنه تسجيل الدخول بالبريد وكلمة السر" : "Observateur créé avec compte", "success");
      } else {
        notify(lang === "ar" ? "تمت إضافة المراقب" : "Observateur ajouté", "success");
      }
      setName(""); setPhone(""); setEmail(""); setPassword("");
      observers.reload();
    } catch (e) { setErr(e instanceof Error ? e.message : String(e)); }
    finally { setBusy(false); }
  };

  const assign = async (observerId: string, stationId: string) => {
    setErr(null);
    if (!year.data) return;
    try {
      if (stationId) await api.assignObserver(partyId, observerId, stationId, year.data.id);
      else await api.unassignObserver(observerId, year.data.id);
      assignments.reload();
    } catch (e) { setErr(e instanceof Error ? e.message : String(e)); }
  };

  return (
    <div className="space-y-4">
      {err && <ErrorBox message={err} />}
      <Card>
        <h3 className="mb-3 font-bold">{t("add_observer")}</h3>
        <div className="grid gap-3 md:grid-cols-5">
          <Field label={t("name")}><input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} /></Field>
          <Field label={lang === "ar" ? "الهاتف" : "Téléphone"}><input className={inputCls} value={phone} onChange={(e) => setPhone(e.target.value)} /></Field>
          <Field label={lang === "ar" ? "البريد (لحساب الدخول)" : "Email (connexion)"}><input type="email" dir="ltr" className={inputCls} value={email} onChange={(e) => setEmail(e.target.value)} placeholder="observer@example.com" /></Field>
          <Field label={lang === "ar" ? "كلمة السر (8+)" : "Mot de passe (8+)"}><input type="password" dir="ltr" className={inputCls} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="8 أحرف على الأقل" /></Field>
          <div className="flex items-end"><Btn disabled={!name.trim() || busy || (email.trim() !== "" && password.trim().length < 8)} onClick={save}>{busy ? "…" : t("save")}</Btn></div>
        </div>
        <p className="mt-2 text-xs text-slate-500">{lang === "ar" ? "اترك البريد وكلمة السر فارغين لإضافة المراقب فقط، أو املأهما لفتح حساب دخول له فورًا." : "Laissez vide pour ajouter sans compte."}</p>
      </Card>
      <Card>
        <div className="mb-3"><input className={`${inputCls} max-w-xs`} placeholder={t("search")} value={q} onChange={(e) => setQ(e.target.value)} /></div>
        {observers.loading ? <Loading /> : rows.length === 0 ? <Empty label={lang === "ar" ? "لا يوجد مراقبون" : "Aucun observateur"} /> : (
          <div className="space-y-2">
            {rows.map((o) => {
              const a = (assignments.data ?? []).find((x) => x.observer_id === o.id);
              return (
                <div key={o.id} className="flex flex-wrap items-center gap-3 rounded-xl border border-slate-700 p-3 text-sm">
                  <div className="flex-1">
                    <div className="font-semibold">{o.full_name}</div>
                    <div className="text-xs text-slate-400">{o.phone}</div>
                  </div>
                  <div className="w-56">
                    <select className={inputCls} value={a?.polling_station_id ?? ""} onChange={(e) => assign(o.id, e.target.value)}>
                      <option value="">{lang === "ar" ? "— تعيين لمكتب —" : "— Affecter —"}</option>
                      {(stations.data ?? []).map((st) => <option key={st.id} value={st.id}>{st.station_number} — {st.name_ar}</option>)}
                    </select>
                  </div>
                  {o.user_id
                    ? <Badge tone="green">{lang === "ar" ? "حساب مفعّل ✓" : "Compte actif ✓"}</Badge>
                    : <Btn variant="ghost" className="!px-3 !py-1 text-xs" onClick={() => { setAcctFor(o); setAcctEmail(""); setAcctPass(""); }}>{lang === "ar" ? "فتح حساب" : "Créer compte"}</Btn>}
                </div>
              );
            })}
          </div>
        )}
      </Card>
      <Modal open={!!acctFor} onClose={() => setAcctFor(null)} title={lang === "ar" ? `فتح حساب دخول: ${acctFor?.full_name ?? ""}` : "Créer un compte"}>
        <div className="space-y-3">
          <Field label={lang === "ar" ? "البريد الإلكتروني للمراقب" : "Email"}>
            <input type="email" dir="ltr" className={inputCls} value={acctEmail} onChange={(e) => setAcctEmail(e.target.value)} placeholder="observer@example.com" />
          </Field>
          <Field label={lang === "ar" ? "كلمة السر (8 أحرف على الأقل)" : "Mot de passe (8+)"}>
            <input type="password" dir="ltr" className={inputCls} value={acctPass} onChange={(e) => setAcctPass(e.target.value)} />
          </Field>
          <div className="flex justify-end gap-2">
            <Btn variant="ghost" onClick={() => setAcctFor(null)}>{t("cancel")}</Btn>
            <Btn disabled={busy || !acctEmail.trim() || acctPass.trim().length < 8} onClick={async () => {
              if (!acctFor) return;
              setBusy(true); setErr(null);
              try {
                await openAccount(acctFor.id, acctFor.full_name, acctEmail.trim(), acctPass.trim());
                notify(lang === "ar" ? "تم فتح حساب المراقب بنجاح" : "Compte créé", "success");
                setAcctFor(null);
                observers.reload();
              } catch (e) { setErr(e instanceof Error ? e.message : String(e)); }
              finally { setBusy(false); }
            }}>{busy ? "…" : (lang === "ar" ? "فتح الحساب" : "Créer")}</Btn>
          </div>
        </div>
      </Modal>
    </div>
  );
}

function AssistantsTab({ partyId, tick, notify }: { partyId: string; tick: number; notify: (title: string, tone?: Toast["tone"]) => void }) {
  const { t, lang } = useI18n();
  const assistants = useLoad(() => api.listAssistants(partyId), [partyId, tick]);
  const [f, setF] = useState({ full_name: "", phone: "", city: "", region: "" });
  const [idCard, setIdCard] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [viewCard, setViewCard] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const rows = (assistants.data ?? []).filter((a) => a.full_name.includes(q) || (a.city ?? "").includes(q));

  const onFile = (file: File | null) => {
    setIdCard(file);
    if (preview) URL.revokeObjectURL(preview);
    setPreview(file ? URL.createObjectURL(file) : null);
  };

  return (
    <div className="space-y-4">
      {err && <ErrorBox message={err} />}
      <Card>
        <h3 className="mb-3 font-bold">{t("add_assistant")}</h3>
        <div className="grid gap-3 md:grid-cols-5">
          <Field label={t("name")}><input className={inputCls} value={f.full_name} onChange={(e) => setF({ ...f, full_name: e.target.value })} /></Field>
          <Field label={lang === "ar" ? "الهاتف" : "Téléphone"}><input className={inputCls} value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></Field>
          <Field label={t("city")}><input className={inputCls} value={f.city} onChange={(e) => setF({ ...f, city: e.target.value })} /></Field>
          <Field label={t("region")}><input className={inputCls} value={f.region} onChange={(e) => setF({ ...f, region: e.target.value })} /></Field>
          <Field label={lang === "ar" ? "صورة البطاقة الوطنية (اختياري)" : "Carte nationale (optionnel)"} hint={lang === "ar" ? "تُقلَّص تلقائياً إلى JPEG قبل الرفع" : "Redimensionnée automatiquement"}>
            <input type="file" accept="image/*" className={inputCls} onChange={(e) => onFile(e.target.files?.[0] ?? null)} />
          </Field>
        </div>
        {preview && (
          <div className="mt-3 flex items-center gap-3">
            <img src={preview} alt="" className="h-20 rounded-lg border border-slate-700 object-cover" />
            <span className="text-xs text-slate-400">{lang === "ar" ? "معاينة — ستُرفع مضغوطة عند الحفظ" : "Aperçu"}</span>
          </div>
        )}
        <div className="mt-3">
          <Btn disabled={!f.full_name.trim() || busy} onClick={async () => {
            setBusy(true); setErr(null);
            try {
              const id = await api.createAssistant(partyId, { ...f, phone: f.phone || undefined, city: f.city || undefined, region: f.region || undefined });
              if (idCard) {
                const blob = await compressImage(idCard);
                const path = `${partyId}/${id}.jpg`;
                await api.uploadIdDocument(path, blob);
                await api.setAssistantIdDocument(id, path);
              }
              notify(lang === "ar" ? (idCard ? "تمت الإضافة ورفع البطاقة بنجاح" : "تمت إضافة المساعد") : "Assistant ajouté", "success");
              setF({ full_name: "", phone: "", city: "", region: "" }); onFile(null);
              assistants.reload();
            } catch (e) { setErr(e instanceof Error ? e.message : String(e)); }
            finally { setBusy(false); }
          }}>{busy ? "…" : t("save")}</Btn>
        </div>
      </Card>
      <Card>
        <div className="mb-3"><input className={`${inputCls} max-w-xs`} placeholder={t("search")} value={q} onChange={(e) => setQ(e.target.value)} /></div>
        {assistants.loading ? <Loading /> : rows.length === 0 ? <Empty label={lang === "ar" ? "لا يوجد مساعدون" : "Aucun assistant"} /> : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="p-2 text-start">{t("name")}</th>
                  <th className="p-2 text-start">{t("city")}</th>
                  <th className="p-2 text-start">{t("region")}</th>
                  <th className="p-2 text-start">{lang === "ar" ? "البطاقة" : "Carte"}</th>
                  <th className="p-2 text-start">{t("status")}</th>
                  <th className="p-2 text-start">{t("actions")}</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((a) => (
                  <tr key={a.id} className="border-b border-slate-800/60">
                    <td className="p-2 font-medium">{a.full_name}<div className="text-xs text-slate-400">{a.phone}</div></td>
                    <td className="p-2">{a.city}</td>
                    <td className="p-2 text-slate-500">{a.region}</td>
                    <td className="p-2">{a.national_id_path ? (
                      <div className="flex items-center gap-1">
                        <Badge tone="green">{lang === "ar" ? "✓ مرفوعة" : "✓"}</Badge>
                        <Btn variant="ghost" className="!px-2 !py-0.5 text-xs" onClick={async () => {
                          try { setViewCard(await api.getIdDocumentUrl(a.national_id_path!)); }
                          catch (e) { alert(e instanceof Error ? e.message : String(e)); }
                        }}>{lang === "ar" ? "عرض" : "Voir"}</Btn>
                      </div>
                    ) : <span className="text-slate-500">—</span>}</td>
                    <td className="p-2"><Badge tone={statusTone(a.status)}>{a.status}</Badge></td>
                    <td className="p-2">
                      <Btn variant="ghost" className="!px-3 !py-1 text-xs" disabled={busy}
                        onClick={async () => {
                          setBusy(true);
                          try { await api.setAssistantStatus(a.id, a.status === "active" ? "inactive" : "active"); assistants.reload(); }
                          catch (e) { setErr(e instanceof Error ? e.message : String(e)); }
                          finally { setBusy(false); }
                        }}>
                        {a.status === "active" ? "تعطيل" : "تفعيل"}
                      </Btn>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
      {viewCard && (
        <Modal open onClose={() => setViewCard(null)} title={lang === "ar" ? "صورة البطاقة الوطنية" : "Carte nationale"}>
          <img src={viewCard} alt="" className="w-full rounded-xl border border-slate-700" />
        </Modal>
      )}
    </div>
  );
}

function ReportsTab({ partyId, tick }: { partyId: string; tick: number }) {
  const { t, lang } = useI18n();
  const reports = useLoad(() => api.listReports(partyId), [partyId, tick]);
  const observers = useLoad(() => api.listObservers(partyId), [partyId, tick]);
  const stations = useLoad(() => api.listStations(partyId), [partyId, tick]);
  const [err, setErr] = useState<string | null>(null);
  const [confirmDel, setConfirmDel] = useState<string | null>(null);
  const nameOf = (id: string | null) => id ? (observers.data ?? []).find((o) => o.id === id)?.full_name ?? "—" : "—";
  const stationOf = (id: string | null) => id ? (stations.data ?? []).find((s) => s.id === id) : undefined;

  return (
    <div className="space-y-4">
      {err && <ErrorBox message={err} />}
      <Card>
        <h3 className="mb-3 font-bold">{t("reports")} ({reports.data?.length ?? "…"})</h3>
        {reports.loading ? <Loading /> : (reports.data ?? []).length === 0 ? <Empty label={lang === "ar" ? "لا توجد تقارير" : "Aucun rapport"} /> : (
          <div className="space-y-2">
            {(reports.data ?? []).map((r) => {
              const st = stationOf(r.polling_station_id);
              return (
                <div key={r.id} className="rounded-xl border border-slate-200 p-3 text-sm dark:border-slate-700">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <span className="font-semibold">{nameOf(r.observer_id)}</span>
                      <span className="mx-2 text-slate-300">·</span>
                      <span className="text-slate-500">{st ? `${st.station_number} — ${st.name_ar}` : "—"}</span>
                      <span className="mx-2 text-slate-300">·</span>
                      <Badge tone="blue">{r.kind}</Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge tone={statusTone(r.status)}>{r.status}</Badge>
                      <Btn variant="danger" className="!px-2.5 !py-1 text-xs" onClick={() => setConfirmDel(r.id)}>🗑 {lang === "ar" ? "حذف" : "Suppr."}</Btn>
                      {r.status === "submitted" && (
                        <>
                          <Btn variant="success" className="!px-3 !py-1 text-xs" onClick={async () => {
                            try { await api.reviewReport(r.id, "reviewed"); reports.reload(); } catch (e) { setErr(e instanceof Error ? e.message : String(e)); }
                          }}>{t("validate")}</Btn>
                          <Btn variant="warn" className="!px-3 !py-1 text-xs" onClick={async () => {
                            try { await api.reviewReport(r.id, "flagged"); reports.reload(); } catch (e) { setErr(e instanceof Error ? e.message : String(e)); }
                          }}>{t("reject")}</Btn>
                        </>
                      )}
                    </div>
                  </div>
                  <p className="mt-2 text-slate-600 dark:text-slate-300">{r.body}</p>
                  <div className="mt-1 text-xs text-slate-400">{timeAgo(r.submitted_at, lang)}</div>
                </div>
              );
            })}
          </div>
        )}
      </Card>
      <ConfirmDialog
        open={!!confirmDel}
        onClose={() => setConfirmDel(null)}
        danger
        title={lang === "ar" ? "حذف التقرير" : "Supprimer le rapport"}
        message={lang === "ar" ? "سيتم حذف هذا التقرير نهائياً. لا يمكن التراجع عن هذا الإجراء." : "Suppression définitive du rapport."}
        confirmLabel={lang === "ar" ? "حذف نهائي" : "Supprimer"}
        onConfirm={async () => {
          const id = confirmDel;
          setConfirmDel(null);
          try { await api.deleteReport(id!); reports.reload(); } catch (e) { setErr(e instanceof Error ? e.message : String(e)); }
        }}
      />
    </div>
  );
}

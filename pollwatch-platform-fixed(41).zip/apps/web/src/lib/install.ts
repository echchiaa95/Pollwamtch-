// ============================================================================
// تثبيت التطبيق (PWA Install Prompt)
// نلتقط حدث beforeinstallprompt ونمنع القائمة التلقائية، ثم نعرض زر تثبيت خاصاً.
// ============================================================================
/* eslint-disable @typescript-eslint/no-explicit-any */

let deferredPrompt: any = null;
const listeners: Array<() => void> = [];

if (typeof window !== "undefined") {
  window.addEventListener("beforeinstallprompt", (e: Event) => {
    e.preventDefault();
    deferredPrompt = e;
    listeners.forEach((l) => l());
  });
  window.addEventListener("appinstalled", () => {
    deferredPrompt = null;
    listeners.forEach((l) => l());
  });
}

export const canInstall = () => deferredPrompt != null;

export const onInstallAvailable = (cb: () => void) => {
  listeners.push(cb);
  return () => {
    const i = listeners.indexOf(cb);
    if (i >= 0) listeners.splice(i, 1);
  };
};

/** يعرض نافذة التثبيت. يعيد true إذا وافق المستخدم. */
export async function promptInstall(): Promise<boolean> {
  if (!deferredPrompt) return false;
  deferredPrompt.prompt();
  const { outcome } = await deferredPrompt.userChoice;
  if (outcome === "accepted") deferredPrompt = null;
  return outcome === "accepted";
}

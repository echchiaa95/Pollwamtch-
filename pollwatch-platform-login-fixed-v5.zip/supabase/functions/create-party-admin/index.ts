import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, content-type" };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const caller = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: authHeader } } });
    const { data: allowed, error: roleError } = await caller.rpc("is_superadmin");
    if (roleError || allowed !== true) return json({ error: "forbidden" }, 403);
    const body = await req.json();
    const name_ar = String(body.name_ar ?? "").trim();
    const slug = String(body.slug ?? "").trim().toLowerCase();
    const email = String(body.email ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");
    if (!name_ar || !slug || !email || password.length < 8) return json({ error: "اسم الحزب وSlug والبريد وكلمة السر (8 أحرف على الأقل) مطلوبة" }, 400);
    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: role, error: roleLookupError } = await admin.from("roles").select("id").eq("key", "party_admin").single();
    if (roleLookupError) return json({ error: roleLookupError.message }, 500);
    const { data: party, error: partyError } = await admin.from("parties").insert({ name_ar, slug, status: "pending" }).select("id").single();
    if (partyError) return json({ error: partyError.message }, 400);
    const { error: domainError } = await admin.from("party_domains").insert({ party_id: party.id, domain: `www.${slug}.ma`, is_primary: true, wildcard: false, verification_token: crypto.randomUUID(), ssl_status: "pending" });
    if (domainError) { await admin.from("parties").delete().eq("id", party.id); return json({ error: domainError.message }, 400); }
    const { data: created, error: userError } = await admin.auth.admin.createUser({ email, password, email_confirm: true, user_metadata: { full_name: name_ar, role: "party_admin", party_id: party.id } });
    if (userError || !created.user) { await admin.from("party_domains").delete().eq("party_id", party.id); await admin.from("parties").delete().eq("id", party.id); return json({ error: userError?.message ?? "تعذر إنشاء المستخدم" }, 400); }
    const { error: memberError } = await admin.from("party_members").insert({ party_id: party.id, user_id: created.user.id, role_id: role.id, full_name: name_ar, status: "active" });
    if (memberError) { await admin.auth.admin.deleteUser(created.user.id); await admin.from("party_domains").delete().eq("party_id", party.id); await admin.from("parties").delete().eq("id", party.id); return json({ error: memberError.message }, 400); }
    return json({ ok: true, party_id: party.id, user_id: created.user.id });
  } catch (e) { return json({ error: e instanceof Error ? e.message : String(e) }, 500); }
});

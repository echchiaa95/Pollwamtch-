// ============================================================================
// عميل Supabase المركزي — الملف الوحيد الذي يحمل إعدادات الاتصال.
// مفتاح publishable مصمم للعرض العام (تفرض RLS الصلاحيات على مستوى الصفوف).
// لا يُستعمل أي import.meta.env أو process.env — يعمل مباشرة على GitHub Pages.
// ============================================================================
import { createClient } from "@supabase/supabase-js";

const SUPABASE_URL = "https://jfrhdhrnpjlrdfsgruzg.supabase.co";

const SUPABASE_PUBLISHABLE_KEY =
  "sb_publishable_laC22Ti4Pt_Jbs89eh_zGA_7GfvkFt_";

export const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    storageKey: "pollwatch-auth",
  },
});

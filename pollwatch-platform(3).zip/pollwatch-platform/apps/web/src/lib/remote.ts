// ============================================================================
// طبقة الربط بالإنتاج — تستورد العميل المركزي نفسه من ./supabase.
// الجداول (supabase/schema.sql) تطابق الأنواع في ./types.ts واحداً بواحد.
//
// بنية party_members الفعلية (schema.sql):
//   role_id uuid NOT NULL references roles(id)  ← لا يوجد عمود "role"
// لذلك fetchUserRole تنفّذ استعلامين صريحين (party_members ثم roles)
// دون افتراض أي علاقة تضمين (embedding) في PostgREST.
// ============================================================================
import { supabase } from "./supabase";

/** حل المستأجر من الدومين عبر Edge Function (تُستدعى عند الإقلاع) */
export async function resolveTenant(host: string) {
  const { data, error } = await supabase.functions.invoke("resolve-tenant", {
    headers: { "x-forwarded-host": host },
  });
  if (error) throw error;
  return data as {
    party_id: string | null;
    party: { name_ar: string; colors: { primary: string } } | null;
  };
}

/**
 * دور المستخدم من party_members + roles — وفق schema الحقيقي:
 * party_members(role_id) → roles(id,key). استعلامان صريحان، لا embedding.
 * تُعيد null إذا لم يوجد عضو نشط بالدور المطلوب.
 */
export async function fetchUserRole(userId: string) {
  // 1) العضو النشط لهذا المستخدم
  const { data: member, error: mErr } = await supabase
    .from("party_members")
    .select("id, party_id, role_id, full_name, status")
    .eq("user_id", userId)
    .eq("status", "active")
    .limit(1)
    .maybeSingle();
  if (mErr) throw mErr;
  if (!member) return null;

  // 2) مفتاح الدور من جدول roles عبر role_id
  const { data: role, error: rErr } = await supabase
    .from("roles")
    .select("key")
    .eq("id", member.role_id as string)
    .maybeSingle();
  if (rErr) throw rErr;
  if (!role) return null;

  return {
    memberId: member.id as string,
    partyId: (member.party_id as string | null) ?? null,
    fullName: member.full_name as string,
    roleKey: role.key as "superadmin" | "party_admin" | "observer" | "assistant",
  };
}

/** observer_id المرتبط بالمستخدم (للواجهة المراقب) */
export async function fetchObserverId(userId: string, partyId: string | null) {
  if (!partyId) return null;
  const { data } = await supabase
    .from("observers")
    .select("id")
    .eq("user_id", userId)
    .eq("party_id", partyId)
    .maybeSingle();
  return (data?.id as string | undefined) ?? null;
}

/** Realtime: اشتراك في تحديثات الحزب */
export function subscribeParty(
  partyId: string,
  onEvent: (table: "reports" | "count_sessions" | "observer_locations", row: unknown) => void
) {
  const channel = supabase
    .channel(`party:${partyId}`)
    .on("postgres_changes", { event: "*", schema: "public", table: "reports", filter: `party_id=eq.${partyId}` },
      (p) => onEvent("reports", p.new))
    .on("postgres_changes", { event: "*", schema: "public", table: "count_sessions", filter: `party_id=eq.${partyId}` },
      (p) => onEvent("count_sessions", p.new))
    .on("postgres_changes", { event: "INSERT", schema: "public", table: "observer_locations", filter: `party_id=eq.${partyId}` },
      (p) => onEvent("observer_locations", p.new))
    .subscribe();
  return () => { supabase.removeChannel(channel); };
}

/** إدخال فرز مضاد للتكرار: client_id يمنع double-submit عند ضعف الاتصال */
export async function insertVoteEntry(sessionId: string, candidateCode: string, clientId: string) {
  const { error } = await supabase.from("vote_entries").insert({
    session_id: sessionId,
    candidate_code: candidateCode,
    action: "add",
    client_id: clientId,
  });
  // 23505 = مفتاح client_id مكرر → نتجاهله بصمت (idempotency)
  if (error && error.code !== "23505") throw error;
}

/** إرسال المحضر عبر Edge Function (تحقق من الجلسة والصلاحيات على الخادم) */
export async function submitCount(sessionId: string) {
  const { data, error } = await supabase.functions.invoke("submit-count", {
    body: { session_id: sessionId },
  });
  if (error) throw error;
  return data as { submitted: boolean };
}

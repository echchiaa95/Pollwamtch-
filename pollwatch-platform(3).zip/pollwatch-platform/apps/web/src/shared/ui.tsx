import { type ReactNode, useEffect, useState } from "react";
import { useI18n } from "../lib/i18n";

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div className={`rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900 ${className}`}>
      {children}
    </div>
  );
}

export function StatCard({ label, value, hint, tone = "brand" }: {
  label: string; value: ReactNode; hint?: string;
  tone?: "brand" | "green" | "red" | "amber" | "blue" | "violet";
}) {
  const tones: Record<string, string> = {
    brand: "text-brand", green: "text-green-600", red: "text-red-600",
    amber: "text-amber-600", blue: "text-blue-600", violet: "text-violet-600",
  };
  return (
    <Card>
      <div className="text-sm text-slate-500 dark:text-slate-400">{label}</div>
      <div className={`mt-1 text-3xl font-bold tabular-nums ${tones[tone]}`}>{value}</div>
      {hint && <div className="mt-1 text-xs text-slate-400">{hint}</div>}
    </Card>
  );
}

export function Btn({ children, onClick, variant = "primary", disabled, className = "", type }: {
  children: ReactNode; onClick?: () => void;
  variant?: "primary" | "ghost" | "danger" | "success" | "warn";
  disabled?: boolean; className?: string; type?: "button" | "submit";
}) {
  const variants: Record<string, string> = {
    primary: "bg-brand text-white hover:bg-brand-dark disabled:bg-slate-300",
    ghost: "bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700",
    danger: "bg-red-600 text-white hover:bg-red-700",
    success: "bg-green-600 text-white hover:bg-green-700",
    warn: "bg-amber-500 text-white hover:bg-amber-600",
  };
  return (
    <button
      type={type ?? "button"}
      onClick={onClick}
      disabled={disabled}
      className={`rounded-xl px-4 py-2 text-sm font-semibold transition disabled:cursor-not-allowed ${variants[variant]} ${className}`}
    >
      {children}
    </button>
  );
}

export function Badge({ children, tone = "slate" }: { children: ReactNode; tone?: string }) {
  const tones: Record<string, string> = {
    slate: "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300",
    green: "bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300",
    red: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300",
    amber: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
    blue: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300",
    violet: "bg-violet-100 text-violet-700 dark:bg-violet-900/40 dark:text-violet-300",
  };
  return <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${tones[tone]}`}>{children}</span>;
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-medium text-slate-600 dark:text-slate-300">{label}</span>
      {children}
    </label>
  );
}

export const inputCls =
  "w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-brand focus:ring-2 focus:ring-brand/30 dark:border-slate-700 dark:bg-slate-900";

export function TopBar({ title, right }: { title: string; right?: ReactNode }) {
  const { t, toggle } = useI18n();
  const [dark, setDark] = useState(() => document.documentElement.classList.contains("dark"));
  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    try { localStorage.setItem("pollwatch-theme", dark ? "dark" : "light"); } catch { /* تفضيل واجهة فقط */ }
  }, [dark]);
  return (
    <header className="sticky top-0 z-20 flex items-center justify-between border-b border-slate-200 bg-white/80 px-4 py-3 backdrop-blur dark:border-slate-800 dark:bg-slate-950/80">
      <h1 className="text-lg font-bold">{title}</h1>
      <div className="flex items-center gap-2">
        {right}
        <Btn variant="ghost" onClick={() => setDark((d) => !d)}>{dark ? "☀" : "☾"} {t("dark_mode")}</Btn>
        <Btn variant="ghost" onClick={toggle}>{t("language")}</Btn>
      </div>
    </header>
  );
}

export function statusTone(s: string): string {
  switch (s) {
    case "active": case "open": case "validated": case "reviewed": case "issued": case "connected":
      return "green";
    case "counting": case "submitted": case "pending": case "under_review":
      return "amber";
    case "suspended": case "returned": case "flagged": case "failed":
      return "red";
    case "report_received": case "closed":
      return "blue";
    default:
      return "slate";
  }
}

export function timeAgo(iso: string, lang: string): string {
  const mins = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
  if (lang === "fr") {
    if (mins < 1) return "à l'instant";
    if (mins < 60) return `il y a ${mins} min`;
    return `il y a ${Math.round(mins / 60)} h`;
  }
  if (mins < 1) return "الآن";
  if (mins < 60) return `منذ ${mins} دقيقة`;
  return `منذ ${Math.round(mins / 60)} ساعة`;
}

// ---------- حالات العرض (loading / empty / error) ----------
export function Loading({ label }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-2 py-10 text-sm text-slate-400">
      <span className="h-4 w-4 animate-spin rounded-full border-2 border-brand border-t-transparent" />
      {label ?? "…"}
    </div>
  );
}

export function Empty({ label }: { label: string }) {
  return <div className="rounded-xl bg-slate-50 px-4 py-8 text-center text-sm text-slate-400 dark:bg-slate-800/60">{label}</div>;
}

export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300">
      <div className="flex items-center justify-between gap-3">
        <span>⚠ {message}</span>
        {onRetry && (
          <button onClick={onRetry} className="rounded-lg bg-red-600 px-3 py-1 text-xs font-semibold text-white hover:bg-red-700">
            إعادة المحاولة
          </button>
        )}
      </div>
    </div>
  );
}

/** هوك تحميل: يستدعي loader ويعيد {data, loading, error, reload} */
export function useLoad<T>(loader: () => Promise<T>, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let alive = true;
    setLoading(true);
    setError(null);
    loader()
      .then((d) => { if (alive) setData(d); })
      .catch((e) => { if (alive) setError(e instanceof Error ? e.message : String(e)); })
      .finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick]);
  return { data, loading, error, reload: () => setTick((n) => n + 1) };
}

// ---------- إشعارات Toast ----------
export interface Toast {
  id: number;
  title: string;
  body?: string;
  tone?: "info" | "success" | "warn";
}

export function Toasts({ toasts, dismiss }: { toasts: Toast[]; dismiss: (id: number) => void }) {
  if (!toasts.length) return null;
  const tones = {
    info: "border-blue-300 bg-blue-50 text-blue-800 dark:bg-blue-950/80 dark:text-blue-200",
    success: "border-green-300 bg-green-50 text-green-800 dark:bg-green-950/80 dark:text-green-200",
    warn: "border-amber-300 bg-amber-50 text-amber-800 dark:bg-amber-950/80 dark:text-amber-200",
  };
  return (
    <div className="fixed bottom-4 end-4 z-50 flex w-80 flex-col gap-2">
      {toasts.map((t) => (
        <div key={t.id} className={`rounded-xl border p-3 text-sm shadow-lg ${tones[t.tone ?? "info"]}`}>
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="font-bold">{t.title}</div>
              {t.body && <div className="mt-0.5 text-xs opacity-80">{t.body}</div>}
            </div>
            <button onClick={() => dismiss(t.id)} className="opacity-60 hover:opacity-100">✕</button>
          </div>
        </div>
      ))}
    </div>
  );
}

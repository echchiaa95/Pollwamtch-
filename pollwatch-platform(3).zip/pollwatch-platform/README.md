# منصة متابعة مكاتب الاقتراع المباشر (PollWatch)

تطبيق ويب متعدد المستأجرين (Multi-Tenant) لإدارة مراقبي الأحزاب السياسية، متابعة مكاتب الاقتراع عبر خريطة تفاعلية مباشرة، استقبال بيانات الفرز والتقارير الميدانية — مع لوحة Superadmin مركزية، ودومين مستقل وهوية بصرية لكل حزب، ودعم RTL (العربية/الفرنسية).

## ما تم تسليمه في هذه المرحلة (المرحلة 0–1: الأساس)

| الملف | المحتوى |
|---|---|
| `docs/architecture.md` | المعمارية الكاملة: Multi-Tenancy، RBAC، تدفقات العمل، الأمان، خطة التنفيذ المُدرَّجة |
| `supabase/schema.sql` | 20 جدولاً كاملاً + PostGIS + سياسات RLS على كل جدول + دوال الأدوار + triggers + Realtime |
| `supabase/seed.sql` | أدوار، صلاحيات، أنواع انتخابات، سنتان، حزب تجريبي بدومين، 3 مكاتب اقتراع بإحداثيات |
| `supabase/functions/` | `resolve-tenant`، `verify-domain` (DNS TXT)، `submit-count`، `request-erasure` (حق النسيان Law 09-08) |
| `supabase/tests/rls_test.sql` | 12 اختبار pgTAP: عزل المستأجرين، idempotency، append-only، منع تصعيد الصلاحيات |
| `apps/web/src/lib/remote.ts` | طبقة الربط بالإنتاج: resolveTenant، subscribeParty (Realtime)، insertVoteEntry المضاد للتكرار |

## نقاط تصميم حاسمة

1. **العزل في قاعدة البيانات نفسه** — كل سياسة RLS تتحقق من `party_id = my_party_id()` أو `is_superadmin()`؛ لا يمكن لأي عميل اختراق العزل حتى لو كان الكود الأمامي معيباً.
2. **ربط الدومين حصري لـ Superadmin** — جدول `party_domains` له سياسات write تسمح بـ superadmin فقط، ورئيس الحزب لا يرى توكن التحقق.
3. **الفرز**: كل ضغطة = `vote_entries` بمفتاح `client_id` idempotent، وtrigger يحدّث `totals` في `count_sessions` (تراجع = revert، لا حذف أبداً → سجل تدقيق كامل).
4. **الموقع**: لا إدراج في `observer_locations` بدون موافقة سارية في `consent_records` (تُفرض من RLS)، وTTL تلقائي `expires_at` + purge مجدول.
5. **الفصل القانوني**: `support_metrics.source_type` ∈ official/entered/estimate/under_review — لا يُخلط التقديري بالرسمي في أي تقرير.
6. **audit_logs و consent_records جدولان append-only** — حتى superadmin لا يستطيع تعديلهما (triggers ترفع exception).
7. **حماية من تصعيد الصلاحيات**: لا يمكن منح دور superadmin من داخل حزب.

## التشغيل محلياً

```bash
# 1) إنشاء مشروع Supabase وتطبيق المخطط + البذور
supabase init
supabase db reset            # يشغّل schema.sql ثم seed.sql

# 2) نشر دالة حل المستأجر
supabase secrets set APP_DOMAIN=app.pollwatch.ma
supabase functions deploy resolve-tenant

# 3) الواجهة (الخطوة التالية)
cd apps/web && pnpm install && pnpm dev
```

## المراحل المتبقية

- **المرحلة 1 (MVP — واجهات):** React + Vite + TS: شاشات Superadmin (أحزاب/دومينات/مستخدمون/مكاتب)، لوحة رئيس الحزب (مؤشرات + خريطة MapLibre + Realtime)، واجهة المراقب (وردية/GPS/إدخال الفرز/PWA offline). اختبارات pgTAP لكل سياسة RLS.
- **المرحلة 2:** المساعدون، الإحصائيات ومقارنة السنوات، التصدير Excel/PDF، الإشعارات.
- **المرحلة 3:** تكامل مصادر رسمية، اختبار اختراق، `docs/compliance.md` (DPIA حسب Law 09-08/CNDP)، إنتاج.

## بنية سريعة للواجهة (apps/web)

```
src/
├── app/            # router + guards (دور → مسارات) + tenant provider (من resolve-tenant)
├── features/
│   ├── superadmin/ # PartiesPage, DomainsPage, UsersPage, StationsPage
│   ├── party/      # DashboardPage, MapPage (MapLibre+supercluster), ObserversPage,
│   │               # AssistantsPage, ReportsPage, StatsPage
│   └── observer/   # SessionPage, GpsButton, CountingPad, ReportForm
└── shared/         # i18n (ar/fr, RTL), supabase client, realtime hook,
                    # offline queue (Dexie), ui kit (Tailwind)
```

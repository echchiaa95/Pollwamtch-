// ============================================================================
// Edge Function: verify-domain
// يتحقق من ملكية الدومين عبر سجل TXT (_pollwatch.<domain>) ثم يفعّله.
// POST { domain_id } — يتطلب صلاحية superadmin.
// ============================================================================
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { verify } from "node:dns/promises";

const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, content-type" };

async function requireSuperadmin(req: Request) {
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } } },
  );
  const { data } = await supabase.rpc("is_superadmin");
  if (!data) throw new Response(JSON.stringify({ error: "forbidden" }), { status: 403, headers: cors });
  return supabase;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const supabase = await requireSuperadmin(req);
    const { domain_id } = await req.json();
    if (!domain_id) return json({ error: "domain_id required" }, 400);

    const { data: domain, error } = await supabase
      .from("party_domains")
      .select("id, domain, verification_token")
      .eq("id", domain_id)
      .single();
    if (error || !domain) return json({ error: "not_found" }, 404);

    // التحقق: TXT record باسم _pollwatch.<domain> قيمته التوكن
    let records: string[] = [];
    try {
      records = (await verify(`_pollwatch.${domain.domain}`, "TXT")) as string[][];
    } catch { /* NXDOMAIN أو لا سجلات */ }

    const flat = records.flat();
    if (!flat.includes(domain.verification_token)) {
      return json({ verified: false, hint: `أضف سجل TXT: _pollwatch.${domain.domain} = ${domain.verification_token}` });
    }

    const { error: upErr } = await supabase
      .from("party_domains")
      .update({ verified_at: new Date().toISOString(), ssl_status: "issued" })
      .eq("id", domain_id);
    if (upErr) return json({ error: upErr.message }, 500);

    await supabase.rpc("log_audit", {
      p_action: "domain.verify", p_entity: "party_domains", p_entity_id: domain_id,
      p_metadata: { domain: domain.domain },
    });
    return json({ verified: true });
  } catch (e) {
    if (e instanceof Response) return e;
    return json({ error: String(e) }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
}

grant execute on function public.has_permission(text) to authenticated;

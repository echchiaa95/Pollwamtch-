drop policy if exists sessions_party_delete on public.count_sessions;
create policy sessions_party_delete on public.count_sessions for delete to authenticated
using (public.can_delete_reports(party_id));

alter table public.observers add column if not exists national_id_number text;
alter table public.observers add column if not exists id_card_front_path text;
alter table public.observers add column if not exists id_card_back_path text;
alter table public.observers add column if not exists profile_photo_path text;
alter table public.assistants add column if not exists national_id_back_path text;

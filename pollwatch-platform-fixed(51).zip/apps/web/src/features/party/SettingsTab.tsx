import { useRef, useState } from "react";
import { useI18n } from "../../lib/i18n";
import * as api from "../../lib/api";
import { Btn, Card, ErrorBox, Field, Modal, inputCls, type Toast } from "../../shared/ui";

type Notify = (title: string, tone?: Toast["tone"]) => void;

/** إعدادات الحزب: نسخ احتياطي (تصدير/استرجاع) + تصفير الحساب */
export default function SettingsTab({ partyId, notify }: { partyId: string; notify: Notify }) {
  const { lang } = useI18n();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);
  const [resetText, setResetText] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const exportBackup = async () => {
    setBusy(true); setErr(null);
    try {
      const [stations, observers, assistants, sessions, reports, assignments] = await Promise.all([
        api.listStations(partyId), api.listObservers(partyId), api.listAssistants(partyId),
        api.listPartySessions(partyId), api.listReports(partyId), api.listAssignments(partyId),
      ]);
      const payload = {
        app: "pollwatch", version: 1, exported_at: new Date().toISOString(), party_id: partyId,
        data: { stations, observers, assistants, sessions, reports, assignments },
      };
      const a = document.createElement("a");
      a.href = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }));
      a.download = `pollwatch-backup-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(a.href);
      notify(lang === "ar" ? "تم تصدير النسخة الاحتياطية" : "Sauvegarde exportée", "success");
    } catch (e) { setErr(e instanceof Error ? e.message : String(e)); }
    finally { setBusy(false); }
  };

  const restoreBackup = async (file: File) => {
    setBusy(true); setErr(null);
    try {
      const payload = JSON.parse(await file.text());
      const d = payload?.data;
      if (!d || payload?.app !== "pollwatch") throw new Error(lang === "ar" ? "ملف النسخة الاحتياطية غير صالح" : "Fichier invalide");
      let added = 0, skipped = 0;

      const stations = await api.listStations(partyId);
      for (const st of d.stations ?? []) {
        if (stations.some((x) => x.station_number === st.station_number && (x.city ?? "") === (st.city ?? ""))) { skipped++; continue; }
        await api.createStation({ party_id: partyId, station_number: st.station_number, name_ar: st.name_ar, city: st.city, region: st.region });
        added++;
      }
      const observers = await api.listObservers(partyId);
      for (const o of d.observers ?? []) {
        if (observers.some((x) => x.full_name === o.full_name)) { skipped++; continue; }
        await api.createObserver(partyId, o.full_name, o.phone ?? undefined);
        added++;
      }
      const assistants = await api.listAssistants(partyId);
      for (const asst of d.assistants ?? []) {
        if (assistants.some((x) => x.full_name === asst.full_name)) { skipped++; continue; }
        await api.createAssistant(partyId, {
          full_name: asst.full_name, phone: asst.phone ?? undefined, city: asst.city ?? undefined, region: asst.region ?? undefined,
          national_id_number: asst.national_id_number ?? undefined,
        });
        added++;
      }
      notify(lang === "ar" ? `اكتمل الاسترجاع: أُضيف ${added} — تُخطّي ${skipped} (الجلسات والتقارير لا تُسترجع)` : `Restauration: ${added} ajoutés, ${skipped} ignorés`, "success");
    } catch (e) { setErr(e instanceof Error ? e.message : String(e)); }
    finally { setBusy(false); if (fileRef.current) fileRef.current.value = ""; }
  };

  const doReset = async () => {
    setBusy(true); setErr(null);
    try {
      await api.deletePartyOperationalData(partyId);
      setConfirmReset(false); setResetText("");
      notify(lang === "ar" ? "تم تصفير بيانات الحساب (التقارير وجلسات الفرز)" : "Données réinitialisées", "success");
    } catch (e) { setErr(e instanceof Error ? e.message : String(e)); }
    finally { setBusy(false); }
  };

  return (
    <div className="space-y-4">
      {err && <ErrorBox message={err} />}

      <Card>
        <h3 className="mb-1 font-bold">{lang === "ar" ? "تصدير النسخة الاحتياطية" : "Exporter la sauvegarde"}</h3>
        <p className="mb-3 text-sm text-slate-500">{lang === "ar" ? "يُنزَّل ملف JSON يضم المكاتب والمراقبين والمساعدين والجلسات والتقارير والتعيينات." : "Télécharge un fichier JSON complet."}</p>
        <Btn onClick={exportBackup} disabled={busy}>⬇ {lang === "ar" ? "تصدير الآن" : "Exporter"}</Btn>
      </Card>

      <Card>
        <h3 className="mb-1 font-bold">{lang === "ar" ? "استرجاع النسخة الاحتياطية" : "Restaurer la sauvegarde"}</h3>
        <p className="mb-3 text-sm text-slate-500">{lang === "ar" ? "اختر ملف JSON سابق — يُضاف ما ينقص فقط دون تكرار (المكاتب/المراقبون/المساعدون). الجلسات والتقارير لا تُسترجع." : "Fusionne sans doublons."}</p>
        <input ref={fileRef} type="file" accept="application/json,.json" className={inputCls} disabled={busy}
          onChange={(e) => { const f = e.target.files?.[0]; if (f) restoreBackup(f); }} />
      </Card>

      <Card className="border-red-900">
        <h3 className="mb-1 font-bold text-red-400">{lang === "ar" ? "تصفير الحساب" : "Réinitialiser le compte"}</h3>
        <p className="mb-3 text-sm text-slate-500">{lang === "ar" ? "يحذف جميع التقارير وجلسات الفرز والأصوات نهائياً. يُبقى المكاتب والمراقبون والمساعدون." : "Supprime rapports et sessions de dépouillement."}</p>
        <Btn variant="danger" disabled={busy} onClick={() => setConfirmReset(true)}>{lang === "ar" ? "تصفير…" : "Réinitialiser…"}</Btn>
      </Card>

      <Modal open={confirmReset} onClose={() => setConfirmReset(false)} title={lang === "ar" ? "تأكيد التصفير" : "Confirmer"}>
        <div className="space-y-3">
          <p className="text-sm text-red-300">{lang === "ar" ? "إجراء نهائي ولا يمكن التراجع. اكتب كلمة «تصفير» للتأكيد:" : "Action irréversible. Tapez «تصفير» :"}</p>
          <Field label="">
            <input className={inputCls} value={resetText} onChange={(e) => setResetText(e.target.value)} placeholder="تصفير" />
          </Field>
          <div className="flex justify-end gap-2">
            <Btn variant="ghost" onClick={() => setConfirmReset(false)}>{lang === "ar" ? "إلغاء" : "Annuler"}</Btn>
            <Btn variant="danger" disabled={busy || resetText.trim() !== "تصفير"} onClick={doReset}>
              {busy ? "جارٍ التصفير…" : (lang === "ar" ? "تصفير نهائي" : "Confirmer")}
            </Btn>
          </div>
        </div>
      </Modal>
    </div>
  );
}

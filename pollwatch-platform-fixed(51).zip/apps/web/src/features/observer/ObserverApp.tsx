import { useEffect, useRef, useState, type ReactNode } from "react";
import { useI18n } from "../../lib/i18n";
import * as api from "../../lib/api";
import { supabase } from "../../lib/supabase";
import type { Session } from "../../lib/types";
import { Badge, Btn, Card, ConfirmDialog, ErrorBox, Field, Loading, Modal, TopBar, Toasts, inputCls, useLoad, type Toast } from "../../shared/ui";

const CANDIDATES: { code: string; ar: string; fr: string }[] = [
  { code: "c1", ar: "القائمة أ", fr: "Liste A" },
  { code: "c2", ar: "القائمة ب", fr: "Liste B" },
  { code: "blank", ar: "أصوات بيضاء", fr: "Bulletins blancs" },
];

export default function ObserverApp({ session, logout }: { session: Session; logout: ReactNode }) {
  const { t, lang } = useI18n();
  const observerId = session.observerId!;
  const partyId = session.partyId!;
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [asstBusy, setAsstBusy] = useState(false);
  const [asstForm, setAsstForm] = useState({ full_name: "", phone: "", city: "", region: "", national_id_number: "" });
  const canManageAssistants = useLoad(async () => {
    try { return await api.myPermission("assistants.manage"); } catch { return false; }
  }, []);

  const notify = (title: string, body: string | undefined, tone: Toast["tone"]) => {
    const toast: Toast = { id: Date.now() + Math.random(), title, body, tone };
    setToasts((ts) => [...ts, toast]);
    setTimeout(() => setToasts((ts) => ts.filter((x) => x.id !== toast.id)), 6000);
  };

  // تعييني الحالي (RLS: المراقب يرى تعيينه فقط)
  const assignments = useLoad(async () => {
    const year = await api.getActiveElectionYear();
    const { data, error } = await supabase
      .from("observer_assignments")
      .select("*")
      .eq("observer_id", observerId)
      .order("assigned_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return { assignment: data as api.AssignmentRow | null, year };
  }, [observerId]);
  const stationId = assignments.data?.assignment?.polling_station_id ?? null;
  const station = useLoad(
    async () => (stationId ? (await api.listStations(partyId)).find((s) => s.id === stationId) ?? null : null),
    [partyId, stationId]
  );
  const mySession = useLoad(() => api.getMySession(observerId), [observerId]);
  const myStationId = assignments.data?.assignment?.polling_station_id ?? "";

  const reloadAll = () => { mySession.reload(); station.reload(); };

  return (
    <div className="min-h-screen pb-8">
      <TopBar title={`${t("observer")} — ${session.memberName}`} right={logout} />
      <div className="mx-auto max-w-md space-y-4 p-4">
        {assignments.error && <ErrorBox message={assignments.error} onRetry={assignments.reload} />}
        {mySession.error && <ErrorBox message={mySession.error} onRetry={mySession.reload} />}

        {canManageAssistants.data && (
          <Card>
            <h3 className="mb-3 font-bold">{lang === "ar" ? "➕ إضافة مساعد" : "Ajouter un assistant"}</h3>
            <div className="grid gap-3">
              <Field label={t("name")}><input className={inputCls} value={asstForm.full_name} onChange={(e) => setAsstForm({ ...asstForm, full_name: e.target.value })} /></Field>
              <Field label={lang === "ar" ? "الهاتف" : "Téléphone"}><input className={inputCls} value={asstForm.phone} onChange={(e) => setAsstForm({ ...asstForm, phone: e.target.value })} /></Field>
              <Field label={lang === "ar" ? "رقم البطاقة الوطنية" : "N° CIN"}><input className={inputCls} dir="ltr" value={asstForm.national_id_number} onChange={(e) => setAsstForm({ ...asstForm, national_id_number: e.target.value })} placeholder="AB123456" /></Field>
              <Field label={t("city")}><input className={inputCls} value={asstForm.city} onChange={(e) => setAsstForm({ ...asstForm, city: e.target.value })} /></Field>
              <Field label={t("region")}><input className={inputCls} value={asstForm.region} onChange={(e) => setAsstForm({ ...asstForm, region: e.target.value })} /></Field>
            </div>
            <div className="mt-3">
              <Btn disabled={!asstForm.full_name.trim() || asstBusy} onClick={async () => {
                setAsstBusy(true);
                try {
                  await api.createAssistant(partyId, {
                    full_name: asstForm.full_name.trim(), phone: asstForm.phone || undefined,
                    city: asstForm.city || undefined, region: asstForm.region || undefined,
                    national_id_number: asstForm.national_id_number || undefined,
                    polling_station_id: myStationId || undefined,
                  });
                  notify(lang === "ar" ? "تمت إضافة المساعد" : "Assistant ajouté", undefined, "success");
                  setAsstForm({ full_name: "", phone: "", city: "", region: "", national_id_number: "" });
                } catch (e) { notify(lang === "ar" ? "فشلت الإضافة" : "Échec", e instanceof Error ? e.message : String(e), "error"); }
                finally { setAsstBusy(false); }
              }}>{asstBusy ? "…" : t("save")}</Btn>
            </div>
          </Card>
        )}

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs text-slate-400">{lang === "ar" ? "الحزب" : "Parti"}</div>
              <div className="font-bold">{session.memberName}</div>
            </div>
            <Badge tone={mySession.data ? "green" : "slate"}>
              {mySession.data ? (lang === "ar" ? `مرحلة: ${mySession.data.phase}` : `Phase: ${mySession.data.phase}`) : (lang === "ar" ? "لا توجد جلسة" : "Aucune session")}
            </Badge>
          </div>
          <div className="mt-3 rounded-xl bg-slate-50 p-3 text-sm dark:bg-slate-800/60">
            <div className="text-xs text-slate-400">{t("station")}</div>
            {station.loading ? <Loading /> : station.data ? (
              <>
                <div className="font-semibold">{station.data.station_number} — {station.data.name_ar}</div>
                <div className="text-xs text-slate-500">{station.data.city} — {station.data.region}</div>
              </>
            ) : (
              <div className="text-amber-600">{lang === "ar" ? "لم يُعيَّن لك مكتب بعد — تواصل مع رئيس الحزب." : "Aucun bureau affecté."}</div>
            )}
          </div>
        </Card>

        {mySession.loading || assignments.loading ? <Loading /> : !mySession.data ? (
          <StartVoting
            partyId={partyId} observerId={observerId} stationId={stationId}
            yearId={assignments.data?.year?.id ?? null}
            onStarted={(id) => { notify(lang === "ar" ? "بدأ التصويت" : "Vote démarré", id, "success"); reloadAll(); }}
            onError={(m) => notify(lang === "ar" ? "فشل بدء التصويت" : "Échec", m, "warn")}
            notify={notify}
          />
        ) : (
          <ActiveSession
            session={mySession.data} observerId={observerId} partyId={partyId}
            onChanged={() => mySession.reload()}
            notify={notify}
            lang={lang}
          />
        )}
      </div>
      <Toasts toasts={toasts} dismiss={(id) => setToasts((ts) => ts.filter((x) => x.id !== id))} />
    </div>
  );
}

// ---------------------------------------------------------------------------
// بدء التصويت: موافقة GPS + بدء الجلسة في Supabase
// ---------------------------------------------------------------------------
function StartVoting({ partyId, observerId, stationId, yearId, onStarted, onError, notify }: {
  partyId: string; observerId: string; stationId: string | null; yearId: string | null;
  onStarted: (id: string) => void; onError: (m: string) => void;
  notify: (title: string, body: string | undefined, tone: Toast["tone"]) => void;
}) {
  const { t, lang } = useI18n();
  const [consent, setConsent] = useState(false);
  const [gps, setGps] = useState<"idle" | "pending" | "ok" | "denied">("idle");
  const [pos, setPos] = useState<{ lat: number; lng: number } | null>(null);
  const [busy, setBusy] = useState(false);
  const [confirmPhase, setConfirmPhase] = useState(false);

  const requestGps = () => {
    if (!navigator.geolocation) { setGps("denied"); return; }
    setGps("pending");
    navigator.geolocation.getCurrentPosition(
      (p) => { setGps("ok"); setPos({ lat: p.coords.latitude, lng: p.coords.longitude }); },
      () => setGps("denied"),
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const start = async () => {
    setBusy(true);
    try {
      if (!stationId) throw new Error(lang === "ar" ? "لم يُعيَّن لك مكتب" : "Aucun bureau affecté");
      // 1) تسجيل الموافقة في Supabase (جدول consent_records — append-only)
      const { data: userData } = await supabase.auth.getUser();
      if (userData.user) await api.grantLocationConsent(partyId, userData.user.id, observerId);
      // 2) إنشاء الجلسة (مرحلة voting)
      const id = await api.startVoting({ partyId, observerId, stationId, electionYearId: yearId });
      // 3) أول موقع (RLS/RPC تفرض الموافقة)
      if (pos) await api.sendLocation({ partyId, observerId, sessionId: id, lat: pos.lat, lng: pos.lng });
      onStarted(id);
    } catch (e) {
      onError(e instanceof Error ? e.message : String(e));
    } finally { setBusy(false); }
  };

  const ready = !!stationId && consent && gps === "ok" && !busy;

  return (
    <Card>
      <h3 className="mb-3 font-bold">{t("start_shift")}</h3>
      <label className="mb-3 flex items-start gap-2 text-sm text-slate-600 dark:text-slate-300">
        <input type="checkbox" className="mt-1" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
        <span>{t("consent_gps")}</span>
      </label>
      <div className="mb-3 flex items-center justify-between rounded-xl border border-slate-200 px-3 py-2 text-sm dark:border-slate-700">
        <span>{t("gps_status")}</span>
        {gps === "ok" && <Badge tone="green">GPS ✓</Badge>}
        {gps === "pending" && <Badge tone="amber">…</Badge>}
        {gps === "denied" && <Badge tone="red">{lang === "ar" ? "مرفوض" : "Refusé"}</Badge>}
        {gps === "denied" && (
          <p className="mt-2 w-full rounded-xl bg-amber-950/60 px-3 py-2 text-xs text-amber-300">
            {lang === "ar"
              ? "⚠ رفضت صلاحية الموقع — لن تظهر حالة «متصل» في لوحة الحزب. فعّل الموقع من إعدادات المتصفح ثم أعد فتح الصفحة."
              : "⚠ Localisation refusée — votre statut «connecté» n'apparaîtra pas. Activez-la dans les paramètres du navigateur."}
          </p>
        )}
        {gps === "idle" && <Badge tone="slate">—</Badge>}
      </div>
      <div className="flex gap-2">
        <Btn variant="ghost" onClick={requestGps}>{lang === "ar" ? "مشاركة الموقع" : "Partager la position"}</Btn>
        <Btn disabled={!ready} onClick={start}>{t("start_shift")}</Btn>
      </div>
      {!ready && (
        <p className="mt-2 text-xs text-slate-400">
          {lang === "ar" ? "يتطلب: تعيين مكتب + موافقة الموقع + تفعيل GPS." : "Requiert: bureau + consentement + GPS."}
        </p>
      )}
    </Card>
  );
}

// ---------------------------------------------------------------------------
// الجلسة النشطة: مراحل التصويت ← الفرز ← الإرسال + عدادات + إدخال الأصوات
// ---------------------------------------------------------------------------
function ActiveSession({ session, observerId, partyId, onChanged, notify, lang }: {
  session: api.SessionRow; observerId: string; partyId: string;
  onChanged: () => void;
  notify: (title: string, body: string | undefined, tone: Toast["tone"]) => void;
  lang: string;
}) {
  const { t } = useI18n();
  const [busyKey, setBusyKey] = useState<string | null>(null);
  const [confirmPhase, setConfirmPhase] = useState(false);
  const [reportSent, setReportSent] = useState(false);
  const [confirmFinish, setConfirmFinish] = useState(false);
  const [confirmSos, setConfirmSos] = useState(false);
  const [sosText, setSosText] = useState("");
  const [sosBusy, setSosBusy] = useState(false);

  const sendSos = async () => {
    setSosBusy(true);
    try {
      // kind = 'incident' (القيم المسموحة في قاعدة البيانات: field_report/count_minutes/incident)
      await api.createReport({
        partyId, observerId, stationId: session.polling_station_id, kind: "incident",
        body: `🚨 بلاغ طارئ: ${sosText.trim()} — ${new Date().toLocaleString("ar")}`,
      });
      notify(lang === "ar" ? "تم إرسال البلاغ الطارئ لرئيس الحزب" : "Alerte envoyée", undefined, "success");
      setSosText("");
      setConfirmSos(false);
    } catch (e) { notify(lang === "ar" ? "فشل إرسال البلاغ" : "Échec", e instanceof Error ? e.message : String(e), "error"); }
    finally { setSosBusy(false); }
  };
  const [report, setReport] = useState("");

  const [totals, setTotals] = useState<Record<string, number>>(session.totals ?? {});
  const watchRef = useRef<number | null>(null);

  const run = async (key: string, fn: () => Promise<unknown>, okMsg: string) => {
    if (busyKey) return; // منع الضغط المزدوج نهائياً
    setBusyKey(key);
    try {
      await fn();
      setTotals((await api.getMySession(observerId))?.totals ?? {});
      notify(okMsg, undefined, "success");
      onChanged();
    } catch (e) {
      notify(lang === "ar" ? "فشلت العملية" : "Échec", e instanceof Error ? e.message : String(e), "warn");
    } finally { setBusyKey(null); }
  };

  // تتبع الموقع دورياً أثناء الجلسة المفتوحة فقط؛ يتوقف عند الإنهاء/الإغلاق
  useEffect(() => {
    if (session.status !== "open") return;
    const send = () => navigator.geolocation?.getCurrentPosition(
      (p) => api.sendLocation({ partyId, observerId, sessionId: session.id, lat: p.coords.latitude, lng: p.coords.longitude }).catch(() => {}),
      () => {}
    );
    send();
    const interval = setInterval(send, 60000);
    if (navigator.geolocation) {
      watchRef.current = navigator.geolocation.watchPosition((p) => {
        api.sendLocation({ partyId, observerId, sessionId: session.id, lat: p.coords.latitude, lng: p.coords.longitude }).catch(() => {});
      }, () => {}, { maximumAge: 30000 });
    }
    return () => {
      clearInterval(interval);
      if (watchRef.current !== null) navigator.geolocation.clearWatch(watchRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session.id, session.status]);

  const total = session.male_count + session.female_count;

  return (
    <div className="space-y-4">
      {/* حالة الاتصال والمزامنة */}
      <Card>
        <div className="flex items-center justify-between text-sm">
          <span className="flex items-center gap-2">
            <span className={`h-2.5 w-2.5 rounded-full ${session.status === "open" ? "animate-pulse bg-green-500" : "bg-amber-500"}`} />
            {lang === "ar" ? "متصل" : "Connecté"}
          </span>
          <Badge tone={session.status === "open" ? "green" : "amber"}>{session.status}</Badge>
        </div>
      </Card>

      {/* عدادات الذكور والإناث */}
      <Card>
        <h3 className="mb-2 font-bold">{lang === "ar" ? "الحضور" : "Présence"}</h3>
        <div className="grid grid-cols-3 gap-3">
          <CounterButton
            label={lang === "ar" ? "ذكور" : "Hommes"} value={session.male_count}
            disabled={busyKey !== null || session.phase !== "voting"}
            onPress={() => run("m", () => api.incrementCounter(session.id, "male"), lang === "ar" ? "تم تسجيل ذكر (+1)" : "Homme (+1)")}
          />
          <CounterButton
            label={lang === "ar" ? "إناث" : "Femmes"} value={session.female_count}
            disabled={busyKey !== null || session.phase !== "voting"}
            onPress={() => run("f", () => api.incrementCounter(session.id, "female"), lang === "ar" ? "تم تسجيل أنثى (+1)" : "Femme (+1)")}
          />
          <div className="flex flex-col items-center justify-center rounded-2xl bg-slate-100 py-4 dark:bg-slate-800">
            <span className="text-xs text-slate-400">{lang === "ar" ? "المجموع" : "Total"}</span>
            <span className="text-3xl font-black tabular-nums">{total}</span>
          </div>
        </div>
        {session.phase === "voting" ? (
          <Btn
            className="mt-4 w-full" variant="success"
            disabled={busyKey !== null}
            onClick={() => setConfirmPhase(true)}
          >
            ⏭ {lang === "ar" ? "إنهاء التصويت وبدء الفرز" : "Terminer le vote et lancer le dépouillement"}
          </Btn>
        ) : null}
      </Card>

      <ConfirmDialog
        open={confirmPhase}
        onClose={() => setConfirmPhase(false)}
        onConfirm={() => {
          setConfirmPhase(false);
          run("endV", () => api.endVoting(session.id), lang === "ar" ? "انتهى التصويت — بدأ الفرز" : "Vote terminé");
        }}
        title={lang === "ar" ? "الانتقال إلى مرحلة الفرز" : "Passer au dépouillement"}
        message={lang === "ar" ? "سيتم إنهاء عملية التصويت وبدء الفرز. لا يمكن التراجع عن هذا الإجراء. هل أنت متأكد؟" : "Le vote sera clôturé et le dépouillement lancé. Action irréversible. Continuer ?"}
        confirmLabel={lang === "ar" ? "نعم، بدء الفرز" : "Oui, lancer"}
      />

      {/* الفرز: إدخال الأصوات */}
      {session.phase === "counting" && (
        <Card>
          <div className="mb-2 flex items-center justify-between">
            <h3 className="font-bold">{lang === "ar" ? "إدخال الفرز" : "Saisie du dépouillement"}</h3>
            <Btn variant="ghost" className="!px-3 !py-1 text-xs" disabled={busyKey !== null}
              onClick={() => run("rev", () => api.revertVote(session.id, session.party_id), lang === "ar" ? "تم التراجع عن آخر إدخال" : "Dernière saisie annulée")}>
              ↩ {t("revert")}
            </Btn>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {CANDIDATES.map((c) => (
              <button
                key={c.code}
                disabled={busyKey !== null}
                onClick={() => {
                  const clientId = crypto.randomUUID(); // idempotency key لكل ضغطة
                  run(`v-${clientId}`, () => api.addVote(session.id, session.party_id, c.code, clientId), `+1 ${lang === "ar" ? c.ar : c.fr}`);
                  if (navigator.vibrate) navigator.vibrate(15);
                }}
                className="flex flex-col items-center justify-center rounded-2xl bg-brand py-6 text-white shadow transition active:scale-95 disabled:opacity-50"
              >
                <span className="text-sm font-semibold">{lang === "ar" ? c.ar : c.fr}</span>
                <span className="mt-1 text-3xl font-black tabular-nums">{totals[c.code] ?? 0}</span>
              </button>
            ))}
          </div>
          <Btn
            className="mt-4 w-full" variant="success"
            disabled={busyKey !== null}
            onClick={() => {
              if (reportSent) run("endC", () => api.endCounting(session.id), lang === "ar" ? "أُرسل المحضر للمراجعة" : "PV envoyé");
              else setConfirmFinish(true);
            }}
          >
            ✓ {lang === "ar" ? "إنهاء الفرز وإرسال المحضر" : "Terminer et envoyer le PV"}
          </Btn>
        </Card>
      )}

      <ConfirmDialog
        open={confirmFinish}
        onClose={() => setConfirmFinish(false)}
        onConfirm={() => {
          setConfirmFinish(false);
          run("endC", () => api.endCounting(session.id), lang === "ar" ? "أُرسل المحضر للمراجعة" : "PV envoyé");
        }}
        title={lang === "ar" ? "لم تُرسل تقريرًا ميدانيًا" : "Aucun rapport de terrain"}
        message={lang === "ar" ? "يُنصح بإرفاق تقرير ميداني مع المحضر. يمكنك الإرسال الآن بدونه أو كتابة التقرير أولًا." : "Un rapport de terrain est recommandé avant l'envoi du PV."}
        confirmLabel={lang === "ar" ? "إرسال بدون تقرير" : "Envoyer sans rapport"}
      />

      <Modal open={confirmSos} onClose={() => setConfirmSos(false)} title={lang === "ar" ? "🚨 بلاغ طارئ لرئيس الحزب" : "Alerte urgente"}>
        <div className="space-y-3">
          <p className="text-sm text-slate-400">
            {lang === "ar" ? "اكتب وصف الحالة الطارئة — سيصل التنبيه فورًا لرئيس الحزب دون أي تأثير على عملية الحضور أو إحصاء الفرز." : "Décrivez l'urgence — alerte immédiate au président, sans impact sur le dépouillement."}
          </p>
          <textarea
            className={`${inputCls} min-h-24`}
            value={sosText}
            onChange={(e) => setSosText(e.target.value)}
            placeholder={lang === "ar" ? "مثال: تعارض حول محضر الاقتراع، غياب رئيس المكتب..." : "Décrivez la situation..."}
            autoFocus
          />
          <div className="flex justify-end gap-2">
            <Btn variant="ghost" onClick={() => setConfirmSos(false)}>{lang === "ar" ? "إلغاء" : "Annuler"}</Btn>
            <Btn variant="danger" disabled={sosBusy || !sosText.trim()} onClick={sendSos}>
              {sosBusy ? "جارٍ الإرسال…" : (lang === "ar" ? "إرسال البلاغ" : "Envoyer")}
            </Btn>
          </div>
        </div>
      </Modal>

      {session.status === "open" && (
        <button
          type="button"
          onClick={() => setConfirmSos(true)}
          title={lang === "ar" ? "بلاغ طارئ لرئيس الحزب" : "Alerte urgente"}
          aria-label={lang === "ar" ? "بلاغ طارئ" : "Alerte"}
          className="fixed bottom-5 end-5 z-40 flex h-14 w-14 items-center justify-center rounded-full border-2 border-red-400 bg-red-600 text-white shadow-lg shadow-red-950/60 transition hover:bg-red-500 active:scale-90"
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" className="h-7 w-7">
            <path d="M12 9v4" />
            <path d="M12 17h.01" />
            <path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
          </svg>
        </button>
      )}


      {/* تقرير ميداني */}
      {session.status === "open" && (
        <Card>
          <h3 className="mb-2 font-bold">{lang === "ar" ? "تقرير ميداني" : "Rapport de terrain"}</h3>
          <textarea
            className="w-full rounded-xl border border-slate-300 bg-white p-3 text-sm outline-none focus:border-brand dark:border-slate-700 dark:bg-slate-900"
            rows={3}
            value={report}
            onChange={(e) => setReport(e.target.value)}
          />
          <div className="mt-3">
            <Btn variant="ghost" disabled={!report.trim() || busyKey !== null}
              onClick={() => run("rep", async () => {
                await api.createReport({ partyId, observerId, stationId: session.polling_station_id, kind: "field_report", body: report });
                setReport("");
                setReportSent(true);
              }, lang === "ar" ? "تم إرسال التقرير" : "Rapport envoyé")}>
              {t("submit")}
            </Btn>
          </div>
        </Card>
      )}

      {session.status === "submitted" && (
        <Card>
          <p className="text-center text-sm text-slate-500">
            {lang === "ar" ? "المحضر قيد المراجعة لدى رئيس الحزب. توقف تتبع الموقع تلقائياً."
              : "PV en révision par le chef de parti. Le suivi de position est arrêté."}
          </p>
        </Card>
      )}
    </div>
  );
}

function CounterButton({ label, value, onPress, disabled }: {
  label: string; value: number; onPress: () => void; disabled: boolean;
}) {
  return (
    <button
      onClick={onPress}
      disabled={disabled}
      className="flex flex-col items-center justify-center rounded-2xl bg-brand py-4 text-white shadow transition active:scale-95 disabled:opacity-50"
    >
      <span className="text-xs">{label} +1</span>
      <span className="text-3xl font-black tabular-nums">{value}</span>
    </button>
  );
}

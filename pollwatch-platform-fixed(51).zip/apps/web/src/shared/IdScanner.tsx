import { useEffect, useRef, useState } from "react";
import { Html5Qrcode } from "html5-qrcode";
import { Btn, Modal } from "./ui";

// ============================================================================
// قارئ البطاقة الوطنية المغربية:
// 1) باركود PDF417 (ظهر البطاقة)  2) تصوير MRZ (ICAO 9303) عبر OCR
// 3) NFC (Web NFC — Chrome/Android)  + نافذة مراجعة البيانات قبل التعبئة
// ============================================================================

export interface MrzData {
  idNumber?: string; fullName?: string; dob?: string; expiry?: string;
  sex?: string; nationality?: string; raw: string;
}

const fmtDate = (yyMMdd: string): string | undefined => {
  if (!/^\d{6}$/.test(yyMMdd)) return undefined;
  const yy = +yyMMdd.slice(0, 2);
  const yyyy = yy <= 30 ? 2000 + yy : 1900 + yy;
  return `${yyyy}-${yyMMdd.slice(2, 4)}-${yyMMdd.slice(4, 6)}`;
};

/** تحليل أسطر MRZ بصيغة ICAO 9303 (TD1: 3 أسطر × 30 محرفاً) — المستعمل في البطاقة المغربية */
export function parseMrz(raw: string): MrzData | null {
  const lines = raw.toUpperCase().split(/[\n\r]+/).map((l) => l.replace(/\s/g, "")).filter((l) => l.length >= 25);
  const mrz = lines.filter((l) => /^[A-Z0-9<]{25,}$/.test(l));
  if (mrz.length < 3) return null;
  const i1 = mrz.findIndex((l) => l.startsWith("ID"));
  const s = i1 >= 0 ? i1 : 0;
  const l1 = mrz[s] ?? "", l2 = mrz[s + 1] ?? "", l3 = mrz[s + 2] ?? "";
  if (l2.length < 18 || !l3.includes("<<")) return null;
  const parts = l3.split("<<");
  const surname = (parts[0] ?? "").replace(/</g, " ").trim();
  const given = parts.slice(1).join(" ").replace(/</g, " ").trim();
  return {
    idNumber: l1.slice(5, 14).replace(/</g, "") || undefined,
    fullName: [given, surname].filter(Boolean).join(" ") || undefined,
    dob: fmtDate(l2.slice(0, 6)),
    expiry: fmtDate(l2.slice(8, 14)),
    sex: l2.charAt(7) === "M" || l2.charAt(7) === "F" ? l2.charAt(7) : undefined,
    nationality: l2.slice(15, 18).replace(/</g, "") || undefined,
    raw,
  };
}

/** تحليل أي نص: MRZ أولاً ثم بحث عن رقم بطاقة كاحتياط */
export function parseIdText(raw: string): MrzData {
  return parseMrz(raw) ?? { idNumber: raw.match(/[A-Z]{1,2}\d{6,8}/)?.[0], raw };
}

// ---------------------------------------------------------------------------
// NFC (Web NFC — يتطلب Chrome على Android وشريحة بتنسيق NDEF)
// ---------------------------------------------------------------------------
type NdefLike = { scan(): Promise<void>; onreading: ((e: never) => void) | null; onreadingerror: (() => void) | null };
export async function tryNfcScan(): Promise<string> {
  if (typeof window === "undefined" || !("NDEFReader" in window)) {
    throw new Error("الـ NFC غير مدعوم على هذا المتصفح — يتطلب Chrome على Android");
  }
  const ndef = new (window as unknown as { NDEFReader: new () => NdefLike }).NDEFReader();
  await ndef.scan();
  return new Promise((resolve, reject) => {
    const to = setTimeout(() => reject(new Error("انتهت مهلة القراءة — قرّب البطاقة من ظهر الهاتف")), 20000);
    ndef.onreading = ((e: { message: { records: { data?: ArrayBuffer }[] } }) => {
      clearTimeout(to);
      const rec = e.message.records[0];
      if (rec?.data) resolve(new TextDecoder().decode(rec.data));
      else reject(new Error("الشريحة لا تحوي نصاً قابلاً للقراءة — البطاقات الإلكترونية الحكومية غالباً تتطلب تطبيقات eID خاصة"));
    }) as never;
    ndef.onreadingerror = () => { clearTimeout(to); reject(new Error("تعذّرت قراءة الشريحة — أبقِ البطاقة ثابتة")); };
  });
}

// ---------------------------------------------------------------------------
// نافذة مراجعة بيانات البطاقة قبل التعبئة
// ---------------------------------------------------------------------------
export function MrzReviewModal({ data, onClose, onFill }: {
  data: MrzData | null; onClose: () => void; onFill: (d: MrzData) => void;
}) {
  if (!data) return null;
  const rows: [string, string | undefined][] = [
    ["رقم البطاقة", data.idNumber],
    ["الاسم الكامل", data.fullName],
    ["تاريخ الازدياد", data.dob],
    ["تاريخ الانتهاء", data.expiry],
    ["الجنس", data.sex === "M" ? "ذكر" : data.sex === "F" ? "أنثى" : undefined],
    ["الجنسية", data.nationality],
  ];
  return (
    <Modal open onClose={onClose} title="بيانات البطاقة المقروءة">
      <div className="space-y-2">
        {rows.map(([k, v]) => (
          <div key={k} className="flex items-center justify-between rounded-xl bg-slate-800/60 px-3 py-2 text-sm">
            <span className="text-slate-400">{k}</span>
            <b dir="ltr">{v ?? "—"}</b>
          </div>
        ))}
        <div className="flex justify-end gap-2 pt-2">
          <Btn variant="ghost" onClick={onClose}>إلغاء</Btn>
          <Btn onClick={() => { onFill(data); onClose(); }}>تعبئة النموذج بهذه البيانات</Btn>
        </div>
      </div>
    </Modal>
  );
}

// ---------------------------------------------------------------------------
// نافذة الماسح: باركود حي أو تصوير MRZ
// ---------------------------------------------------------------------------
export default function IdScannerModal({ open, onClose, onResult }: {
  open: boolean; onClose: () => void; onResult: (d: MrzData) => void;
}) {
  const [tab, setTab] = useState<"barcode" | "mrz">("barcode");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [progress, setProgress] = useState("");
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    if (!open || tab !== "barcode") return;
    let alive = true;
    const scanner = new Html5Qrcode("pw-id-reader");
    scanner.start(
      { facingMode: "environment" },
      { fps: 10, qrbox: { width: 280, height: 160 } },
      (text) => {
        if (!alive) return;
        alive = false;
        scanner.stop().catch(() => {}).then(() => { onResult(parseIdText(text)); onClose(); });
      },
      () => {}
    ).catch((e) => setErr(String(e)));
    return () => { alive = false; scanner.stop().catch(() => {}).then(() => scanner.clear()).catch(() => {}); };
  }, [open, tab]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!open || tab !== "mrz") return;
    let alive = true;
    navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } }).then((st) => {
      if (!alive) { st.getTracks().forEach((t) => t.stop()); return; }
      streamRef.current = st;
      if (videoRef.current) { videoRef.current.srcObject = st; videoRef.current.play().catch(() => {}); }
    }).catch((e) => setErr(String(e)));
    return () => { alive = false; streamRef.current?.getTracks().forEach((t) => t.stop()); streamRef.current = null; };
  }, [open, tab]);

  const captureOcr = async () => {
    const v = videoRef.current;
    if (!v || !v.videoWidth) return;
    setBusy(true); setErr(null); setProgress("جارٍ التحليل…");
    try {
      const canvas = document.createElement("canvas");
      canvas.width = v.videoWidth; canvas.height = v.videoHeight;
      canvas.getContext("2d")!.drawImage(v, 0, 0);
      const { createWorker } = await import("tesseract.js");
      const worker = await createWorker("eng", 1, {
        logger: (m: { status: string; progress: number }) => setProgress(`${m.status} ${Math.round(m.progress * 100)}%`),
      });
      const { data: { text } } = await worker.recognize(canvas);
      await worker.terminate();
      const parsed = parseIdText(text);
      if (!parsed.idNumber && !parsed.fullName) throw new Error(`تعذّرت القراءة بوضوح — حسّن الإضاءة والزاوية. (المقروء: ${text.slice(0, 80)})`);
      onResult(parsed); onClose();
    } catch (e) { setErr(e instanceof Error ? e.message : String(e)); }
    finally { setBusy(false); setProgress(""); }
  };

  return (
    <Modal open={open} onClose={onClose} title="قراءة البطاقة الوطنية">
      <div className="mb-3 flex gap-2">
        <Btn variant={tab === "barcode" ? "primary" : "ghost"} className="!px-3 !py-1 text-xs" onClick={() => setTab("barcode")}>باركود PDF417</Btn>
        <Btn variant={tab === "mrz" ? "primary" : "ghost"} className="!px-3 !py-1 text-xs" onClick={() => setTab("mrz")}>تصوير MRZ</Btn>
      </div>
      {tab === "barcode" ? (
        <>
          <p className="mb-3 text-sm text-slate-400">وجّه الكاميرا نحو الباركود على ظهر البطاقة.</p>
          {err && <p className="mb-2 text-sm text-red-400">{err}</p>}
          <div id="pw-id-reader" className="w-full overflow-hidden rounded-xl border border-slate-700" />
        </>
      ) : (
        <>
          <p className="mb-3 text-sm text-slate-400">وجّه الكاميرا نحو الأسطر السفلية (MRZ) من البطاقة ثم اضغط «قراءة».</p>
          {err && <p className="mb-2 text-sm text-red-400">{err}</p>}
          <video ref={videoRef} className="mb-3 w-full rounded-xl border border-slate-700" playsInline muted />
          {progress && <p className="mb-2 text-xs text-slate-400">{progress}</p>}
          <Btn disabled={busy} onClick={captureOcr}>{busy ? "جارٍ القراءة…" : "📸 قراءة النص"}</Btn>
        </>
      )}
    </Modal>
  );
}

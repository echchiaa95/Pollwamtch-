import { createContext, useContext, useState, type ReactNode } from "react";

type Lang = "ar" | "fr";
const dict: Record<string, { ar: string; fr: string }> = {
  app_title: { ar: "منصة متابعة مكاتب الاقتراع", fr: "Suivi des bureaux de vote" },
  login: { ar: "تسجيل الدخول", fr: "Connexion" },
  superadmin: { ar: "المدير المركزي", fr: "Superadmin" },
  party_admin: { ar: "رئيس الحزب", fr: "Chef de parti" },
  observer: { ar: "المراقب", fr: "Observateur" },
  dashboard: { ar: "لوحة التحكم", fr: "Tableau de bord" },
  parties: { ar: "الأحزاب", fr: "Partis" },
  domains: { ar: "الدومينات", fr: "Domaines" },
  users: { ar: "المستخدمون", fr: "Utilisateurs" },
  stations: { ar: "مكاتب الاقتراع", fr: "Bureaux de vote" },
  observers: { ar: "المراقبون", fr: "Observateurs" },
  assistants: { ar: "المساعدون", fr: "Assistants" },
  reports: { ar: "التقارير", fr: "Rapports" },
  stats: { ar: "الإحصائيات", fr: "Statistiques" },
  map: { ar: "الخريطة", fr: "Carte" },
  total_stations: { ar: "إجمالي المكاتب", fr: "Total bureaux" },
  observers_count: { ar: "المراقبون", fr: "Observateurs" },
  connected: { ar: "متصل", fr: "Connectés" },
  disconnected: { ar: "غير متصل", fr: "Déconnectés" },
  coverage: { ar: "نسبة التغطية", fr: "Taux de couverture" },
  counting_started: { ar: "بدأ الفرز", fr: "Dépouillement lancé" },
  reports_received: { ar: "تقارير مستلمة", fr: "Rapports reçus" },
  reports_reviewed: { ar: "تقارير مراجعة", fr: "Rapports révisés" },
  support_votes: { ar: "الأصوات المحصاة", fr: "Voix dépouillées" },
  assistants_active: { ar: "مساعدون نشطون", fr: "Assistants actifs" },
  start_shift: { ar: "بدء الوردية", fr: "Débuter le shift" },
  end_shift: { ar: "إنهاء الوردية", fr: "Terminer le shift" },
  last_sync: { ar: "آخر مزامنة", fr: "Dernière synchro" },
  gps_status: { ar: "حالة GPS", fr: "Statut GPS" },
  connection: { ar: "الاتصال", fr: "Connexion" },
  add_party: { ar: "إنشاء حزب جديد", fr: "Nouveau parti" },
  add_station: { ar: "إضافة مكتب", fr: "Ajouter un bureau" },
  add_observer: { ar: "إضافة مراقب", fr: "Ajouter un observateur" },
  add_assistant: { ar: "إضافة مساعد", fr: "Ajouter un assistant" },
  search: { ar: "بحث…", fr: "Rechercher…" },
  save: { ar: "حفظ", fr: "Enregistrer" },
  cancel: { ar: "إلغاء", fr: "Annuler" },
  submit: { ar: "إرسال", fr: "Envoyer" },
  review: { ar: "مراجعة", fr: "Réviser" },
  validate: { ar: "اعتماد", fr: "Valider" },
  reject: { ar: "إرجاع", fr: "Retourner" },
  revert: { ar: "تراجع", fr: "Annuler" },
  station: { ar: "مكتب الاقتراع", fr: "Bureau de vote" },
  station_number: { ar: "رقم المكتب", fr: "N° du bureau" },
  name: { ar: "الاسم", fr: "Nom" },
  city: { ar: "المدينة", fr: "Ville" },
  region: { ar: "الجهة", fr: "Région" },
  status: { ar: "الحالة", fr: "Statut" },
  actions: { ar: "إجراءات", fr: "Actions" },
  logout: { ar: "خروج", fr: "Déconnexion" },
  language: { ar: "Français", fr: "العربية" },
  not_connected_hint: { ar: "غير متصل — آخر تحديث قديم", fr: "Hors ligne — dernière mise à jour ancienne" },
  report_submitted: { ar: "تم إرسال المحضر للمراجعة", fr: "Procès-verbal envoyé pour révision" },
  offline_queue: { ar: "بانتظار المزامنة", fr: "En attente de synchro" },
  consent_gps: {
    ar: "أوافق على مشاركة موقعي الجغرافي أثناء الوردية فقط، وفق سياسة الخصوصية المعتمدة، ويتوقف التتبع عند إنهاء الوردية.",
    fr: "J'accepte de partager ma position géographique pendant le shift uniquement, selon la politique de confidentialité approuvée. Le suivi s'arrête à la fin du shift.",
  },
  official_vs_estimate: {
    ar: "هذه البيانات مساندة/تقديرية غير رسمية، وتُفصل عن محاضر الفرز الرسمية.",
    fr: "Données de soutien/estimées non officielles, séparées des procès-verbaux officiels.",
  },
};

interface I18nCtx {
  lang: Lang;
  t: (key: string) => string;
  toggle: () => void;
}
const Ctx = createContext<I18nCtx>({ lang: "ar", t: (k) => k, toggle: () => {} });

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>("ar");
  const t = (key: string) => dict[key]?.[lang] ?? key;
  const toggle = () => {
    const next: Lang = lang === "ar" ? "fr" : "ar";
    setLang(next);
    document.documentElement.lang = next;
    document.documentElement.dir = next === "ar" ? "rtl" : "ltr";
  };
  return <Ctx.Provider value={{ lang, t, toggle }}>{children}</Ctx.Provider>;
}
export const useI18n = () => useContext(Ctx);

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, "Content-Type": "application/json" },
  });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ success: false, error: "method_not_allowed" }, 405);

  try {
    // 1) قراءة Authorization header والتحقق من الجلسة
    const token = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "").trim();
    if (!token) return json({ success: false, error: "يجب تسجيل الدخول أولاً" }, 401);

    const url = Deno.env.get("SUPABASE_URL");
    const anon = Deno.env.get("SUPABASE_ANON_KEY");
    // المفتاح السري يُقرأ داخلياً فقط — لا يصل إلى الواجهة أبداً
    const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!url || !anon || !service) return json({ success: false, error: "إعدادات Supabase السرية ناقصة على الخادم" }, 500);

    const auth = createClient(url, anon);
    const { data: ud, error: ue } = await auth.auth.getUser(token);
    if (ue || !ud.user) return json({ success: false, error: "جلسة الدخول غير صالحة" }, 401);

    // 2) التحقق من صلاحية superadmin عبر service role (تجاوز RLS بأمان)
    const admin = createClient(url, service);
    const { data: me } = await admin
      .from("party_members").select("id, roles!inner(key)")
      .eq("user_id", ud.user.id).eq("status", "active")
      .eq("roles.key", "superadmin").limit(1).maybeSingle();
    if (!me) return json({ success: false, error: "ليس لديك صلاحية المدير المركزي" }, 403);

    // 3) التحقق من body ووجود الحزب
    let body: { party_id?: string };
    try { body = await req.json(); }
    catch { return json({ success: false, error: "body غير صالح (JSON مطلوب)" }, 400); }
    const partyId = String(body?.party_id ?? "").trim();
    if (!partyId) return json({ success: false, error: "party_id مطلوب" }, 400);

    const { data: party, error: partyErr } = await admin
      .from("parties").select("id, name_ar").eq("id", partyId).maybeSingle();
    if (partyErr) return json({ success: false, error: partyErr.message }, 400);
    if (!party) return json({ success: false, error: "الحزب غير موجود" }, 404);

    // 4) جمع حسابات Auth المرتبطة بالحزب
    const { data: members, error: memberError } = await admin
      .from("party_members").select("user_id").eq("party_id", partyId);
    if (memberError) return json({ success: false, error: memberError.message }, 400);

    // 5) حذف حسابات Auth أولاً — قبل لمس بيانات الحزب
    const failedUsers: string[] = [];
    for (const m of members ?? []) {
      if (!m.user_id) continue;
      const { error: delUserErr } = await admin.auth.admin.deleteUser(m.user_id);
      if (delUserErr) failedUsers.push(m.user_id);
    }

    // 6) حذف سجل الحزب
    const { error: delPartyError } = await admin.from("parties").delete().eq("id", partyId);
    if (delPartyError) {
      return json({
        success: false,
        error: delPartyError.message,
        partial: true, // حُذفت بعض/كل حسابات Auth لكن بيانات الحزب بقيت
        deleted_auth_users: (members ?? []).length - failedUsers.length,
        failed_auth_users: failedUsers.length,
      }, 400);
    }

    // 7) تقرير نهائي صادق — نجاح كامل أو جزئي لا يُخفى
    const partial = failedUsers.length > 0;
    return json({
      success: true,
      ok: true,
      data: {
        deleted_party_id: partyId,
        deleted_auth_users: (members ?? []).length - failedUsers.length,
        failed_auth_users: failedUsers.length,
        partial,
      },
      ...(partial ? { warning: "فشل حذف بعض حسابات Auth — راجع لوحة Supabase" } : {}),
    });
  } catch (e) {
    return json({ success: false, error: e instanceof Error ? e.message : String(e) }, 500);
  }
});

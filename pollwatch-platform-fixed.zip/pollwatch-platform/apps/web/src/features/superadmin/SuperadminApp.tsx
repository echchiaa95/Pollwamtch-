import { useMemo, useState, type ReactNode } from "react";
import { useI18n } from "../../lib/i18n";
import { store } from "../../lib/store";
import { Badge, Btn, Card, Field, StatCard, TopBar, inputCls, statusTone, useDB } from "../../shared/ui";

type Tab = "parties" | "users" | "stations";

export default function SuperadminApp({ logout }: { logout: ReactNode }) {
  const { t } = useI18n();
  const [tab, setTab] = useState<Tab>("parties");
  const db = useDB();
  const tabs: { key: Tab; label: string }[] = [
    { key: "parties", label: t("parties") },
    { key: "users", label: t("users") },
    { key: "stations", label: t("stations") },
  ];
  return (
    <div className="min-h-screen">
      <TopBar title={`${t("app_title")} — ${t("superadmin")}`} right={logout} />
      <div className="mx-auto max-w-6xl p-4">
        <div className="mb-4 flex gap-2">
          {tabs.map((x) => (
            <button
              key={x.key}
              onClick={() => setTab(x.key)}
              className={`rounded-xl px-4 py-2 text-sm font-semibold transition ${
                tab === x.key ? "bg-brand text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300"
              }`}
            >
              {x.label}
            </button>
          ))}
        </div>
        {tab === "parties" && <PartiesTab />}
        {tab === "users" && <UsersTab />}
        {tab === "stations" && <StationsTab db={db} />}
      </div>
    </div>
  );
}

function PartiesTab() {
  const { t } = useI18n();
  const db = useDB();
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <StatCard label={t("parties")} value={db.parties.length} />
        <StatCard label={t("domains")} value={db.domains.length} tone="blue" />
        <StatCard label="نشط" value={db.parties.filter((p) => p.status === "active").length} tone="green" />
        <StatCard label="معلّق" value={db.parties.filter((p) => p.status === "pending").length} tone="amber" />
      </div>
      <Card>
        <h3 className="mb-3 font-bold">{t("add_party")}</h3>
        <div className="grid gap-3 md:grid-cols-3">
          <Field label="اسم الحزب">
            <input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} placeholder="حزب النموذج" />
          </Field>
          <Field label="Slug (الدومين)">
            <input className={inputCls} value={slug} onChange={(e) => setSlug(e.target.value.replace(/[^a-z0-9-]/g, ""))} placeholder="parti-exemple" />
          </Field>
          <div className="flex items-end">
            <Btn disabled={!name || !slug} onClick={() => { store.addParty({ name_ar: name, slug }); setName(""); setSlug(""); }}>
              {t("save")}
            </Btn>
          </div>
        </div>
        <p className="mt-2 text-xs text-slate-400">يُنشأ تلقائياً: دومين www.{slug || "…"}.ma بحالة «قيد التحقق» — Superadmin وحده يتحقق عبر DNS TXT.</p>
      </Card>
      {db.parties.map((p) => (
        <Card key={p.id}>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl text-white font-bold" style={{ background: p.colors.primary }}>
                {p.name_ar.slice(0, 1)}
              </div>
              <div>
                <div className="font-bold">{p.name_ar} {p.name_fr && <span className="text-sm text-slate-400">({p.name_fr})</span>}</div>
                <div className="text-xs text-slate-400">{p.slug}.ma</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge tone={statusTone(p.status)}>{p.status}</Badge>
              {p.status !== "active" && (
                <Btn variant="success" className="!px-3 !py-1 text-xs" onClick={() => store.setPartyStatus(p.id, "active")}>تفعيل</Btn>
              )}
              {p.status === "active" && (
                <Btn variant="danger" className="!px-3 !py-1 text-xs" onClick={() => store.setPartyStatus(p.id, "suspended")}>تعطيل</Btn>
              )}
            </div>
          </div>
          <div className="mt-3 space-y-2 border-t border-slate-100 pt-3 dark:border-slate-800">
            {db.domains.filter((d) => d.party_id === p.id).map((d) => (
              <div key={d.id} className="flex items-center justify-between rounded-xl bg-slate-50 px-3 py-2 text-sm dark:bg-slate-800/60">
                <span dir="ltr">{d.domain}</span>
                <div className="flex items-center gap-2">
                  <Badge tone={d.verified ? "green" : "amber"}>{d.verified ? "مُتحقق (DNS)" : "قيد التحقق"}</Badge>
                  <Badge tone={statusTone(d.ssl)}>SSL: {d.ssl}</Badge>
                  {!d.verified && (
                    <Btn variant="ghost" className="!px-3 !py-1 text-xs" onClick={() => store.verifyDomain(d.id)}>
                      محاكاة التحقق
                    </Btn>
                  )}
                </div>
              </div>
            ))}
          </div>
        </Card>
      ))}
    </div>
  );
}

function UsersTab() {
  const { t } = useI18n();
  const db = useDB();
  const [q, setQ] = useState("");
  const rows = useMemo(
    () => db.members.filter((m) => m.full_name.includes(q) || m.role.includes(q)),
    [db.members, q]
  );
  return (
    <Card>
      <div className="mb-3 flex items-center justify-between gap-2">
        <h3 className="font-bold">{t("users")}</h3>
        <input className={`${inputCls} max-w-xs`} placeholder={t("search")} value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-200 text-start text-slate-400 dark:border-slate-800">
              <th className="p-2 text-start">{t("name")}</th>
              <th className="p-2 text-start">الدور</th>
              <th className="p-2 text-start">الحزب</th>
              <th className="p-2 text-start">{t("status")}</th>
              <th className="p-2 text-start">{t("actions")}</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((m) => {
              const party = db.parties.find((p) => p.id === m.party_id);
              return (
                <tr key={m.id} className="border-b border-slate-100 dark:border-slate-800/60">
                  <td className="p-2 font-medium">{m.full_name}</td>
                  <td className="p-2"><Badge tone={m.role === "superadmin" ? "violet" : "blue"}>{t(m.role)}</Badge></td>
                  <td className="p-2 text-slate-500">{party?.name_ar ?? "—"}</td>
                  <td className="p-2"><Badge tone={statusTone(m.status)}>{m.status}</Badge></td>
                  <td className="p-2">
                    <Btn variant="ghost" className="!px-3 !py-1 text-xs" onClick={() =>
                      store.toggleMemberStatus(m.id, m.status === "active" ? "suspended" : "active")
                    }>
                      {m.status === "active" ? "تعطيل" : "تفعيل"}
                    </Btn>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function StationsTab({ db }: { db: ReturnType<typeof useDB> }) {
  const { t } = useI18n();
  const [num, setNum] = useState("");
  const [name, setName] = useState("");
  const [city, setCity] = useState("");
  const [region, setRegion] = useState("");
  const [lat, setLat] = useState("");
  const [lng, setLng] = useState("");
  const [q, setQ] = useState("");
  const rows = db.stations.filter((s) => s.station_number.includes(q) || s.name_ar.includes(q) || (s.city ?? "").includes(q));
  return (
    <div className="space-y-4">
      <Card>
        <h3 className="mb-3 font-bold">{t("add_station")}</h3>
        <div className="grid gap-3 md:grid-cols-3">
          <Field label={t("station_number")}><input className={inputCls} value={num} onChange={(e) => setNum(e.target.value)} placeholder="CASA-004" /></Field>
          <Field label={t("name")}><input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} /></Field>
          <Field label={t("city")}><input className={inputCls} value={city} onChange={(e) => setCity(e.target.value)} /></Field>
          <Field label={t("region")}><input className={inputCls} value={region} onChange={(e) => setRegion(e.target.value)} /></Field>
          <Field label="خط العرض (lat)"><input className={inputCls} value={lat} onChange={(e) => setLat(e.target.value)} placeholder="33.57" /></Field>
          <Field label="خط الطول (lng)"><input className={inputCls} value={lng} onChange={(e) => setLng(e.target.value)} placeholder="-7.58" /></Field>
        </div>
        <div className="mt-3">
          <Btn disabled={!num || !name || !lat || !lng} onClick={() => {
            store.addStation({ station_number: num, name_ar: name, city, region, lat: +lat, lng: +lng });
            setNum(""); setName(""); setCity(""); setRegion(""); setLat(""); setLng("");
          }}>{t("save")}</Btn>
        </div>
      </Card>
      <Card>
        <div className="mb-3"><input className={`${inputCls} max-w-xs`} placeholder={t("search")} value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-slate-400 dark:border-slate-800">
                <th className="p-2 text-start">{t("station_number")}</th>
                <th className="p-2 text-start">{t("name")}</th>
                <th className="p-2 text-start">{t("city")}</th>
                <th className="p-2 text-start">{t("status")}</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((s) => (
                <tr key={s.id} className="border-b border-slate-100 dark:border-slate-800/60">
                  <td className="p-2 font-mono">{s.station_number}</td>
                  <td className="p-2">{s.name_ar}</td>
                  <td className="p-2 text-slate-500">{s.city} — {s.region}</td>
                  <td className="p-2"><Badge tone={statusTone(s.status)}>{s.status}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

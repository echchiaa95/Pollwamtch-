import { useEffect, useRef, useState, type ReactNode } from "react";
import { useI18n } from "../../lib/i18n";
import { store } from "../../lib/store";
import type { Session } from "../../lib/types";
import { Badge, Btn, Card, TopBar, useDB } from "../../shared/ui";

export default function ObserverApp({ session, logout }: { session: Session; logout: ReactNode }) {
  const { t, lang } = useI18n();
  const db = useDB();
  const observer = db.observers.find((o) => o.id === session.observerId);
  const assign = db.assignments.find((a) => a.observer_id === session.observerId);
  const station = db.stations.find((s) => s.id === assign?.station_id);
  const mySession = db.sessions.find((s) => s.observer_id === session.observerId && s.status === "open");

  return (
    <div className="min-h-screen pb-8">
      <TopBar title={`${t("observer")} — ${observer?.full_name ?? ""}`} right={logout} />
      <div className="mx-auto max-w-md space-y-4 p-4">
        <Card>
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs text-slate-400">{t("party_admin")}</div>
              <div className="font-bold">{db.parties[0]?.name_ar}</div>
            </div>
            <Badge tone={mySession ? "green" : "slate"}>{mySession ? (lang === "ar" ? "وردية نشطة" : "Shift actif") : (lang === "ar" ? "خارج الوردية" : "Hors shift")}</Badge>
          </div>
          <div className="mt-3 rounded-xl bg-slate-50 p-3 text-sm dark:bg-slate-800/60">
            <div className="text-xs text-slate-400">{t("station")}</div>
            <div className="font-semibold">{station ? `${station.station_number} — ${station.name_ar}` : (lang === "ar" ? "لم يُعيَّن مكتب بعد" : "Aucun bureau affecté")}</div>
            {station && <div className="text-xs text-slate-500">{station.city} — {station.region}</div>}
          </div>
        </Card>
        {!mySession && <StartShift session={session} stationId={station?.id} />}
        {mySession && <CountingPad sessionId={mySession.id} observerId={session.observerId!} />}
      </div>
    </div>
  );
}

function StartShift({ session, stationId }: { session: Session; stationId?: string }) {
  const { t, lang } = useI18n();
  const [consent, setConsent] = useState(false);
  const [gpsState, setGpsState] = useState<"idle" | "pending" | "ok" | "denied">("idle");
  const [error, setError] = useState("");

  const requestGps = () => {
    if (!navigator.geolocation) { setGpsState("denied"); return; }
    setGpsState("pending");
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGpsState("ok");
        store.pingLocation(session.observerId!, pos.coords.latitude, pos.coords.longitude);
      },
      () => setGpsState("denied"),
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  return (
    <Card>
      <h3 className="mb-3 font-bold">{t("start_shift")}</h3>
      <label className="mb-3 flex items-start gap-2 text-sm text-slate-600 dark:text-slate-300">
        <input type="checkbox" className="mt-1" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
        <span>{t("consent_gps")}</span>
      </label>
      <div className="mb-3 flex items-center justify-between rounded-xl border border-slate-200 px-3 py-2 text-sm dark:border-slate-700">
        <span>{t("gps_status")}</span>
        {gpsState === "ok" && <Badge tone="green">GPS ✓</Badge>}
        {gpsState === "pending" && <Badge tone="amber">…</Badge>}
        {gpsState === "denied" && <Badge tone="red">{lang === "ar" ? "مرفوض" : "Refusé"}</Badge>}
        {gpsState === "idle" && <Badge tone="slate">—</Badge>}
      </div>
      <div className="flex gap-2">
        <Btn variant="ghost" onClick={requestGps}>{lang === "ar" ? "مشاركة الموقع" : "Partager la position"}</Btn>
        <Btn
          disabled={!stationId || !consent || gpsState !== "ok"}
          onClick={() => store.openSession(session.observerId!, stationId!)}
        >
          {t("start_shift")}
        </Btn>
      </div>
      {error && <p className="mt-2 text-xs text-red-600">{error}</p>}
      {(!stationId || !consent || gpsState !== "ok") && (
        <p className="mt-2 text-xs text-slate-400">
          {lang === "ar" ? "يتطلب بدء الوردية: تعيين مكتب + موافقة الموقع + تفعيل GPS." : "Requiert: bureau affecté + consentement + GPS actif."}
        </p>
      )}
    </Card>
  );
}

function CountingPad({ sessionId, observerId }: { sessionId: string; observerId: string }) {
  const { t, lang } = useI18n();
  const db = useDB();
  const s = db.sessions.find((x) => x.id === sessionId);
  const [lastAction, setLastAction] = useState("");
  const [queue, setQueue] = useState(0);
  const [report, setReport] = useState("");
  const posRef = useRef<number | null>(null);
  const watchRef = useRef<number | null>(null);

  // تتبع دوري أثناء الوردية (كل 60 ثانية) — يتوقف تلقائياً عند إنهاء الوردية
  useEffect(() => {
    if (!navigator.geolocation) return;
    watchRef.current = navigator.geolocation.watchPosition(
      (pos) => store.pingLocation(observerId, pos.coords.latitude, pos.coords.longitude),
      () => {},
      { enableHighAccuracy: false, maximumAge: 30000 }
    );
    const interval = setInterval(() => {
      navigator.geolocation.getCurrentPosition(
        (pos) => store.pingLocation(observerId, pos.coords.latitude, pos.coords.longitude),
        () => {}
      );
    }, 60000);
    return () => {
      if (watchRef.current !== null) navigator.geolocation.clearWatch(watchRef.current);
      clearInterval(interval);
    };
  }, [observerId]);

  // محاكاة طابور العمل دون اتصال: حفظ محلي ثم مزامنة
  useEffect(() => {
    if (queue === 0) return;
    const timer = setTimeout(() => setQueue(0), 2500);
    return () => clearTimeout(timer);
  }, [queue]);

  // عودة الاتصال (Background Sync من Service Worker) → إفراغ الطابور فوراً
  useEffect(() => {
    const onSync = () => setQueue(0);
    window.addEventListener("pollwatch:sync", onSync);
    return () => window.removeEventListener("pollwatch:sync", onSync);
  }, []);

  if (!s) return null;
  const entries = db.entries.filter((e) => e.session_id === sessionId);
  const candidates = Object.keys(s.candidate_names);

  const press = (code: string) => {
    store.addVote(sessionId, code);
    setQueue((q) => q + 1);
    setLastAction(`${s.candidate_names[code]} +1`);
    if (navigator.vibrate) navigator.vibrate(15); // تأكيد لمسي + منع الضغطات العرضية بتأخير بسيط
  };

  const endShift = () => {
    store.closeSession(sessionId);
    if (posRef.current !== null) navigator.geolocation.clearWatch(posRef.current);
  };

  return (
    <div className="space-y-4">
      <Card>
        <div className="flex items-center justify-between text-sm">
          <span className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-green-500" />
            {t("connection")}: {lang === "ar" ? "متصل" : "Connecté"} · {t("last_sync")}: {lang === "ar" ? "الآن" : "maintenant"}
          </span>
          {queue > 0 && <Badge tone="amber">{t("offline_queue")}: {queue}</Badge>}
        </div>
      </Card>

      <Card>
        <div className="mb-2 flex items-center justify-between">
          <h3 className="font-bold">{lang === "ar" ? "إدخال الفرز — بيانات مساندة" : "Saisie du dépouillement — données de soutien"}</h3>
          <Btn variant="ghost" className="!px-3 !py-1 text-xs" onClick={() => { store.revertVote(sessionId); setLastAction(lang === "ar" ? "تم التراجع عن آخر إدخال" : "Dernière saisie annulée"); }}>
            ↩ {t("revert")}
          </Btn>
        </div>
        <p className="mb-4 text-xs text-amber-600">{t("official_vs_estimate")}</p>
        <div className="grid grid-cols-3 gap-3">
          {candidates.map((code) => (
            <button
              key={code}
              onClick={() => press(code)}
              className="flex flex-col items-center justify-center rounded-2xl bg-brand py-6 text-white shadow transition active:scale-95"
            >
              <span className="text-sm font-semibold">{s.candidate_names[code]}</span>
              <span className="mt-1 text-3xl font-black tabular-nums">{s.totals[code] ?? 0}</span>
            </button>
          ))}
        </div>
        <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
          <span>{lang === "ar" ? `إجمالي الإدخالات: ${entries.length}` : `Total saisies: ${entries.length}`}</span>
          <span>{lastAction}</span>
        </div>
      </Card>

      <Card>
        <h3 className="mb-2 font-bold">{lang === "ar" ? "تقرير ميداني / محضر الفرز" : "Rapport de terrain / PV"}</h3>
        <textarea
          className="w-full rounded-xl border border-slate-300 bg-white p-3 text-sm outline-none focus:border-brand dark:border-slate-700 dark:bg-slate-900"
          rows={4}
          placeholder={lang === "ar" ? "ملاحظات الميدان، الملاحظات الاستثنائية، تفاصيل المحضر…" : "Observations terrain, incidents, détails du PV…"}
          value={report}
          onChange={(e) => setReport(e.target.value)}
        />
        <div className="mt-3 flex gap-2">
          <Btn variant="ghost" disabled={!report.trim()} onClick={() => {
            store.addReport({ author_name: db.observers.find((o) => o.id === observerId)?.full_name ?? "", station_id: s.station_id, kind: "field_report", body: report });
            setReport("");
          }}>
            {lang === "ar" ? "إرسال التقرير" : "Envoyer le rapport"}
          </Btn>
          <Btn variant="success" onClick={endShift}>✓ {lang === "ar" ? "إرسال المحضر وإنهاء الوردية" : "Envoyer le PV et terminer"}</Btn>
        </div>
        <p className="mt-2 text-xs text-slate-400">
          {lang === "ar" ? "عند الإرسال يتحول المحضر لحالة «قيد المراجعة» ولا يمكن تعديل الأعداد إلا بتراجع رئيس الحزب. يتوقف مشاركة الموقع فوراً."
            : "Après envoi, le PV passe en «soumis» et les chiffres ne sont modifiables que par retour du chef de parti. Le partage de position s'arrête immédiatement."}
        </p>
      </Card>
    </div>
  );
}

// مخزن بيانات تجريبي — يحاكي طبقة Supabase مع الامتثال لمنطق RLS على مستوى الواجهة.
// عند توفر متغيرات البيئة VITE_SUPABASE_URL يُستخدم supabase-js (الإنتاج).
import type {
  Party, PartyDomain, Member, Observer, Assistant, Station, Assignment,
  CountSession, VoteEntry, Report, LocationPing, ElectionHistory,
} from "./types";

const KEY = "pollwatch-demo-v1";

export interface DB {
  parties: Party[];
  domains: PartyDomain[];
  members: Member[];
  observers: Observer[];
  assistants: Assistant[];
  stations: Station[];
  assignments: Assignment[];
  sessions: CountSession[];
  entries: VoteEntry[];
  reports: Report[];
  pings: LocationPing[];
  history: ElectionHistory[];
}

function seed(): DB {
  const party: Party = {
    id: "p1", name_ar: "حزب النموذج", name_fr: "Parti Exemple", slug: "parti-exemple",
    status: "active", colors: { primary: "#0f766e", secondary: "#f59e0b" },
  };
  return {
    parties: [party],
    domains: [{
      id: "d1", party_id: "p1", domain: "www.parti-exemple.ma", is_primary: true,
      wildcard: false, verified: true, ssl: "issued",
    }],
    members: [
      { id: "m0", party_id: null, role: "superadmin", full_name: "المدير المركزي", status: "active" },
      { id: "m1", party_id: "p1", role: "party_admin", full_name: "رئيس الحزب", status: "active" },
      { id: "m2", party_id: "p1", role: "observer", full_name: "يوسف العلوي", status: "active" },
      { id: "m3", party_id: "p1", role: "observer", full_name: "فاطمة الزهراء مرتب", status: "active" },
      { id: "m4", party_id: "p1", role: "observer", full_name: "كريم بنعيسى", status: "active" },
    ],
    observers: [
      { id: "o1", party_id: "p1", full_name: "يوسف العلوي", phone: "0612345678", status: "active" },
      { id: "o2", party_id: "p1", full_name: "فاطمة الزهراء مرتب", phone: "0698765432", status: "active" },
      { id: "o3", party_id: "p1", full_name: "كريم بنعيسى", phone: "0655443322", status: "active" },
    ],
    assistants: [
      { id: "a1", party_id: "p1", full_name: "سعاد الإدريسي", phone: "0661112233", city: "الدار البيضاء", region: "الدار البيضاء-سطات", status: "active", admin_notes: "تنسيق لوجستي" },
      { id: "a2", party_id: "p1", full_name: "مهدي التازي", phone: "0677889900", city: "الرباط", region: "الرباط-سلا-القنيطرة", status: "active" },
    ],
    stations: [
      { id: "s1", party_id: "p1", station_number: "CASA-001", name_ar: "مكتب الحي المعاريف", city: "الدار البيضاء", region: "الدار البيضاء-سطات", lat: 33.5892, lng: -7.632, status: "open" },
      { id: "s2", party_id: "p1", station_number: "CASA-002", name_ar: "مكتب أنفا", city: "الدار البيضاء", region: "الدار البيضاء-سطات", lat: 33.615, lng: -7.611, status: "counting" },
      { id: "s3", party_id: "p1", station_number: "RBT-001", name_ar: "مكتب أكدال", city: "الرباط", region: "الرباط-سلا-القنيطرة", lat: 34.008, lng: -6.843, status: "open" },
      { id: "s4", party_id: "p1", station_number: "RBT-002", name_ar: "مكتب يعقوب المنصور", city: "الرباط", region: "الرباط-سلا-القنيطرة", lat: 34.0125, lng: -6.857, status: "planned" },
      { id: "s5", party_id: "p1", station_number: "CASA-003", name_ar: "مكتب المعاريف الشمالي", city: "الدار البيضاء", region: "الدار البيضاء-سطات", lat: 33.595, lng: -7.64, status: "report_received" },
    ],
    assignments: [
      { observer_id: "o1", station_id: "s1" },
      { observer_id: "o2", station_id: "s2" },
      { observer_id: "o3", station_id: "s3" },
    ],
    sessions: [
      {
        id: "cs1", party_id: "p1", observer_id: "o2", station_id: "s2",
        started_at: new Date(Date.now() - 40 * 60000).toISOString(),
        status: "open", totals: { c1: 142, c2: 87, blank: 6 },
        candidate_names: { c1: "القائمة أ", c2: "القائمة ب", blank: "أصوات بيضاء" },
      },
    ],
    entries: [],
    reports: [
      {
        id: "r1", party_id: "p1", author_name: "فاطمة الزهراء مرتب", station_id: "s2",
        kind: "field_report", status: "submitted",
        body: "سير عادي للفرز، الحضور الجماهيري متوسط. لا ملاحظات استثنائية.",
        submitted_at: new Date(Date.now() - 15 * 60000).toISOString(),
      },
      {
        id: "r2", party_id: "p1", author_name: "يوسف العلوي", station_id: "s1",
        kind: "count_minutes", status: "reviewed",
        body: "محضر الفرز مرفق — تطابق الأعداد مع الإدخال الميداني.",
        submitted_at: new Date(Date.now() - 120 * 60000).toISOString(),
      },
    ],
    pings: [
      { observer_id: "o1", lat: 33.5893, lng: -7.6321, recorded_at: new Date(Date.now() - 2 * 60000).toISOString() },
      { observer_id: "o3", lat: 34.0081, lng: -6.8431, recorded_at: new Date(Date.now() - 45 * 60000).toISOString() },
    ],
    history: [
      {
        year: 2021, label_ar: "انتخابات 2021",
        participation_rate: 50.35, coverage_rate: 62,
        reports_received: 340, reports_reviewed_rate: 88, avg_report_minutes: 95,
        support_votes_estimate: 15420, stations_count: 412, source: "official",
      },
      {
        year: 2026, label_ar: "انتخابات 2026 (جارية)",
        participation_rate: null, coverage_rate: 60,
        reports_received: 2, reports_reviewed_rate: 50, avg_report_minutes: 68,
        support_votes_estimate: 235, stations_count: 5, source: "entered",
      },
    ],
  };
}

function load(): DB {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw) as DB;
  } catch { /* ignore */ }
  const db = seed();
  localStorage.setItem(KEY, JSON.stringify(db));
  return db;
}

type Listener = () => void;

class Store {
  private db: DB = load();
  private listeners = new Set<Listener>();

  get data(): DB {
    return this.db;
  }
  subscribe(fn: Listener) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }
  private commit(mut: (db: DB) => void) {
    mut(this.db);
    localStorage.setItem(KEY, JSON.stringify(this.db));
    this.listeners.forEach((f) => f());
  }

  // ---- الأحزاب (Superadmin) ----
  addParty(input: { name_ar: string; slug: string }) {
    this.commit((db) => {
      const id = crypto.randomUUID();
      db.parties.push({
        id, name_ar: input.name_ar, slug: input.slug, status: "pending",
        colors: { primary: "#1d4ed8", secondary: "#f59e0b" },
      });
      db.domains.push({
        id: crypto.randomUUID(), party_id: id, domain: `www.${input.slug}.ma`,
        is_primary: true, wildcard: false, verified: false, ssl: "pending",
      });
    });
  }
  setPartyStatus(id: string, status: Party["status"]) {
    this.commit((db) => {
      const p = db.parties.find((x) => x.id === id);
      if (p) p.status = status;
    });
  }
  verifyDomain(id: string) {
    this.commit((db) => {
      const d = db.domains.find((x) => x.id === id);
      if (d) { d.verified = true; d.ssl = "issued"; }
    });
  }

  toggleMemberStatus(id: string, status: "active" | "suspended") {
    this.commit((db) => {
      const m = db.members.find((x) => x.id === id);
      if (m) m.status = status;
    });
  }

  // ---- المكاتب ----
  addStation(input: Omit<Station, "id" | "party_id" | "status"> & { status?: Station["status"] }) {
    this.commit((db) => {
      db.stations.push({ ...input, id: crypto.randomUUID(), party_id: "p1", status: input.status ?? "planned" });
    });
  }

  // ---- المراقبون والتعيينات ----
  addObserver(full_name: string, phone?: string) {
    this.commit((db) => {
      db.observers.push({ id: crypto.randomUUID(), party_id: "p1", full_name, phone, status: "active" });
    });
  }
  assignObserver(observer_id: string, station_id: string) {
    this.commit((db) => {
      db.assignments = db.assignments.filter((a) => a.observer_id !== observer_id);
      db.assignments.push({ observer_id, station_id });
    });
  }

  // ---- المساعدون ----
  addAssistant(a: Omit<Assistant, "id" | "party_id">) {
    this.commit((db) => {
      db.assistants.push({ ...a, id: crypto.randomUUID(), party_id: "p1" });
    });
  }

  // ---- جلسات الفرز ----
  openSession(observer_id: string, station_id: string): string {
    const id = crypto.randomUUID();
    this.commit((db) => {
      db.sessions.push({
        id, party_id: "p1", observer_id, station_id,
        started_at: new Date().toISOString(), status: "open",
        totals: { c1: 0, c2: 0, blank: 0 },
        candidate_names: { c1: "القائمة أ", c2: "القائمة ب", blank: "أصوات بيضاء" },
      });
    });
    return id;
  }
  addVote(session_id: string, candidate_code: string) {
    const client_id = crypto.randomUUID();
    this.commit((db) => {
      db.entries.push({ session_id, candidate_code, action: "add", client_id, created_at: new Date().toISOString() });
      const s = db.sessions.find((x) => x.id === session_id);
      if (s) s.totals[candidate_code] = (s.totals[candidate_code] ?? 0) + 1;
    });
  }
  revertVote(session_id: string) {
    this.commit((db) => {
      const s = db.sessions.find((x) => x.id === session_id);
      if (!s || s.status !== "open") return;
      const last = [...db.entries].reverse().find((e) => e.session_id === session_id && e.action === "add");
      if (!last) return;
      db.entries.push({ session_id, candidate_code: last.candidate_code, action: "revert", client_id: crypto.randomUUID(), created_at: new Date().toISOString() });
      s.totals[last.candidate_code] = Math.max(0, (s.totals[last.candidate_code] ?? 0) - 1);
    });
  }
  closeSession(session_id: string) {
    this.commit((db) => {
      const s = db.sessions.find((x) => x.id === session_id);
      if (s && s.status === "open") { s.status = "submitted"; s.ended_at = new Date().toISOString(); }
    });
  }
  reviewSession(session_id: string, status: "validated" | "returned") {
    this.commit((db) => {
      const s = db.sessions.find((x) => x.id === session_id);
      if (s) s.status = status;
    });
  }

  // ---- المواقع ----
  pingLocation(observer_id: string, lat: number, lng: number) {
    this.commit((db) => {
      db.pings = db.pings.filter((p) => p.observer_id !== observer_id);
      db.pings.push({ observer_id, lat, lng, recorded_at: new Date().toISOString() });
    });
  }

  // ---- التقارير ----
  addReport(r: Omit<Report, "id" | "party_id" | "status" | "submitted_at">) {
    this.commit((db) => {
      db.reports.unshift({ ...r, id: crypto.randomUUID(), party_id: "p1", status: "submitted", submitted_at: new Date().toISOString() });
    });
  }
  reviewReport(id: string, status: "reviewed" | "flagged") {
    this.commit((db) => {
      const r = db.reports.find((x) => x.id === id);
      if (r) r.status = status;
    });
  }

  reset() {
    this.db = seed();
    localStorage.setItem(KEY, JSON.stringify(this.db));
    this.listeners.forEach((f) => f());
  }
}

export const store = new Store();

import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { useI18n } from "../../lib/i18n";
import * as api from "../../lib/api";
import { supabase, SUPABASE_URL } from "../../lib/supabase";
import { Badge, Btn, Card, Empty, ErrorBox, Field, Loading, StatCard, TopBar, inputCls, statusTone, useLoad } from "../../shared/ui";

type Tab = "parties" | "users" | "stations" | "diagnostics";

export default function SuperadminApp({ logout }: { logout: ReactNode }) {
  const { t } = useI18n();
  const [tab, setTab] = useState<Tab>("parties");
  const tabs: { key: Tab; label: string }[] = [
    { key: "parties", label: t("parties") },
    { key: "users", label: t("users") },
    { key: "stations", label: t("stations") },
    { key: "diagnostics", label: "تشخيص" },
  ];
  return (
    <div className="min-h-screen">
      <TopBar title={`${t("app_title")} — ${t("superadmin")}`} right={logout} />
      <div className="mx-auto max-w-6xl p-4">
        <div className="mb-4 flex gap-2">
          {tabs.map((x) => (
            <button key={x.key} onClick={() => setTab(x.key)}
              className={`rounded-xl px-4 py-2 text-sm font-semibold transition ${tab === x.key ? "bg-brand text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300"}`}>
              {x.label}
            </button>
          ))}
        </div>
        {tab === "parties" && <PartiesTab />}
        {tab === "users" && <UsersTab />}
        {tab === "stations" && <StationsTab />}
        {tab === "diagnostics" && <DiagnosticsTab />}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// الأحزاب + الدومينات
// ---------------------------------------------------------------------------
function PartiesTab() {
  const { t, lang } = useI18n();
  const parties = useLoad(api.listParties);
  const domains = useLoad(api.listDomains);
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [selectedParty, setSelectedParty] = useState<api.PartyRow | null>(null);

  const domainsByParty = useMemo(() => {
    const m = new Map<string, api.DomainRow[]>();
    (domains.data ?? []).forEach((d) => {
      m.set(d.party_id, [...(m.get(d.party_id) ?? []), d]);
    });
    return m;
  }, [domains.data]);

  const run = async (fn: () => Promise<unknown>) => {
    setBusy(true); setMsg(null);
    try { await fn(); setMsg({ ok: true, text: lang === "ar" ? "تم الحفظ في Supabase" : "Enregistré dans Supabase" }); parties.reload(); domains.reload(); }
    catch (e) { setMsg({ ok: false, text: e instanceof Error ? e.message : String(e) }); }
    finally { setBusy(false); }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <StatCard label={t("parties")} value={parties.data?.length ?? "…"} />
        <StatCard label={t("domains")} value={domains.data?.length ?? "…"} tone="blue" />
      </div>

      {parties.error && <ErrorBox message={parties.error} onRetry={parties.reload} />}
      {msg && <div className={`rounded-xl px-4 py-2 text-sm ${msg.ok ? "bg-green-50 text-green-700 dark:bg-green-950/60" : "bg-red-50 text-red-700 dark:bg-red-950/60"}`}>{msg.ok ? "✓ " : "⚠ "}{msg.text}</div>}

      <Card>
        <h3 className="mb-3 font-bold">{t("add_party")}</h3>
        <div className="grid gap-3 md:grid-cols-3">
          <Field label="اسم الحزب"><input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} /></Field>
          <Field label="Slug">
            <input dir="ltr" className={inputCls} value={slug} onChange={(e) => setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ""))} placeholder="parti-exemple" />
            <p className="mt-1 text-xs text-slate-400">بالإنجليزية فقط، مثل: parti-independance</p>
          </Field>
          <Field label="بريد رئيس الحزب">
            <input type="email" dir="ltr" className={inputCls} value={email} onChange={(e) => setEmail(e.target.value)} placeholder="president@example.com" />
          </Field>
          <Field label="كلمة سر رئيس الحزب">
            <input type="password" dir="ltr" className={inputCls} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="8 أحرف على الأقل" />
          </Field>
          <div className="flex items-end">
            <Btn
              disabled={!name.trim() || !slug.trim() || !email.trim() || password.length < 8 || busy}
              onClick={() => run(async () => {
                const finalSlug = slug.trim() || `party-${Date.now().toString().slice(-6)}`;
                await api.createParty({ name_ar: name.trim(), slug: finalSlug, email: email.trim(), password });
                setName(""); setSlug(""); setEmail(""); setPassword("");
              })}
            >{t("save")}</Btn>
          </div>
        </div>
      </Card>

      {selectedParty && (
        <Card>
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 className="font-bold">معلومات الحزب: {selectedParty.name_ar}</h3>
              <p className="mt-2 text-sm text-slate-500">Slug: {selectedParty.slug}</p>
              <p className="text-sm text-slate-500">الحالة: {selectedParty.status}</p>
              <p className="text-sm text-slate-500">المعرّف: {selectedParty.id}</p>
            </div>
            <Btn variant="ghost" onClick={() => setSelectedParty(null)}>إغلاق</Btn>
          </div>
        </Card>
      )}

      {parties.loading ? <Loading /> : (parties.data?.length ?? 0) === 0 ? <Empty label={lang === "ar" ? "لا توجد أحزاب بعد" : "Aucun parti"} /> :
        parties.data!.map((p) => (
          <Card key={p.id}>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl font-bold text-white" style={{ background: p.colors?.primary ?? "#0f766e" }}>
                  {p.name_ar.slice(0, 1)}
                </div>
                <button type="button" className="text-start" onClick={() => setSelectedParty(p)} title="عرض معلومات الحزب">
                  <div className="font-bold hover:text-brand">{p.name_ar} {p.name_fr && <span className="text-sm text-slate-400">({p.name_fr})</span>}</div>
                  <div className="text-xs text-slate-400">{p.slug}.ma</div>
                </button>
              </div>
              <div className="flex items-center gap-2">
                <Badge tone={statusTone(p.status)}>{p.status}</Badge>
                {p.status !== "active"
                  ? <Btn variant="success" className="!px-3 !py-1 text-xs" disabled={busy} onClick={() => run(() => api.setPartyStatus(p.id, "active"))}>تفعيل</Btn>
                  : <Btn variant="danger" className="!px-3 !py-1 text-xs" disabled={busy} onClick={() => run(() => api.setPartyStatus(p.id, "suspended"))}>تعطيل</Btn>}
                <Btn variant="ghost" className="!px-3 !py-1 text-xs text-red-600" disabled={busy} onClick={() => {
                  if (window.confirm(`حذف الحزب ${p.name_ar} وحساب رئيسه نهائياً؟`)) run(() => api.deleteParty(p.id));
                }}>حذف الحساب</Btn>
              </div>
            </div>
            <div className="mt-3 space-y-2 border-t border-slate-100 pt-3 dark:border-slate-800">
              {(domainsByParty.get(p.id) ?? []).map((d) => (
                <div key={d.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-slate-50 px-3 py-2 text-sm dark:bg-slate-800/60">
                  <span dir="ltr">{d.domain}</span>
                  <div className="flex items-center gap-2">
                    <Badge tone={d.verified_at ? "green" : "amber"}>{d.verified_at ? "مُتحقق (DNS)" : "قيد التحقق"}</Badge>
                    <Badge tone={statusTone(d.ssl_status)}>SSL: {d.ssl_status}</Badge>
                    {!d.verified_at && (
                      <Btn variant="ghost" className="!px-3 !py-1 text-xs" disabled={busy}
                        onClick={() => run(async () => {
                          const r = await api.verifyDomain(d.id);
                          if (r && r.verified === false) throw new Error(r.hint ?? "DNS غير صحيح");
                          if (r && r.error) throw new Error(r.error);
                        })}>
                        تحقق DNS
                      </Btn>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        ))}
    </div>
  );
}

// ---------------------------------------------------------------------------
// المستخدمون + الأدوار
// ---------------------------------------------------------------------------
function UsersTab() {
  const { t, lang } = useI18n();
  const members = useLoad(api.listMembers);
  const roles = useLoad(api.listRoles);
  const parties = useLoad(api.listParties);
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const roleKey = useMemo(() => {
    const m = new Map((roles.data ?? []).map((r) => [r.id, r.key]));
    return (id: string) => m.get(id) ?? "—";
  }, [roles.data]);
  const partyName = useMemo(() => {
    const m = new Map((parties.data ?? []).map((p) => [p.id, p.name_ar]));
    return (id: string | null) => (id ? (m.get(id) ?? "—") : "—");
  }, [parties.data]);

  const rows = (members.data ?? []).filter((m) => m.full_name.includes(q) || roleKey(m.role_id).includes(q));
  const toggle = async (m: api.MemberRow) => {
    setBusy(true); setErr(null);
    try { await api.setMemberStatus(m.id, m.status === "active" ? "suspended" : "active"); members.reload(); }
    catch (e) { setErr(e instanceof Error ? e.message : String(e)); }
    finally { setBusy(false); }
  };

  return (
    <Card>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <h3 className="font-bold">{t("users")}</h3>
        <input className={`${inputCls} max-w-xs`} placeholder={t("search")} value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      {members.error && <ErrorBox message={members.error} onRetry={members.reload} />}
      {err && <ErrorBox message={err} />}
      {members.loading ? <Loading /> : rows.length === 0 ? <Empty label={lang === "ar" ? "لا يوجد مستخدمون" : "Aucun utilisateur"} /> : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-start text-slate-400 dark:border-slate-800">
                <th className="p-2 text-start">{t("name")}</th>
                <th className="p-2 text-start">الدور</th>
                <th className="p-2 text-start">الحزب</th>
                <th className="p-2 text-start">{t("status")}</th>
                <th className="p-2 text-start">{t("actions")}</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((m) => (
                <tr key={m.id} className="border-b border-slate-100 dark:border-slate-800/60">
                  <td className="p-2 font-medium">{m.full_name}</td>
                  <td className="p-2"><Badge tone={roleKey(m.role_id) === "superadmin" ? "violet" : "blue"}>{roleKey(m.role_id)}</Badge></td>
                  <td className="p-2 text-slate-500">{partyName(m.party_id)}</td>
                  <td className="p-2"><Badge tone={statusTone(m.status)}>{m.status}</Badge></td>
                  <td className="p-2">
                    <Btn variant="ghost" className="!px-3 !py-1 text-xs" disabled={busy} onClick={() => toggle(m)}>
                      {m.status === "active" ? "تعطيل" : "تفعيل"}
                    </Btn>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}

// ---------------------------------------------------------------------------
// مكاتب الاقتراع (كل الأحزاب) + منتقي الخريطة
// ---------------------------------------------------------------------------
function MapPicker({ lat, lng, onPick }: { lat: number | null; lng: number | null; onPick: (lat: number, lng: number) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);
  useEffect(() => {
    if (!ref.current || mapRef.current) return;
    const map = L.map(ref.current).setView(lat != null && lng != null ? [lat, lng] : [33.8, -7.2], lat != null ? 13 : 8);
    L.tileLayer("https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png", { attribution: "© OSM © CARTO", maxZoom: 19 }).addTo(map);
    map.on("click", (e: L.LeafletMouseEvent) => {
      const { lat: la, lng: ln } = e.latlng;
      onPick(+la.toFixed(6), +ln.toFixed(6));
    });
    mapRef.current = map;
    setTimeout(() => map.invalidateSize(), 50);
    return () => { map.remove(); mapRef.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    if (lat != null && lng != null) {
      markerRef.current?.remove();
      markerRef.current = L.marker([lat, lng], { draggable: true })
        .on("dragend", () => {
          const p = markerRef.current!.getLatLng();
          onPick(+p.lat.toFixed(6), +p.lng.toFixed(6));
        })
        .addTo(map);
      map.setView([lat, lng], Math.max(map.getZoom(), 13));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lat, lng]);
  return <div ref={ref} style={{ touchAction: "auto", pointerEvents: "auto" }} className="relative z-0 h-64 w-full rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden" />;
}

function StationsTab() {
  const { t, lang } = useI18n();
  const stations = useLoad(() => api.listStations(null));
  const parties = useLoad(api.listParties);
  const [q, setQ] = useState("");
  const [editing, setEditing] = useState<api.StationRow | "new" | null>(null);
  const [form, setForm] = useState({ party_id: "", station_number: "", name_ar: "", city: "", region: "", lat: null as number | null, lng: null as number | null });
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const rows = (stations.data ?? []).filter((s) => s.station_number.includes(q) || s.name_ar.includes(q) || (s.city ?? "").includes(q));

  const openNew = () => {
    const firstParty = parties.data?.[0];
    setForm({ party_id: firstParty?.id ?? "", station_number: "", name_ar: "", city: "", region: "", lat: null, lng: null });
    setEditing("new");
  };
  const openEdit = (s: api.StationRow) => {
    setForm({ party_id: s.party_id, station_number: s.station_number, name_ar: s.name_ar, city: s.city ?? "", region: s.region ?? "", lat: s.lat, lng: s.lng });
    setEditing(s);
  };
  const save = async () => {
    setBusy(true); setMsg(null);
    try {
      if (editing === "new") {
        await api.createStation({ party_id: form.party_id, station_number: form.station_number, name_ar: form.name_ar, city: form.city, region: form.region, lat: form.lat ?? undefined, lng: form.lng ?? undefined });
      } else if (editing) {
        await api.updateStation(editing.id, { station_number: form.station_number, name_ar: form.name_ar, city: form.city, region: form.region, lat: form.lat, lng: form.lng });
      }
      setMsg({ ok: true, text: lang === "ar" ? "تم الحفظ في Supabase" : "Enregistré" });
      setEditing(null);
      stations.reload();
    } catch (e) { setMsg({ ok: false, text: e instanceof Error ? e.message : String(e) }); }
    finally { setBusy(false); }
  };
  const remove = async (s: api.StationRow) => {
    if (!window.confirm(lang === "ar" ? `حذف المكتب ${s.station_number}؟` : `Supprimer ${s.station_number} ?`)) return;
    setBusy(true);
    try { await api.deleteStation(s.id); stations.reload(); }
    catch (e) { setMsg({ ok: false, text: e instanceof Error ? e.message : String(e) }); }
    finally { setBusy(false); }
  };

  const partyName = (id: string) => parties.data?.find((p) => p.id === id)?.name_ar ?? "—";

  return (
    <div className="space-y-4">
      {stations.error && <ErrorBox message={stations.error} onRetry={stations.reload} />}
      {msg && <div className={`rounded-xl px-4 py-2 text-sm ${msg.ok ? "bg-green-50 text-green-700 dark:bg-green-950/60" : "bg-red-50 text-red-700 dark:bg-red-950/60"}`}>{msg.ok ? "✓ " : "⚠ "}{msg.text}</div>}
      <Card>
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <h3 className="font-bold">{t("stations")} ({stations.data?.length ?? "…"})</h3>
          <div className="flex gap-2">
            <input className={`${inputCls} max-w-xs`} placeholder={t("search")} value={q} onChange={(e) => setQ(e.target.value)} />
            <Btn onClick={openNew}>+ {t("add_station")}</Btn>
          </div>
        </div>
        {stations.loading ? <Loading /> : rows.length === 0 ? <Empty label={lang === "ar" ? "لا توجد مكاتب" : "Aucun bureau"} /> : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-slate-400 dark:border-slate-800">
                  <th className="p-2 text-start">{t("station_number")}</th>
                  <th className="p-2 text-start">{t("name")}</th>
                  <th className="p-2 text-start">الحزب</th>
                  <th className="p-2 text-start">{t("city")}</th>
                  <th className="p-2 text-start">الإحداثيات</th>
                  <th className="p-2 text-start">{t("status")}</th>
                  <th className="p-2 text-start">{t("actions")}</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((s) => (
                  <tr key={s.id} className="border-b border-slate-100 dark:border-slate-800/60">
                    <td className="p-2 font-mono">{s.station_number}</td>
                    <td className="p-2">{s.name_ar}</td>
                    <td className="p-2 text-slate-500">{partyName(s.party_id)}</td>
                    <td className="p-2">{s.city} — {s.region}</td>
                    <td className="p-2 text-xs text-slate-400" dir="ltr">{s.lat != null ? `${s.lat}, ${s.lng}` : "—"}</td>
                    <td className="p-2"><Badge tone={statusTone(s.status)}>{s.status}</Badge></td>
                    <td className="p-2">
                      <div className="flex gap-1">
                        <Btn variant="ghost" className="!px-3 !py-1 text-xs" onClick={() => openEdit(s)}>تعديل</Btn>
                        <Btn variant="danger" className="!px-3 !py-1 text-xs" disabled={busy} onClick={() => remove(s)}>حذف</Btn>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {editing && (
        <Card>
          <h3 className="mb-3 font-bold">{editing === "new" ? t("add_station") : `تعديل ${editing.station_number}`}</h3>
          <div className="grid gap-3 md:grid-cols-3">
            {editing === "new" && (
              <Field label="الحزب">
                <select className={inputCls} value={form.party_id} onChange={(e) => setForm({ ...form, party_id: e.target.value })}>
                  {(parties.data ?? []).map((p) => <option key={p.id} value={p.id}>{p.name_ar}</option>)}
                </select>
              </Field>
            )}
            <Field label={t("station_number")}><input className={inputCls} value={form.station_number} onChange={(e) => setForm({ ...form, station_number: e.target.value })} /></Field>
            <Field label={t("name")}><input className={inputCls} value={form.name_ar} onChange={(e) => setForm({ ...form, name_ar: e.target.value })} /></Field>
            <Field label={t("city")}><input className={inputCls} value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></Field>
            <Field label={t("region")}><input className={inputCls} value={form.region} onChange={(e) => setForm({ ...form, region: e.target.value })} /></Field>
            <Field label="lat / lng">
              <input className={inputCls} readOnly dir="ltr" value={form.lat != null ? `${form.lat}, ${form.lng}` : (lang === "ar" ? "انقر على الخريطة" : "Cliquez sur la carte")} />
            </Field>
          </div>
          <div className="mt-3">
            <MapPicker lat={form.lat} lng={form.lng} onPick={(la, ln) => setForm({ ...form, lat: la, lng: ln })} />
            <p className="mt-1 text-xs text-slate-400">{lang === "ar" ? "انقر لتحديد الموقع، أو اسحب العلامة للضبط." : "Cliquez pour placer, ou glissez le marqueur."}</p>
          </div>
          <div className="mt-3 flex gap-2">
            <Btn disabled={busy || !form.station_number || !form.name_ar || !form.party_id} onClick={save}>{t("save")}</Btn>
            <Btn variant="ghost" onClick={() => setEditing(null)}>{t("cancel")}</Btn>
          </div>
        </Card>
      )}
    </div>
  );
}


function DiagnosticsTab() {
  const [running, setRunning] = useState(false);
  const [results, setResults] = useState<{name:string; ok:boolean; detail:string}[]>([]);
  const [manualLat, setManualLat] = useState(33.8);
  const [manualLng, setManualLng] = useState(-7.2);

  // استدعاء دالة واحدة مع تقرير كامل: الاسم، الرابط (بلا أي مفتاح سري)، HTTP status، نص الرد، الخطأ الحقيقي
  const probeFunction = async (fnName: string, body: Record<string, unknown>) => {
    const invokeUrl = `${SUPABASE_URL}/functions/v1/${fnName}`;
    try {
      const { data, error } = await supabase.functions.invoke(fnName, { body });
      if (error) {
        const ctx = (error as { context?: { status?: number; body?: unknown } }).context ?? {};
        const status = ctx.status ?? "غير معروف";
        const respBody = typeof ctx.body === "string" ? ctx.body : ctx.body ? JSON.stringify(ctx.body) : "—";
        return { ok: false, text:
          `الدالة: ${fnName}\nالرابط: ${invokeUrl}\nHTTP: ${status}\nرد Supabase: ${respBody}\nالخطأ: ${error.message}` };
      }
      return { ok: true, text: `الدالة: ${fnName}\nالرابط: ${invokeUrl}\nHTTP: 2xx\nالرد: ${JSON.stringify(data)}` };
    } catch (e) {
      return { ok: false, text: `الدالة: ${fnName}\nالرابط: ${invokeUrl}\nاستثناء: ${e instanceof Error ? e.message : String(e)}` };
    }
  };

  const runDiagnostics = async () => {
    setRunning(true); setResults([]);
    const out: {name:string; ok:boolean; detail:string}[] = [];
    const add = (name:string, ok:boolean, detail:string) => out.push({name,ok,detail});
    try {
      const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
      add("جلسة Supabase", !sessionError && !!sessionData?.session?.access_token,
        sessionError?.message ?? (sessionData?.session ? "جلسة صالحة والتوكن موجود" : "لا توجد جلسة نشطة"));
      if (sessionData?.session) {
        for (const name of ["my_role_key", "my_member_id", "my_party_id", "is_superadmin"]) {
          const { data, error } = await supabase.rpc(name);
          add(`RPC ${name}`, !error, error?.message ?? `النتيجة: ${JSON.stringify(data)}`);
        }
        // اختبار الدوال الثلاث — يُرسل body ناقص عمداً لقياس وصول الواجهة للدالة وصلاحياتها فقط
        const r1 = await probeFunction("create-party-admin", {});
        add("Edge: create-party-admin", r1.ok, r1.text);
        const r2 = await probeFunction("delete-party-admin", {});
        add("Edge: delete-party-admin", r2.ok, r2.text);
        const r3 = await probeFunction("verify-domain", {});
        add("Edge: verify-domain", r3.ok, r3.text);
      }
      const { error: partiesError } = await supabase.from("parties").select("id").limit(1);
      add("قراءة جدول parties", !partiesError, partiesError?.message ?? "نجحت القراءة");
      const { error: stationsError } = await supabase.from("stations_view").select("id").limit(1);
      add("قراءة stations_view", !stationsError, stationsError?.message ?? "نجحت القراءة");
    } catch (e) {
      add("خطأ عام", false, e instanceof Error ? e.message : String(e));
    }
    setResults(out); setRunning(false);
  };

  return <div className="space-y-4">
    <Card>
      <h3 className="mb-2 font-bold">تشخيص الاتصال والصلاحيات</h3>
      <p className="mb-3 text-sm text-slate-500">يرسل بيانات ناقصة إلى الدوال فقط لقياس الوصول والصلاحيات — لا يغيّر أي بيانات.</p>
      <Btn disabled={running} onClick={runDiagnostics}>{running ? "جارٍ الفحص…" : "بدء التشخيص"}</Btn>
      {results.length > 0 && <div className="mt-4 space-y-2">{results.map((r,i)=><div key={i} className={`rounded-xl p-3 text-sm ${r.ok ? "bg-green-50 text-green-800 dark:bg-green-950/40 dark:text-green-200" : "bg-red-50 text-red-800 dark:bg-red-950/40 dark:text-red-200"}`}><div className="font-bold">{r.ok ? "✓" : "✕"} {r.name}</div><div className="mt-1 whitespace-pre-wrap break-words font-mono text-xs">{r.detail}</div></div>)}</div>}
    </Card>
    <Card>
      <h3 className="mb-2 font-bold">اختبار إحداثيات الخريطة</h3>
      <p className="text-sm text-slate-500">إذا لم تستجب الخريطة، يمكنك استعمال هذه الإحداثيات مؤقتًا في نموذج المكتب. القيم الافتراضية تقريبية للمغرب.</p>
      <div className="mt-3 grid gap-3 md:grid-cols-2"><Field label="Latitude"><input className={inputCls} type="number" step="0.000001" value={manualLat} onChange={e=>setManualLat(Number(e.target.value))}/></Field><Field label="Longitude"><input className={inputCls} type="number" step="0.000001" value={manualLng} onChange={e=>setManualLng(Number(e.target.value))}/></Field></div>
      <div className="mt-3 rounded-xl bg-slate-100 p-3 text-sm dark:bg-slate-800" dir="ltr">{manualLat}, {manualLng}</div>
      <p className="mt-2 text-xs text-slate-500">التشخيص يسجل المشكلة فقط؛ لا يغيّر بيانات قاعدة البيانات.</p>
    </Card>
  </div>;
}

// PollWatch Service Worker — عمل دون اتصال
// استراتيجية: app shell (cache-first)، بيانات (network-first مع تمرير)
// v2: يجب رفع الرقم مع كل إصدار يغيّر منطق الاستدعاء —
// عند التفعيل تُحذف كل الكاشات القديمة وتُحمَّل الحزمة المصححة.
const CACHE = "pollwatch-v2";
const SHELL = ["./", "./index.html", "./manifest.webmanifest", "./icon-192.png", "./icon-512.png"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== "GET") return;

  // البلاطات والخطوط الخارجية: cache-first مع تحديث خلفي
  if (url.hostname.includes("tile") || url.hostname.includes("basemaps") || url.hostname.includes("unpkg")) {
    e.respondWith(
      caches.open(CACHE).then(async (cache) => {
        const hit = await cache.match(e.request);
        const net = fetch(e.request).then((res) => {
          if (res.ok) cache.put(e.request, res.clone());
          return res;
        }).catch(() => hit);
        return hit || net;
      })
    );
    return;
  }

  // باقي الطلبات (API/Supabase لاحقاً): network-first
  e.respondWith(
    fetch(e.request)
      .then((res) => {
        if (res.ok && (url.origin === location.origin)) {
          const clone = res.clone();
          caches.open(CACHE).then((c) => c.put(e.request, clone));
        }
        return res;
      })
      .catch(async () => {
        const hit = await caches.match(e.request);
        if (hit) return hit;
        if (e.request.mode === "navigate") return caches.match("./index.html");
        return Response.error();
      })
  );
});

// Background Sync: إعادة محاولة إرسال ما في الطابور عند عودة الاتصال
self.addEventListener("sync", (e) => {
  if (e.tag === "pollwatch-sync") {
    e.waitUntil(
      self.clients.matchAll().then((clients) =>
        clients.forEach((c) => c.postMessage({ type: "SYNC_NOW" }))
      )
    );
  }
});

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, "Content-Type": "application/json" },
  });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ success: false, error: "method_not_allowed" }, 405);

  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const token = authHeader.replace(/^Bearer\s+/i, "").trim();
    if (!token) return json({ success: false, error: "يجب تسجيل الدخول أولاً" }, 401);

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? Deno.env.get("SERVICE_ROLE_KEY");
    if (!supabaseUrl || !anonKey || !serviceKey) return json({ success: false, error: "إعدادات Supabase السرية ناقصة" }, 500);

    // التحقق من صاحب الجلسة باستعمال JWT المرسل من الواجهة.
    const authClient = createClient(supabaseUrl, anonKey);
    const { data: userData, error: userError } = await authClient.auth.getUser(token);
    if (userError || !userData.user) return json({ success: false, error: "جلسة الدخول غير صالحة" }, 401);

    // استعمال service role لقراءة صلاحية المدير بدون الوقوع في RLS recursion.
    const admin = createClient(supabaseUrl, serviceKey);
    const { data: member, error: memberError } = await admin
      .from("party_members")
      .select("id, role_id, status, roles!inner(key)")
      .eq("user_id", userData.user.id)
      .eq("status", "active")
      .eq("roles.key", "superadmin")
      .limit(1)
      .maybeSingle();

    if (memberError) return json({ success: false, error: memberError.message }, 500);
    if (!member) return json({ success: false, error: "ليس لديك صلاحية المدير المركزي" }, 403);

    // قبول الاسماء القديمة والجديدة للحقول معاً (name_ar/name, email/president_email, password/president_password)
    let body: Record<string, unknown>;
    try { body = await req.json(); }
    catch { return json({ success: false, error: "body غير صالح (JSON مطلوب)" }, 400); }

    const name_ar = String(body.name_ar ?? body.name ?? "").trim();
    const slug = String(body.slug ?? "").trim().toLowerCase();
    const email = String(body.email ?? body.president_email ?? "").trim().toLowerCase();
    const password = String(body.password ?? body.president_password ?? "");
    if (!name_ar || !slug || !email || password.length < 8) {
      return json({ success: false, error: "اسم الحزب وSlug والبريد وكلمة السر (8 أحرف على الأقل) مطلوبة" }, 400);
    }
    if (!/^[a-z0-9-]+$/.test(slug)) return json({ success: false, error: "Slug يجب أن يحتوي على أحرف إنجليزية وأرقام وشرطة فقط" }, 400);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({ success: false, error: "صيغة البريد الإلكتروني غير صحيحة" }, 400);

    // منع slug مكرر قبل أي إدراج
    const { data: existingSlug } = await admin.from("parties").select("id").eq("slug", slug).limit(1).maybeSingle();
    if (existingSlug) return json({ success: false, error: `slug مستعمل مسبقاً: ${slug}` }, 409);

    const { data: role, error: roleLookupError } = await admin
      .from("roles").select("id").eq("key", "party_admin").single();
    if (roleLookupError) return json({ success: false, error: roleLookupError.message }, 500);

    const { data: party, error: partyError } = await admin
      .from("parties").insert({ name_ar, slug, status: "pending" }).select("id").single();
    if (partyError) return json({ success: false, error: partyError.message }, 400);

    const { error: domainError } = await admin.from("party_domains").insert({
      party_id: party.id, domain: `www.${slug}.ma`, is_primary: true, wildcard: false,
      verification_token: crypto.randomUUID(), ssl_status: "pending",
    });
    if (domainError) {
      await admin.from("parties").delete().eq("id", party.id);
      return json({ success: false, error: domainError.message }, 400);
    }

    const { data: created, error: createUserError } = await admin.auth.admin.createUser({
      email, password, email_confirm: true,
      user_metadata: { full_name: name_ar, role: "party_admin", party_id: party.id },
    });
    if (createUserError || !created.user) {
      await admin.from("party_domains").delete().eq("party_id", party.id);
      await admin.from("parties").delete().eq("id", party.id);
      return json({ success: false, error: createUserError?.message ?? "تعذر إنشاء المستخدم" }, 400);
    }

    const { error: insertMemberError } = await admin.from("party_members").insert({
      party_id: party.id, user_id: created.user.id, role_id: role.id,
      full_name: name_ar, status: "active",
    });
    if (insertMemberError) {
      await admin.auth.admin.deleteUser(created.user.id);
      await admin.from("party_domains").delete().eq("party_id", party.id);
      await admin.from("parties").delete().eq("id", party.id);
      return json({ success: false, error: insertMemberError.message }, 400);
    }

    return json({ success: true, ok: true, data: { party_id: party.id, user_id: created.user.id } });
  } catch (e) {
    console.error("[create-party-admin] خطأ غير متوقع:", e);
    return json({ success: false, error: e instanceof Error ? e.message : String(e) }, 500);
  }
});

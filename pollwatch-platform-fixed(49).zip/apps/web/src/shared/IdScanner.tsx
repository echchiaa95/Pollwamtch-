import { useEffect, useState } from "react";
import { Html5Qrcode } from "html5-qrcode";
import { Modal } from "./ui";

// استخراج معلومات من نص باركود البطاقة المغربية (PDF417)
export function parseIdText(raw: string): { idNumber?: string; fullName?: string } {
  const idNumber = raw.match(/[A-Z]{1,2}\d{6,8}/)?.[0];
  const nameLine = raw.split(/[\n\r|]+/).map((l) => l.trim())
    .find((l) => /^[A-Za-zÀ-ÿ' -]{6,}$/.test(l) && l.split(" ").length >= 2 && !/\d/.test(l));
  return { idNumber, fullName: nameLine };
}

/** ماسح باركود البطاقة الوطنية — يملأ المعلومات تلقائياً عند النجاح */
export default function IdScannerModal({ open, onClose, onResult }: {
  open: boolean; onClose: () => void;
  onResult: (parsed: { idNumber?: string; fullName?: string }, raw: string) => void;
}) {
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    let alive = true;
    const scanner = new Html5Qrcode("pw-id-reader");
    scanner.start(
      { facingMode: "environment" },
      { fps: 10, qrbox: { width: 280, height: 160 } },
      (text) => {
        if (!alive) return;
        alive = false;
        scanner.stop().catch(() => {}).then(() => {
          onResult(parseIdText(text), text);
          onClose();
        });
      },
      () => {}
    ).catch((e) => setErr(String(e)));
    return () => {
      alive = false;
      scanner.stop().catch(() => {}).then(() => scanner.clear()).catch(() => {});
    };
  }, [open]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <Modal open={open} onClose={onClose} title="مسح باركود البطاقة الوطنية">
      <p className="mb-3 text-sm text-slate-400">وجّه الكاميرا نحو الباركود (PDF417) على ظهر البطاقة — ستمتلئ الخانات تلقائياً.</p>
      {err && <p className="mb-2 text-sm text-red-400">تعذّر فتح الكاميرا: {err} (تحقق من الصلاحية)</p>}
      <div id="pw-id-reader" className="w-full overflow-hidden rounded-xl border border-slate-700" />
    </Modal>
  );
}

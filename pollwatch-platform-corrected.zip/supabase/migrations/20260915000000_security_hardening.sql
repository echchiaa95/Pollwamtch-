-- ============================================================================
-- 20260913_security_hardening.sql
-- إصلاحات RLS أساسية: عزل الحزب، منع تصعيد الصلاحيات، وتقييد المراقب
-- ============================================================================

begin;

-- ---------------------------------------------------------------------------
-- 1) دوال السياق: لا نعتمد على party_id في JWT وحده
-- ---------------------------------------------------------------------------

create or replace function public.my_party_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$
  select pm.party_id
  from public.party_members pm
  join public.roles r on r.id = pm.role_id
  where pm.user_id = auth.uid()
    and pm.status = 'active'
    and pm.party_id is not null
    and r.key <> 'superadmin'
  order by pm.created_at asc
  limit 1
$$;

create or replace function public.my_role_key()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select r.key
  from public.party_members pm
  join public.roles r on r.id = pm.role_id
  where pm.user_id = auth.uid()
    and pm.status = 'active'
    and (
      r.key = 'superadmin'
      or pm.party_id = public.my_party_id()
    )
  order by case r.key
    when 'superadmin' then 0
    when 'party_admin' then 1
    when 'assistant' then 2
    when 'observer' then 3
    else 9
  end
  limit 1
$$;

create or replace function public.has_permission(p_key text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select public.is_superadmin()
    or exists (
      select 1
      from public.party_members pm
      where pm.user_id = auth.uid()
        and pm.party_id = public.my_party_id()
        and pm.status = 'active'
        and (
          (pm.permissions ? p_key)
          or exists (
            select 1
            from public.roles r
            where r.id = pm.role_id
              and r.key = 'party_admin'
          )
        )
    )
$$;

-- ---------------------------------------------------------------------------
-- 2) إزالة السياسات المتعارضة التي كانت تسمح بتجاوز المنع
-- ---------------------------------------------------------------------------

drop policy if exists members_insert on public.party_members;
drop policy if exists members_update on public.party_members;
drop policy if exists members_no_privesc on public.party_members;
drop policy if exists stations_select on public.polling_stations;
drop policy if exists sessions_update_own on public.count_sessions;
drop policy if exists sessions_review on public.count_sessions;
drop policy if exists metrics_write on public.support_metrics;

-- ---------------------------------------------------------------------------
-- 3) party_members: منع إنشاء/تعديل superadmin من داخل الحزب
-- ---------------------------------------------------------------------------

create policy members_update_hardened
on public.party_members
for update
using (
  public.is_superadmin()
  or (
    party_id = public.my_party_id()
    and public.my_role_key() = 'party_admin'
  )
)
with check (
  public.is_superadmin()
  or (
    party_id = public.my_party_id()
    and public.my_role_key() = 'party_admin'
    and role_id in (
      select r.id
      from public.roles r
      where r.key <> 'superadmin'
    )
  )
);

create policy members_insert_hardened
on public.party_members
for insert
with check (
  public.is_superadmin()
  or (
    party_id = public.my_party_id()
    and public.my_role_key() = 'party_admin'
    and role_id in (
      select r.id
      from public.roles r
      where r.key <> 'superadmin'
    )
  )
);

-- ---------------------------------------------------------------------------
-- 4) المراقب يرى المكاتب المعيّن بها فقط
-- ---------------------------------------------------------------------------

create policy stations_select_hardened
on public.polling_stations
for select
using (
  public.is_superadmin()
  or (
    party_id = public.my_party_id()
    and public.my_role_key() in ('party_admin', 'assistant')
  )
  or exists (
    select 1
    from public.observer_assignments oa
    where oa.polling_station_id = polling_stations.id
      and oa.observer_id = public.my_observer_id()
      and oa.party_id = public.my_party_id()
  )
);

-- ---------------------------------------------------------------------------
-- 5) count_sessions: المراقب لا يغيّر ملكية الجلسة أو totals
-- ---------------------------------------------------------------------------

create policy sessions_update_own_hardened
on public.count_sessions
for update
using (
  party_id = public.my_party_id()
  and observer_id = public.my_observer_id()
  and status in ('open', 'submitted')
)
with check (
  party_id = public.my_party_id()
  and observer_id = public.my_observer_id()
  and status in ('open', 'submitted')
);

create policy sessions_review_hardened
on public.count_sessions
for update
using (
  party_id = public.my_party_id()
  and public.my_role_key() = 'party_admin'
  and status = 'submitted'
)
with check (
  party_id = public.my_party_id()
  and public.my_role_key() = 'party_admin'
  and status in ('validated', 'returned')
);

-- ---------------------------------------------------------------------------
-- 6) support_metrics: القراءة لأعضاء الحزب، والكتابة للإدارة فقط
-- ---------------------------------------------------------------------------

create policy metrics_write_hardened
on public.support_metrics
for all
using (
  public.is_superadmin()
  or (
    party_id = public.my_party_id()
    and public.my_role_key() = 'party_admin'
  )
)
with check (
  public.is_superadmin()
  or (
    party_id = public.my_party_id()
    and public.my_role_key() = 'party_admin'
  )
);

commit;

import { useMemo } from "react";
import { useI18n } from "../../lib/i18n";
import { store } from "../../lib/store";
import type { ElectionHistory, SourceType } from "../../lib/types";
import { Badge, Btn, Card, StatCard, useDB } from "../../shared/ui";

const srcTone: Record<SourceType, string> = {
  official: "green", entered: "blue", estimate: "amber", under_review: "red",
};
const srcLabel: Record<SourceType, { ar: string; fr: string }> = {
  official: { ar: "رسمي", fr: "Officiel" },
  entered: { ar: "مدخل", fr: "Saisi" },
  estimate: { ar: "تقديري", fr: "Estimé" },
  under_review: { ar: "قيد المراجعة", fr: "En révision" },
};

function downloadCSV(filename: string, rows: (string | number)[][]) {
  const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" }); // BOM للعربية في Excel
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

// رسم أعمدة SVG خفيف بدون مكتبات
function Bars({ data, max, unit }: {
  data: { label: string; value: number | null; color: string; sub?: string }[];
  max: number; unit: string;
}) {
  const W = 520, H = 200, pad = 30;
  const bw = (W - pad * 2) / data.length;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full">
      {[0.25, 0.5, 0.75, 1].map((f) => (
        <g key={f}>
          <line x1={pad} x2={W - pad} y1={H - 40 - f * (H - 70)} y2={H - 40 - f * (H - 70)} stroke="#94a3b8" strokeOpacity=".25" strokeDasharray="3" />
          <text x={pad - 5} y={H - 36 - f * (H - 70)} fontSize="9" fill="#94a3b8" textAnchor="end">{Math.round(max * f)}{unit}</text>
        </g>
      ))}
      {data.map((d, i) => {
        const h = d.value === null ? 0 : (d.value / max) * (H - 70);
        const x = pad + i * bw + bw * 0.2;
        return (
          <g key={i}>
            <rect x={x} y={H - 40 - h} width={bw * 0.6} height={h} rx="4" fill={d.color} opacity={d.value === null ? 0.15 : 0.9} />
            <text x={x + bw * 0.3} y={H - 46 - h} fontSize="11" fontWeight="bold" textAnchor="middle" fill="#334155">
              {d.value === null ? "—" : d.value}
            </text>
            <text x={x + bw * 0.3} y={H - 24} fontSize="10" textAnchor="middle" fill="#64748b">{d.label}</text>
            {d.sub && <text x={x + bw * 0.3} y={H - 10} fontSize="8" textAnchor="middle" fill="#94a3b8">{d.sub}</text>}
          </g>
        );
      })}
    </svg>
  );
}

function ChangeBadge({ from, to, unit }: { from: number | null; to: number; unit: string }) {
  const { lang } = useI18n();
  if (from === null) return <Badge tone="slate">{lang === "ar" ? "بانتظار بيانات رسمية" : "En attente de données officielles"}</Badge>;
  const diff = to - from;
  const pct = from !== 0 ? ((diff / from) * 100).toFixed(1) : "0";
  return (
    <Badge tone={diff >= 0 ? "green" : "red"}>
      {diff >= 0 ? "▲" : "▼"} {Math.abs(diff)} {unit} ({Math.abs(+pct)}%)
    </Badge>
  );
}

export default function StatsTab() {
  const { lang } = useI18n();
  const db = useDB();
  const h = db.history;
  const prev = h.find((x) => x.year !== 2026) ?? h[0];
  const curr: ElectionHistory = h.find((x) => x.year === 2026) ?? h[h.length - 1];

  const regionDist = useMemo(() => {
    const m = new Map<string, number>();
    db.stations.forEach((s) => m.set(s.region ?? "—", (m.get(s.region ?? "—") ?? 0) + 1));
    return [...m.entries()];
  }, [db.stations]);

  const totalReports = db.reports.length;
  const reviewedRate = totalReports ? Math.round((db.reports.filter((r) => r.status === "reviewed").length / totalReports) * 100) : 0;
  const assigned = new Set(db.assignments.map((a) => a.station_id)).size;
  const coverage = db.stations.length ? Math.round((assigned / db.stations.length) * 100) : 0;
  const supportVotes = db.sessions.reduce((acc, s) => acc + Object.values(s.totals).reduce((a, b) => a + b, 0), 0);

  const exportStations = () => {
    downloadCSV("stations.csv", [
      ["رقم المكتب", "الاسم", "المدينة", "الجهة", "الحالة"],
      ...db.stations.map((s) => [s.station_number, s.name_ar, s.city ?? "", s.region ?? "", s.status]),
    ]);
  };
  const exportObservers = () => {
    downloadCSV("observers.csv", [
      ["الاسم", "الهاتف", "المكتب المعين", "آخر تحديث"],
      ...db.observers.map((o) => {
        const a = db.assignments.find((x) => x.observer_id === o.id);
        const st = a ? db.stations.find((s) => s.id === a.station_id) : undefined;
        const ping = db.pings.find((p) => p.observer_id === o.id);
        return [o.full_name, o.phone ?? "", st?.station_number ?? "—", ping?.recorded_at ?? "—"];
      }),
    ]);
  };
  const exportHistory = () => {
    downloadCSV("election-history.csv", [
      ["السنة", "المشاركة الرسمية %", "التغطية %", "تقارير مستلمة", "نسبة المراجعة %", "متوسط زمن التقرير (د)", "أصوات مساندة (تقديري)", "عدد المكاتب", "المصدر"],
      ...h.map((x) => [x.year, x.participation_rate ?? "—", x.coverage_rate, x.reports_received, x.reports_reviewed_rate, x.avg_report_minutes, x.support_votes_estimate ?? "—", x.stations_count, x.source]),
    ]);
  };

  const primary = db.parties[0]?.colors.primary ?? "#0f766e";

  return (
    <div className="space-y-4">
      {/* مؤشرات السنة الحالية — كل رقم بمصدره */}
      <div>
        <div className="mb-2 flex items-center gap-2">
          <h3 className="font-bold">{curr.label_ar}</h3>
          <Badge tone={srcTone[curr.source]}>{srcLabel[curr.source][lang]}</Badge>
        </div>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          <StatCard label={lang === "ar" ? "نسبة تغطية المكاتب" : "Taux de couverture"} value={`${coverage}%`} hint={`${assigned}/${db.stations.length}`} tone="brand" />
          <StatCard label={lang === "ar" ? "نسبة مراجعة التقارير" : "Taux de révision"} value={`${reviewedRate}%`} hint={`${totalReports} ${lang === "ar" ? "تقريراً" : "rapports"}`} tone="violet" />
          <StatCard label={lang === "ar" ? "أصوات مساندة (تقديرية)" : "Voix de soutien (estimées)"} value={supportVotes} tone="amber" />
          <StatCard label={lang === "ar" ? "نسبة المشاركة الرسمية" : "Participation officielle"} value={curr.participation_rate === null ? "—" : `${curr.participation_rate}%`} hint={lang === "ar" ? "تُنشر بعد الإعلان الرسمي" : "Publiée après annonce officielle"} tone="green" />
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* مقارنة السنوات */}
        <Card>
          <div className="mb-2 flex items-center justify-between">
            <h3 className="font-bold">{lang === "ar" ? "مقارنة مع السنة السابقة" : `Comparaison ${prev.year}`}</h3>
            <ChangeBadge from={prev.coverage_rate} to={coverage} unit="%" />
          </div>
          <Bars
            max={100} unit="%"
            data={[
              { label: `${prev.year}`, value: prev.coverage_rate, color: "#94a3b8", sub: lang === "ar" ? "تغطية" : "couverture" },
              { label: "2026", value: coverage, color: primary, sub: lang === "ar" ? "تغطية" : "couverture" },
              { label: `${prev.year}`, value: prev.reports_reviewed_rate, color: "#c4b5fd", sub: lang === "ar" ? "مراجعة" : "révision" },
              { label: "2026", value: reviewedRate, color: "#7c3aed", sub: lang === "ar" ? "مراجعة" : "révision" },
            ]}
          />
          <div className="mt-2 space-y-1 border-t border-slate-100 pt-2 text-xs text-slate-500 dark:border-slate-800">
            <div className="flex items-center justify-between">
              <span>{lang === "ar" ? "متوسط زمن استقبال التقرير" : "Délai moyen de réception"}</span>
              <span><b>{curr.avg_report_minutes} min</b> <ChangeBadge from={prev.avg_report_minutes} to={curr.avg_report_minutes} unit="min" /></span>
            </div>
            <div className="flex items-center justify-between">
              <span>{lang === "ar" ? "عدد المكاتب المغطاة" : "Bureaux couverts"}</span>
              <span><b>{db.stations.length}</b> / {prev.stations_count} ({prev.year})</span>
            </div>
            <div className="flex items-center justify-between">
              <span>{lang === "ar" ? "المشاركة الرسمية" : "Participation officielle"}</span>
              <span>{prev.participation_rate}% ({prev.year}) → {curr.participation_rate === null ? (lang === "ar" ? "قيد الإعلان" : "à annoncer") : `${curr.participation_rate}%`}</span>
            </div>
          </div>
        </Card>

        {/* توزيع الجهات */}
        <Card>
          <h3 className="mb-2 font-bold">{lang === "ar" ? "توزيع المكاتب حسب الجهات" : "Répartition par région"}</h3>
          <Bars
            max={Math.max(1, ...regionDist.map(([, n]) => n))} unit=""
            data={regionDist.map(([region, n]) => ({
              label: region.length > 12 ? region.slice(0, 12) + "…" : region,
              value: n, color: primary, sub: lang === "ar" ? "مكتب" : "bureau(x)",
            }))}
          />
          <p className="mt-2 text-xs text-slate-400">{lang === "ar" ? "مراعاة تغير الحدود والدوائر بين السنوات عند المقارنة التاريخية." : "Tenir compte des changements de circonscriptions entre les années."}</p>
        </Card>
      </div>

      {/* تصدير */}
      <Card>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h3 className="font-bold">{lang === "ar" ? "تصدير التقارير الإدارية" : "Exporter rapports"}</h3>
          <div className="flex flex-wrap gap-2">
            <Btn variant="ghost" onClick={exportStations}>⬇ {lang === "ar" ? "المكاتب (CSV)" : "Bureaux (CSV)"}</Btn>
            <Btn variant="ghost" onClick={exportObservers}>⬇ {lang === "ar" ? "المراقبون (CSV)" : "Observateurs (CSV)"}</Btn>
            <Btn variant="ghost" onClick={exportHistory}>⬇ {lang === "ar" ? "المقارنة التاريخية (CSV)" : "Historique (CSV)"}</Btn>
          </div>
        </div>
        <p className="mt-2 text-xs text-slate-400">
          {lang === "ar"
            ? "ملاحظة: ملفات CSV تُصدَّر بترميز UTF-8 مع BOM لفتحها مباشرة في Excel بالعربية. تصدير PDF يُضاف في نسخة الإنتاج عبر Edge Function."
            : "CSV exportés en UTF-8 avec BOM pour Excel. Export PDF via Edge Function en production."}
        </p>
      </Card>
    </div>
  );
}

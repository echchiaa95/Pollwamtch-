import { useState } from "react";
import { useI18n } from "./lib/i18n";
import { store } from "./lib/store";
import type { Session } from "./lib/types";
import { Btn, Card } from "./shared/ui";
import SuperadminApp from "./features/superadmin/SuperadminApp";
import PartyApp from "./features/party/PartyApp";
import ObserverApp from "./features/observer/ObserverApp";

function Login({ onLogin }: { onLogin: (s: Session) => void }) {
  const { t } = useI18n();
  const parties = store.data.parties;
  const accounts: { label: string; session: Session }[] = [
    { label: `${t("superadmin")} — admin@pollwatch.ma`, session: { role: "superadmin", partyId: null, memberName: "المدير المركزي" } },
    { label: `${t("party_admin")} — ${parties[0]?.name_ar ?? ""}`, session: { role: "party_admin", partyId: "p1", memberName: "رئيس الحزب" } },
    { label: `${t("observer")} — يوسف العلوي (CASA-001)`, session: { role: "observer", partyId: "p1", memberName: "يوسف العلوي", observerId: "o1" } },
    { label: `${t("observer")} — فاطمة الزهراء مرتب (CASA-002)`, session: { role: "observer", partyId: "p1", memberName: "فاطمة الزهراء مرتب", observerId: "o2" } },
  ];
  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-brand-dark to-brand p-4">
      <Card className="w-full max-w-md">
        <div className="mb-6 text-center">
          <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-brand text-2xl font-black text-white">P</div>
          <h1 className="text-xl font-bold">{t("app_title")}</h1>
          <p className="mt-1 text-xs text-amber-600">⚠ {t("demo_mode")}</p>
        </div>
        <div className="space-y-2">
          {accounts.map((a) => (
            <button
              key={a.label}
              onClick={() => onLogin(a.session)}
              className="w-full rounded-xl border border-slate-200 px-4 py-3 text-start text-sm font-medium transition hover:border-brand hover:bg-brand/5 dark:border-slate-700"
            >
              {a.label}
            </button>
          ))}
        </div>
        <div className="mt-4 flex items-center justify-between text-xs text-slate-400">
          <button onClick={() => store.reset()} className="underline">Reset demo data</button>
          <span>v0.1 — MVP</span>
        </div>
      </Card>
    </div>
  );
}

export default function App() {
  const [session, setSession] = useState<Session | null>(null);
  const { t } = useI18n();
  if (!session) return <Login onLogin={setSession} />;
  const logout = <Btn variant="ghost" onClick={() => setSession(null)}>{t("logout")}</Btn>;
  if (session.role === "superadmin") return <SuperadminApp logout={logout} />;
  if (session.role === "party_admin") return <PartyApp logout={logout} />;
  return <ObserverApp session={session} logout={logout} />;
}

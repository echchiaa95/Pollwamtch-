// ============================================================================
// طبقة الربط بالإنتاج: استبدال المخزن المحلي (lib/store.ts) بـ Supabase.
//
// الاستخدام: عند تعيين VITE_SUPABASE_URL و VITE_SUPABASE_ANON_KEY يُستدعى
// resolveTenant(host) عند الإقلاع، وتُبنى الجلسة من party_id المحقون في JWT.
// المخطط (supabase/schema.sql) يطابق الأنواع في lib/types.ts واحدًا بواحد.
// ============================================================================
import { createClient, type SupabaseClient } from "@supabase/supabase-js";

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const anon = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

export const supabase: SupabaseClient | null =
  url && anon ? createClient(url, anon, { auth: { persistSession: true, autoRefreshToken: true } }) : null;

export const isLive = () => supabase !== null;

/** حل المستأجر من الدومين عبر Edge Function (تُستدعى قبل تسجيل الدخول) */
export async function resolveTenant(host: string) {
  if (!supabase) return null;
  const { data, error } = await supabase.functions.invoke("resolve-tenant", {
    headers: { "x-forwarded-host": host },
  });
  if (error) throw error;
  return data as { party_id: string | null; party: { name_ar: string; colors: { primary: string } } | null };
}

/** Realtime: اشتراك في تحديثات الحزب — يستبدل useEffect في PartyApp عند الإنتاج */
export function subscribeParty(
  partyId: string,
  onEvent: (table: "reports" | "count_sessions" | "observer_locations", row: unknown) => void
) {
  if (!supabase) return () => {};
  const channel = supabase
    .channel(`party:${partyId}`)
    .on("postgres_changes", { event: "*", schema: "public", table: "reports", filter: `party_id=eq.${partyId}` },
      (p) => onEvent("reports", p.new))
    .on("postgres_changes", { event: "*", schema: "public", table: "count_sessions", filter: `party_id=eq.${partyId}` },
      (p) => onEvent("count_sessions", p.new))
    .on("postgres_changes", { event: "INSERT", schema: "public", table: "observer_locations", filter: `party_id=eq.${partyId}` },
      (p) => onEvent("observer_locations", p.new))
    .subscribe();
  return () => { supabase!.removeChannel(channel); };
}

/** إدخال فرز مضاد للتكرار: client_id يمنع double-submit عند ضعف الاتصال */
export async function insertVoteEntry(sessionId: string, candidateCode: string, clientId: string) {
  if (!supabase) throw new Error("live mode not configured");
  const { error } = await supabase.from("vote_entries").insert({
    session_id: sessionId,
    candidate_code: candidateCode,
    action: "add",
    client_id: clientId,
  });
  // 23505 = مفتاح client_id مكرر → نتجاهله بصمت (idempotency)
  if (error && error.code !== "23505") throw error;
}

/** إرسال المحضر عبر Edge Function (تحقق من الجلسة والصلاحيات على الخادم) */
export async function submitCount(sessionId: string) {
  if (!supabase) throw new Error("live mode not configured");
  const { data, error } = await supabase.functions.invoke("submit-count", {
    body: { session_id: sessionId },
  });
  if (error) throw error;
  return data as { submitted: boolean };
}

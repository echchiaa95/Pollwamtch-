import { useI18n } from "../../lib/i18n";
import * as api from "../../lib/api";
import { Badge, Card, Empty, Loading, StatCard, useLoad } from "../../shared/ui";

function downloadCSV(filename: string, rows: (string | number)[][]) {
  const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8" }));
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

const LIST_KEYS = ["c1", "c2"]; // أكواد القوائم الفعلية في تطبيق المراقب

export default function StatsTab({ partyId, tick }: { partyId: string; tick: number }) {
  const { lang } = useI18n();
  const stations = useLoad(() => api.listStations(partyId), [partyId, tick]);
  const assignments = useLoad(() => api.listAssignments(partyId), [partyId, tick]);
  const sessions = useLoad(() => api.listPartySessions(partyId), [partyId, tick]);
  const reports = useLoad(() => api.listReports(partyId), [partyId, tick]);
  const observers = useLoad(() => api.listObservers(partyId), [partyId, tick]);
  const locations = useLoad(() => api.listLatestLocations(partyId), [partyId, tick]);

  if (stations.loading || sessions.loading) return <Loading />;
  const s = stations.data ?? [], r = reports.data ?? [], se = sessions.data ?? [];
  const o = observers.data ?? [], loc = locations.data ?? [];

  // أحدث جلسة لكل مكتب (لتفادي ازدواج الجلسات)
  const latestByStation = new Map<string, api.SessionRow>();
  for (const x of se) {
    const prev = latestByStation.get(x.polling_station_id);
    if (!prev || x.started_at > prev.started_at) latestByStation.set(x.polling_station_id, x);
  }
  const latest = [...latestByStation.values()];

  const totalsOf = (x: api.SessionRow) => (x.totals ?? {}) as Record<string, number>;
  const sumKey = (k: string) => latest.reduce((a, x) => a + (totalsOf(x)[k] ?? 0), 0);
  const voteA = sumKey("c1");
  const voteB = sumKey("c2");
  const voteBlank = sumKey("blank");
  const countedTotal = latest.reduce((acc, x) => acc + Object.values(totalsOf(x)).reduce((m, n) => m + n, 0), 0);
  const others = countedTotal - voteA - voteB - voteBlank;
  const supportVotes = voteA + voteB; // المساندة = القائمة أ + القائمة ب

  const assigned = new Set((assignments.data ?? []).map((a) => a.polling_station_id)).size;
  const coverage = s.length ? Math.round((assigned / s.length) * 100) : 0;
  const reviewedRate = r.length ? Math.round((r.filter((x) => x.status === "reviewed").length / r.length) * 100) : 0;
  const connected = o.filter((ob) => {
    const p = loc.find((x) => x.observer_id === ob.id);
    if (p && Date.now() - new Date(p.recorded_at).getTime() < 5 * 60000) return true;
    const sess = se.find((x) => x.observer_id === ob.id);
    return !!sess && Date.now() - new Date(sess.updated_at).getTime() < 10 * 60000;
  }).length;

  // المكاتب الأكثر تصويتات (ترتيب تنازلي)
  const stationRanking = s
    .map((st) => {
      const sess = latestByStation.get(st.id);
      const t = sess ? totalsOf(sess) : {};
      const total = Object.values(t).reduce((m, n) => m + n, 0);
      return { st, t, total, a: t["c1"] ?? 0, b: t["c2"] ?? 0, blank: t["blank"] ?? 0 };
    })
    .filter((x) => x.total > 0)
    .sort((a, b) => b.total - a.total)
    .slice(0, 10);
  const maxVotes = Math.max(1, ...stationRanking.map((x) => x.total));

  const listRows = [
    { label: lang === "ar" ? "القائمة أ" : "Liste A", value: voteA, cls: "bg-teal-500" },
    { label: lang === "ar" ? "القائمة ب" : "Liste B", value: voteB, cls: "bg-blue-500" },
    { label: lang === "ar" ? "أصوات بيضاء" : "Blancs", value: voteBlank, cls: "bg-slate-500" },
    ...(others > 0 ? [{ label: lang === "ar" ? "أخرى" : "Autres", value: others, cls: "bg-amber-500" }] : []),
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <StatCard label={lang === "ar" ? "نسبة التغطية" : "Couverture"} value={`${coverage}%`} hint={`${assigned}/${s.length}`} />
        <StatCard label={lang === "ar" ? "مراجعة التقارير" : "Révision"} value={`${reviewedRate}%`} hint={`${r.length}`} tone="violet" />
        <StatCard label={lang === "ar" ? "الأصوات المساندة" : "Voix de soutien"} value={supportVotes} tone="amber" hint={lang === "ar" ? "القائمة أ + القائمة ب" : "A + B"} />
        <StatCard label={lang === "ar" ? "الأصوات المحصاة" : "Voix dépouillées"} value={countedTotal} tone="green" hint={lang === "ar" ? `منها بيضاء: ${voteBlank}` : `dont blancs: ${voteBlank}`} />
        <StatCard label={lang === "ar" ? "مراقبون متصلون" : "Observateurs connectés"} value={`${connected}/${o.length}`} tone="blue" />
      </div>

      <Card>
        <h3 className="mb-3 font-bold">{lang === "ar" ? "إحصائية القوائم" : "Statistiques des listes"}</h3>
        {countedTotal === 0 ? <Empty label={lang === "ar" ? "لا توجد أصوات بعد" : "Aucune voix"} /> : (
          <div className="space-y-3">
            {listRows.map((row) => (
              <div key={row.label}>
                <div className="mb-1 flex items-center justify-between text-sm">
                  <span className="font-medium">{row.label}</span>
                  <span className="tabular-nums text-slate-400">
                    <b className="text-slate-100">{row.value}</b>
                    {" — "}{Math.round((row.value / Math.max(1, countedTotal)) * 100)}%
                  </span>
                </div>
                <div className="h-3 w-full overflow-hidden rounded-full bg-slate-800">
                  <div className={`h-3 rounded-full transition-all ${row.cls}`} style={{ width: `${(row.value / Math.max(1, countedTotal)) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Card>
        <h3 className="mb-3 font-bold">{lang === "ar" ? "المكاتب الأكثر تصويتات" : "Bureaux les plus votés"}</h3>
        {stationRanking.length === 0 ? <Empty label={lang === "ar" ? "لا توجد أصوات بعد" : "Aucune voix"} /> : (
          <div className="space-y-2">
            {stationRanking.map(({ st, total, a, b, blank }, i) => (
              <div key={st.id} className="rounded-xl bg-slate-800/60 p-3">
                <div className="flex items-center justify-between gap-2 text-sm">
                  <span className="flex items-center gap-2">
                    <Badge tone="slate">#{i + 1}</Badge>
                    <b>{st.name_ar}</b>
                    <span className="text-xs text-slate-500">{st.station_number}</span>
                  </span>
                  <span className="text-base font-bold tabular-nums text-teal-400">{total}</span>
                </div>
                <div className="mt-2 flex h-2.5 w-full overflow-hidden rounded-full bg-slate-800">
                  <div className="bg-teal-500" style={{ width: `${(a / maxVotes) * 100}%` }} />
                  <div className="bg-blue-500" style={{ width: `${(b / maxVotes) * 100}%` }} />
                  <div className="bg-slate-500" style={{ width: `${(blank / maxVotes) * 100}%` }} />
                </div>
                <div className="mt-1 flex gap-3 text-xs text-slate-400">
                  <span>أ: {a}</span><span>ب: {b}</span><span>بيضاء: {blank}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

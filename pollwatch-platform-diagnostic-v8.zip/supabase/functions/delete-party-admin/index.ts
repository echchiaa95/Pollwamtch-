import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const token = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "").trim();
    const url = Deno.env.get("SUPABASE_URL");
    const anon = Deno.env.get("SUPABASE_ANON_KEY");
    const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? Deno.env.get("SERVICE_ROLE_KEY");
    if (!token) return json({ error: "يجب تسجيل الدخول أولاً" }, 401);
    if (!url || !anon || !service) return json({ error: "إعدادات Supabase السرية ناقصة" }, 500);
    const auth = createClient(url, anon);
    const { data: ud, error: ue } = await auth.auth.getUser(token);
    if (ue || !ud.user) return json({ error: "جلسة الدخول غير صالحة" }, 401);
    const admin = createClient(url, service);
    const { data: me } = await admin.from("party_members").select("id, roles!inner(key)").eq("user_id", ud.user.id).eq("status", "active").eq("roles.key", "superadmin").limit(1).maybeSingle();
    if (!me) return json({ error: "ليس لديك صلاحية المدير المركزي" }, 403);
    const body = await req.json();
    const partyId = String(body.party_id ?? "").trim();
    if (!partyId) return json({ error: "party_id مطلوب" }, 400);
    const { data: members, error: memberError } = await admin.from("party_members").select("user_id").eq("party_id", partyId);
    if (memberError) return json({ error: memberError.message }, 400);
    const { error: delPartyError } = await admin.from("parties").delete().eq("id", partyId);
    if (delPartyError) return json({ error: delPartyError.message }, 400);
    for (const m of members ?? []) if (m.user_id) await admin.auth.admin.deleteUser(m.user_id);
    return json({ ok: true, deleted_party_id: partyId });
  } catch (e) { return json({ error: e instanceof Error ? e.message : String(e) }, 500); }
});

-- ============================================================================
-- ملف موحّد: طبّقه مرة واحدة في Supabase ← SQL Editor ← New query ← Run
-- يجمع الـ migrations الناقصة: منح الجداول + عدادات الجلسات + views
-- آمن وقابل لإعادة التنفيذ (IF NOT EXISTS / CREATE OR REPLACE / GRANT)
-- لا يحذف أي بيانات ولا يضعف RLS — RLS تبقى الحارس الأمني.
-- ============================================================================

-- [1/2] منح الصلاحيات للدور authenticated (السبب المباشر لخطأ permission denied)
-- Pollwatch: required table privileges for the authenticated web client.
-- RLS remains the security boundary; these grants do not bypass RLS.

GRANT USAGE ON SCHEMA public TO authenticated;

-- Read-only reference data
GRANT SELECT ON TABLE
  public.election_years,
  public.election_types,
  public.roles,
  public.permissions,
  public.parties,
  public.party_domains,
  public.party_members
TO authenticated;

-- Tables accessed directly by the web application.
-- RLS policies restrict which rows each authenticated role may access.
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE
  public.parties,
  public.party_domains,
  public.party_members,
  public.observers,
  public.assistants,
  public.polling_stations,
  public.observer_assignments,
  public.observer_locations,
  public.count_sessions,
  public.vote_entries,
  public.support_metrics,
  public.official_results,
  public.reports,
  public.audit_logs,
  public.consent_records
TO authenticated;

-- Views used by the dashboard.
GRANT SELECT ON TABLE public.stations_view TO authenticated;

-- The application calls these RPCs from the browser.
GRANT EXECUTE ON FUNCTION public.my_role_key() TO authenticated;
GRANT EXECUTE ON FUNCTION public.my_member_id() TO authenticated;
GRANT EXECUTE ON FUNCTION public.my_party_id() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_superadmin() TO authenticated;
GRANT EXECUTE ON FUNCTION public.set_station_location(uuid, double precision, double precision) TO authenticated;

-- [2/2] مراحل التصويت + العدادات + RPCs + views
-- ============================================================================
-- Migration إضافي (غير هدّام): مراحل التصويت + عدادات الذكور/الإناث
-- + RPCs ذرّية + views بـ security_invoker=on (تفرض RLS كما لو استعلام مباشر).
-- لا يحذف أي بيانات ولا يغيّر الجداول الموجودة — يضيف أعمدة وكائنات فقط.
-- ============================================================================

-- 1) أعمدة الجلسات (إضافية بقيم افتراضية — آمنة على الصفوف القائمة)
alter table public.count_sessions
  add column if not exists phase text not null default 'voting'
    check (phase in ('voting', 'counting', 'done')),
  add column if not exists male_count int not null default 0 check (male_count >= 0),
  add column if not exists female_count int not null default 0 check (female_count >= 0),
  add column if not exists voting_started_at timestamptz,
  add column if not exists voting_ended_at timestamptz,
  add column if not exists counting_started_at timestamptz,
  add column if not exists counting_ended_at timestamptz;

-- 2) عدادات ذرّية بتحقق ملكية الجلسة داخل الدالة (definer + فحص يدوي)
create or replace function public.increment_counter(p_session uuid, p_which text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  s public.count_sessions%rowtype;
begin
  select * into s from public.count_sessions where id = p_session for update;
  if not found then
    raise exception 'session_not_found';
  end if;
  -- definer يتجاوز RLS → نفرض ملكية الجلسة للمراقب الحالي يدوياً
  if s.observer_id is distinct from public.my_observer_id() then
    raise exception 'forbidden';
  end if;
  if s.phase <> 'voting' then
    raise exception 'not_in_voting_phase';
  end if;
  if p_which = 'male' then
    update public.count_sessions set male_count = male_count + 1 where id = p_session;
  elsif p_which = 'female' then
    update public.count_sessions set female_count = female_count + 1 where id = p_session;
  else
    raise exception 'invalid_counter';
  end if;
end;
$$;

grant execute on function public.increment_counter(uuid, text) to authenticated;

-- 3) تثبيت إحداثيات المكتب (geography لا يُبنى من العميل مباشرة)
create or replace function public.set_station_location(
  p_station uuid, p_lat double precision, p_lng double precision
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  st public.polling_stations%rowtype;
begin
  select * into st from public.polling_stations where id = p_station;
  if not found then
    raise exception 'station_not_found';
  end if;
  -- صلاحية: superadmin أو party_admin لنفس الحزب
  if not public.is_superadmin() then
    if public.my_role_key() <> 'party_admin' or st.party_id is distinct from public.my_party_id() then
      raise exception 'forbidden';
    end if;
  end if;
  update public.polling_stations
  set location = st_geogfromtext('POINT(' || p_lng || ' ' || p_lat || ')')
  where id = p_station;
end;
$$;

grant execute on function public.set_station_location(uuid, double precision, double precision) to authenticated;

-- 4) view المكاتب بإحداثيات مقروءة — security_invoker=on ⇒ تسري عليه سياسات polling_stations
create or replace view public.stations_view
with (security_invoker = on) as
select
  id, party_id, station_number, name_ar, name_fr, city, region, status,
  election_year_id, created_at, updated_at,
  case when location is not null then st_y(location::geometry) end as lat,
  case when location is not null then st_x(location::geometry) end as lng
from public.polling_stations;

-- 5) view آخر موقع لكل مراقب — تسري عليه سياسات observer_locations
create or replace view public.observer_locations_latest
with (security_invoker = on) as
select distinct on (observer_id)
  id, party_id, observer_id, session_id, recorded_at, expires_at,
  st_y(location::geometry) as lat,
  st_x(location::geometry) as lng
from public.observer_locations
order by observer_id, recorded_at desc;

-- 6) إدراج موقع مراقب — definer مع فحص الموافقة والملكية يدوياً (RLS لا تنطبق على definer)
create or replace function public.insert_observer_location(
  p_observer uuid, p_session uuid, p_party uuid,
  p_lat double precision, p_lng double precision, p_expires timestamptz
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  -- المراقب الحالي فقط
  if p_observer is distinct from public.my_observer_id() then
    raise exception 'forbidden';
  end if;
  -- موافقة GPS سارية (نفس شرط سياسة RLS)
  if not exists (
    select 1 from public.consent_records c
    where c.subject_id = p_observer and c.consent_type = 'location_tracking'
      and c.granted = true and c.revoked_at is null
  ) then
    raise exception 'consent_required';
  end if;
  insert into public.observer_locations (party_id, observer_id, session_id, location, expires_at)
  values (p_party, p_observer, p_session, st_geogfromtext('POINT(' || p_lng || ' ' || p_lat || ')'), p_expires);
end;
$$;

grant execute on function public.insert_observer_location(uuid, uuid, uuid, double precision, double precision, timestamptz) to authenticated;
-- حسابات المراقبين/المساعدين + وثائق الهوية في التخزين الخاص
alter table public.observers  add column if not exists user_id uuid references auth.users(id) on delete set null;
alter table public.assistants add column if not exists user_id uuid references auth.users(id) on delete set null;
alter table public.assistants add column if not exists national_id_path text;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('id-documents', 'id-documents', false, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

drop policy if exists id_docs_insert on storage.objects;
create policy id_docs_insert on storage.objects for insert to authenticated
with check (bucket_id = 'id-documents' and (
  public.is_superadmin()
  or (public.my_role_key() = 'party_admin' and public.my_party_id()::text = (storage.foldername(name))[1])
));
drop policy if exists id_docs_select on storage.objects;
create policy id_docs_select on storage.objects for select to authenticated
using (bucket_id = 'id-documents' and (
  public.is_superadmin()
  or (public.my_role_key() = 'party_admin' and public.my_party_id()::text = (storage.foldername(name))[1])
));
drop policy if exists id_docs_delete on storage.objects;
create policy id_docs_delete on storage.objects for delete to authenticated
using (bucket_id = 'id-documents' and (
  public.is_superadmin()
  or (public.my_role_key() = 'party_admin' and public.my_party_id()::text = (storage.foldername(name))[1])
));

-- [4/4] شعارات الأحزاب — Bucket عام القراءة، الكتابة/التعديل/الحذف لـ superadmin فقط
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('party-assets', 'party-assets', true, 2097152, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

drop policy if exists party_assets_insert on storage.objects;
create policy party_assets_insert on storage.objects for insert to authenticated
with check (bucket_id = 'party-assets' and public.is_superadmin());
drop policy if exists party_assets_update on storage.objects;
create policy party_assets_update on storage.objects for update to authenticated
using (bucket_id = 'party-assets' and public.is_superadmin())
with check (bucket_id = 'party-assets' and public.is_superadmin());
drop policy if exists party_assets_delete on storage.objects;
create policy party_assets_delete on storage.objects for delete to authenticated
using (bucket_id = 'party-assets' and public.is_superadmin());

-- ============================================================================
-- [5/5] إصلاح سياسات التخزين — دوال SECURITY DEFINER تتجاوز تداخل RLS
-- (الدوال العادية is_superadmin/my_role_key تفشل داخل WITH CHECK للتخزين
--  لأنها تستعلم party_members الخاضع لـ RLS بشكل متداخل)
-- ============================================================================

-- 1) دالة تحقق superadmin آمنة داخل سياسات التخزين
create or replace function public.is_superadmin_storage()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.party_members pm
    join public.roles r on r.id = pm.role_id
    where pm.user_id = auth.uid() and r.key = 'superadmin' and pm.status = 'active'
  );
$$;
revoke all on function public.is_superadmin_storage() from anon;
grant execute on function public.is_superadmin_storage() to authenticated;

-- 2) دالة تحقق وثائق الهوية: superadmin أو party_admin لنفس الحزب (المسار يبدأ بمعرف الحزب)
create or replace function public.can_manage_id_doc(p_name text)
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.party_members pm
    join public.roles r on r.id = pm.role_id
    where pm.user_id = auth.uid() and pm.status = 'active'
      and (r.key = 'superadmin'
           or (r.key = 'party_admin' and pm.party_id::text = (storage.foldername(p_name))[1]))
  );
$$;
revoke all on function public.can_manage_id_doc() from anon;
grant execute on function public.can_manage_id_doc(text) to authenticated;

-- 3) إعادة إنشاء سياسات الشعارات بالدوال الآمنة
drop policy if exists party_assets_insert on storage.objects;
create policy party_assets_insert on storage.objects for insert to authenticated
with check (bucket_id = 'party-assets' and public.is_superadmin_storage());
drop policy if exists party_assets_update on storage.objects;
create policy party_assets_update on storage.objects for update to authenticated
using (bucket_id = 'party-assets' and public.is_superadmin_storage())
with check (bucket_id = 'party-assets' and public.is_superadmin_storage());
drop policy if exists party_assets_delete on storage.objects;
create policy party_assets_delete on storage.objects for delete to authenticated
using (bucket_id = 'party-assets' and public.is_superadmin_storage());

-- 4) إعادة إنشاء سياسات البطاقات بالدوال الآمنة
drop policy if exists id_docs_insert on storage.objects;
create policy id_docs_insert on storage.objects for insert to authenticated
with check (bucket_id = 'id-documents' and public.can_manage_id_doc(name));
drop policy if exists id_docs_select on storage.objects;
create policy id_docs_select on storage.objects for select to authenticated
using (bucket_id = 'id-documents' and public.can_manage_id_doc(name));
drop policy if exists id_docs_delete on storage.objects;
create policy id_docs_delete on storage.objects for delete to authenticated
using (bucket_id = 'id-documents' and public.can_manage_id_doc(name));

-- 5) إعادة تحميل المخطط
select pg_notify('pgrst', 'reload schema');

# منصة متابعة مكاتب الاقتراع المباشر — وثيقة المعمارية (v1.0)

> تطبيق ويب احترافي، آمن، متعدد المستأجرين (Multi-Tenant)، لإدارة مراقبي الأحزاب السياسية ومتابعة مكاتب الاقتراع عبر خريطة تفاعلية، مع دعم RTL (العربية) والفرنسية.

---

## 1. نظرة عامة على المعمارية

```
┌──────────────────────────────────────────────────────────────────┐
│                        طبقة العميل (Frontend)                     │
│  React 18 + Vite + TypeScript + Tailwind CSS + PWA               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐   │
│  │ واجهة المراقب │  │ لوحة رئيس    │  │ لوحة Superadmin      │   │
│  │ (هاتف/PWA)   │  │ الحزب        │  │ (إدارة مركزية)       │   │
│  └──────────────┘  └──────────────┘  └──────────────────────┘   │
│  الخريطة: MapLibre GL JS + Protocol Buffers (PMTiles/vector)     │
└──────────────────────────────┬───────────────────────────────────┘
                               │ HTTPS / WSS (Supabase Realtime)
┌──────────────────────────────┴───────────────────────────────────┐
│                     طبقة Supabase (Backend-as-a-Service)          │
│  ┌─────────────┐  ┌──────────────┐  ┌─────────────────────────┐ │
│  │ Auth        │  │ PostgreSQL   │  │ Edge Functions (Deno)   │ │
│  │ (Email +    │  │ + Row Level  │  │ • resolve-tenant        │ │
│  │  MFA إدارية)│  │   Security   │  │ • domain-verify (DNS)   │ │
│  └─────────────┘  │ + Realtime   │  │ • report-submit         │ │
│                   │ + Storage    │  │ • export (Excel/PDF)    │ │
│                   └──────────────┘  │ • audit-log             │ │
│                                     └─────────────────────────┘ │
└──────────────────────────────────────────────────────────────────┘
```

**قرار معماري أساسي:** لا يوجد خادم تطبيق مخصص (No custom app server). كل منطق الوصول يعيش في PostgreSQL (RLS) وEdge Functions. هذا يقلص سطح الهجوم ويضمن أن عزل البيانات يفرض من قاعدة البيانات نفسها وليس من الكود فقط.

---

## 2. المعمارية متعددة المستأجرين (Multi-Tenant)

### 2.1 تحديد المستأجر (Tenant Resolution)

المستأجر = الحزب (`party_id`). يُحلّ عبر **الدومين** الذي يصل منه الطلب:

1. المستخدم يفتح `www.parti-exemple.ma`.
2. Edge Function `resolve-tenant` تستقبل `Host` وتبحث في `party_domains` عن دومين `verified = true`.
3. تُحقن `party_id` في JWT claims عند تسجيل الدخول (عبر `auth.users.raw_app_meta_data`) بحيث تصبح متاحة كـ `auth.jwt() ->> 'party_id'` داخل كل استعلام وكل سياسة RLS.
4. `app.parti-exemple.ma` (دومين التطبيق الرئيسي) → `party_id = null` → Superadmin فقط.

### 2.2 قواعد العزل الصارم

- **كل جدول يخص حزباً يحمل عمود `party_id NOT NULL`** (باستثناء `parties`, `party_domains`, `roles`, `permissions`, `election_years`, `election_types` — مرجعية مركزية).
- لا توجد سياسة RLS واحدة تعتمد على "ثقة العميل"؛ كل سياسة تتحقق من `party_id = (auth.jwt() ->> 'party_id')::uuid` أو من دور Superadmin.
- Superadmin يملك دوراً مركزياً `is_superadmin()` يتجاوز العزل للقراءة الإحصائية فقط (بدون بيانات شخصية حساسة عند الإمكان).
- الاتصال المباشر بقاعدة البيانات من أي عميل آخر غير التطبيق الرسمي مستحيل عملياً لأن RLS تفرض العزل على مستوى الصفوف.

### 2.3 نموذج البيانات للهوية

- `parties`: الاسم، الشعار (Storage)، الألوان (JSONB: primary/secondary)، الحالة.
- `party_domains`: الدومين، `verification_token` (TXT record)، `verified_at`، `ssl_status`، `is_primary`.
- كل حزب له دومين رئيسي + نطاقات فرعية اختيارية (`*.parti-exemple.ma` عبر wildcard match).

---

## 3. الأدوار والصلاحيات (RBAC)

| الدور (role key) | النطاق | يدير | لا يستطيع |
|---|---|---|---|
| `superadmin` | النظام كله | الأحزاب، الدومينات، المستخدمون، السنوات الانتخابية، السجلات | تعديل بيانات شخصية غير ضرورية |
| `party_admin` (رئيس الحزب) | حزبه فقط | المراقبون، المساعدون، المستخدمون الفرعيون، الخريطة، التقارير | ربط/تغيير الدومين، إدارة أحزاب أخرى |
| `observer` | مكتبه المعيّن فقط | حالته، موقعه، إدخال الفرز، تقريره | رؤية مراقبين آخرين، إعدادات الحزب |
| `assistant` | حسب `permissions` الممنوحة | ما يصرح به رئيس الحزب | أي شيء خارج صلاحياته |

التنفيذ:
- جدول `roles` (مرجعي) + جدول `permissions` (مرجعي) + `party_members.role` + `party_members.permissions` (JSONB array لتجاوزات دقيقة لكل مستخدم فرعي).
- `party_members.status`: `active | suspended | pending` — الحساب المعلّق لا يمر عبر RLS (تُرفض الجلسة عبر Edge Function `resolve-tenant` وHook على Auth).
- التحقق من الدور داخل RLS: `has_role('party_admin')` تعمل على `auth.jwt()`.

### مصفوفة الوصول للجداول (مختصر)

| الجدول | superadmin | party_admin | observer | assistant |
|---|---|---|---|---|
| parties | RW كل | R (حزبه)، U (بيانات غير حساسة) | R (اسمه فقط) | — |
| party_domains | RW | R | — | — |
| users / party_members | RW | R/W داخل حزبه | R (نفسه) | R (نفسه) |
| observers | RW | R/W داخل حزبه | R (سجله) | حسب الصلاحية |
| assistants | RW | R/W داخل حزبه | — | حسب الصلاحية |
| polling_stations | RW | R داخل حزبه | R (مكتبه) | حسب الصلاحية |
| observer_assignments | RW | R/W داخل حزبه | R (تعيينه) | — |
| observer_locations | RW | R (بدون تتبع تاريخي زائد) | W (موقعه) | — |
| count_sessions / vote_entries | RW | R داخل حزبه | RW (جلسته) | — |
| reports | RW | R/W داخل حزبه | W (تقاريره) | حسب الصلاحية |
| official_results / election_years | RW | R | R | R |
| audit_logs | R (كتابة عبر Edge Function فقط) | R (سجل حزبه) | — | — |
| consent_records | RW | R (حزبه) | R/W (موافقاته) | — |

---

## 4. قاعدة البيانات

- PostgreSQL 15+ (Supabase)، الترميز `UTF8`، المنطقة الزمنية `Africa/Casablanca`.
- كل الجداول: `id uuid PK default gen_random_uuid()`، `created_at timestamptz default now()`، `updated_at` مع trigger.
- فهارس: `(party_id)` على كل جدول مستأجر + `GIST` على `location geography(Point)` في `polling_stations` و`observer_locations` + فهارس على `(party_id, status)`.
- **Row Level Security مفعّل على كل جدول** (انظر `supabase/schema.sql`).
- Realtime: فعّال على `observer_locations`، `count_sessions`، `reports`، `support_metrics` مع filter بالقناة `party:<uuid>`.

### مخطط العلاقات (نبذة)

```
parties 1──n party_domains
parties 1──n party_members 1──1 users (auth.users)
parties 1──n observers ──1 users
parties 1──n assistants
parties 1──n polling_stations
observer_assignments: observers n──1 polling_stations (per election_year)
observer_locations: observers 1──n (session-scoped, TTL + consent)
count_sessions 1──n vote_entries
election_years 1──n official_results 1──n polling_stations
reports: (observer/party_admin) 1──n
audit_logs / consent_records: append-only
```

---

## 5. تدفقات العمل الرئيسية

### 5.1 إنشاء حزب (Superadmin)
`create-party` Edge Function → إنشاء `party` + `party_admin` user (دعوة بريد) + `party_domains` (pending) → Superadmin يضيف TXT record → `verify-domain` Edge Function تتحقق عبر DNS → `verified_at = now()` → SSL تلقائي (عبر مزود الاستضافة) → الحزب يعمل على دومينه.

### 5.2 وردية المراقب (دورة حياة)
1. تسجيل دخول المراقب من الهاتف → `resolve-tenant` تتحقق من الدور والحالة → JWT فيه `party_id, role, observer_id`.
2. "بدء الوردية" → `count_sessions` (status: `open`) + `consent_records` (موافقة GPS صريحة، نصها مخزن) → Geolocation API → إدراج أول `observer_locations`.
3. إدخال الفرز: كل ضغطة = `vote_entries` واحدة (client_id uuid لمنع التكرار عند إعادة الإرسال) → upsert في `count_sessions.totals` عبر trigger → Realtime يحدّث لوحة رئيس الحزب والخريطة.
4. "إنهاء الوردية" → `count_sessions.status = 'submitted'` → إيقاف تتبع الموقع → انتظار مراجعة رئيس الحزب → `validated` / `returned`.

### 5.3 الخريطة المباشرة
- رئيس الحزب يشترك في قناة Realtime `party:<id>`، وعند كل تحديث (موقع، حالة، تقرير) يُعاد حساب حالة المكتب (خوارزمية: آخر `heartbeat < 5min` أخضر، `5–30min` أصفر، `>30min` أحمر، تقرير مقدم أزرق) وتتحدث العلامة.
- التجميع (clustering) عبر `maplibre-gl` + `supercluster`؛ مربعات `PMTiles` ذاتية الاستضافة للخريطة الأساسية (تجنب أسعار/قيود مفاتيح الإنتاج).

### 5.4 العمل دون اتصال (PWA)
- `IndexedDB` (عبر Dexie): طابور إدخالات الفرز + التقارير مع `client_id`.
- Background Sync عند عودة الاتصال + مؤشر واضح "بانتظار المزامنة (n)".
- النتائج النهائية لا تُعلن محلياً كمؤكدة إلا بعد استلام `validated` من الخادم.

---

## 6. الأمان والامتثال

- **TLS إجباري**، HSTS، CSP صارمة.
- **MFA** إجبارية لـ superadmin وparty_admin (TOTP).
- كلمات المرور: Supabase Auth defaults (bcrypt)، سياسة قوة كلمة مرور.
- الجلسات: short-lived JWT access token (15min) + refresh rotation.
- **audit_logs**: append-only (لا UPDATE/DELETE حتى لـ superadmin)، يكتب عبر `security definer` function فقط، يُرسل نسخة مجمعة خارجية (webhook) للحماية من العبث.
- **consent_records**: موافقة صريحة على GPS، قابلة للسحب، مع نص الموافقة والإصدار وسياقه.
- **تقليل البيانات**: `national_id` مشفر (pgcrypto, مفتاح في Vault/KMS) + mask في العرض؛ المواقع تُحذف بعد `TTL` معلن (افتراضي 24 ساعة بعد إنهاء الوردية) — سياسة `data_retention_days` في إعدادات الحزب.
- حقوق الوصول: كل سجل بيانات شخصية يحمل `access_level` وتسجَّل من اطّلع عليه في audit_logs.
- الامتثال المغربي: Law 09-08 (حماية المعطيات الشخصية) + CNDP — توثيق DPIA في `docs/compliance.md`، وحق النسيان عبر Edge Function `request-erasure`.
- الفصل القانوني بين "الأصوات المساندة (تقديرية)" و"نتائج محاضر الفرز (رسمية)": حقول منفصلة (`source_type` ∈ `official | entered | estimate | under_review`)، ولا يجمعهما أي تقرير واحد.

---

## 7. بنية المستودع (Monorepo)

```
pollwatch-platform/
├── apps/
│   ├── web/                  # React + Vite + TS (الثلاث واجهات في تطبيق واحد بالتوجيه حسب الدور)
│   │   ├── src/
│   │   │   ├── app/          # router, providers, guards
│   │   │   ├── features/
│   │   │   │   ├── superadmin/  parties, domains, users, stations, system
│   │   │   │   ├── party/       dashboard, map, observers, assistants, stats
│   │   │   │   └── observer/    session, gps, counting, report
│   │   │   ├── shared/       ui kit, i18n (ar/fr), map, realtime, offline
│   │   └── public/           manifest.webmanifest, service worker
│   └── web-e2e/              # Playwright
├── supabase/
│   ├── schema.sql            # الجداول + RLS (هذا التسليم)
│   ├── seed.sql              # بيانات اختبارية
│   ├── functions/            # Edge Functions (Deno)
│   └── migrations/
├── docs/
│   ├── architecture.md       # هذا الملف
│   ├── compliance.md         # DPIA + Law 09-08 checklist
│   └── runbook.md            # التشغيل والمراقبة
└── package.json              # pnpm workspaces
```

---

## 8. خطة التنفيذ المُدرَّجة

| المرحلة | المحتوى | معيار القبول |
|---|---|---|
| **MVP (المرحلة 1)** | Auth + Superadmin + إنشاء الأحزاب + ربط الدومين (DNS verify) + مكاتب الاقتراع + مراقبون + خريطة + GPS + إدخال فرز تجريبي + RLS كامل | كل سياسات RLS تاجَت اختبارات pgTAP خضراء؛ دومين حزب تجريبي يعمل end-to-end |
| **المرحلة 2** | المساعدون + الإحصائيات + التقارير + مقارنة السنوات + تصدير Excel/PDF + إشعارات + تحسين offline | تقرير Excel يطابق البيانات؛ مقارنة سنتين رسميتين تعمل |
| **المرحلة 3** | تكامل مصادر رسمية + تحسينات أداء/أمان + اختبار اختراق + إنتاج | تقرير اختبار اختراق نظيف؛ DPIA موقّع؛ تشغيل إنتاجي |

### اختبارات كل مرحلة
- **وحدة/تكامل DB:** pgTAP على كل سياسة RLS (محاولة عبور مستأجر يجب أن تفشل).
- **واجهة:** Vitest + Testing Library؛ E2E عبر Playwright (3 مسارات: سوبردمن→حزب، رئيس حزب→خريطة، مراقب→فرز كامل).
- **أداء:** k6 على Realtime (1000 مراقب concurrent) وعلى خريطة بـ 10k مكتب.

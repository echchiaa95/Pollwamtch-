// ============================================================================
// Edge Function: submit-count
// غلق جلسة الفرز من طرف المراقب مع تحققات: الجلسة مفتوحة، لمراقبها هو، لها إدخالات.
// POST { session_id } — JWT عادي (المراقب). تحديث عبر service role بعد التحقق اليدوي.
// ============================================================================
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, content-type" };

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const anon = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );
    const { data: userData } = await anon.auth.getUser();
    const user = userData.user;
    if (!user) return json({ error: "unauthorized" }, 401);

    const { session_id } = await req.json();
    if (!session_id) return json({ error: "session_id required" }, 400);

    // تحقق: الجلسة مفتوحة وتخص مراقب هذا المستخدم
    const { data: session, error } = await anon
      .from("count_sessions")
      .select("id, observer_id, status, observers!inner(user_id)")
      .eq("id", session_id)
      .single();
    if (error || !session) return json({ error: "not_found" }, 404);
    const observer = session.observers as unknown as { user_id: string };
    if (observer.user_id !== user.id) return json({ error: "forbidden" }, 403);
    if (session.status !== "open") return json({ error: "session_not_open" }, 409);

    // تحقق: وجود إدخالات
    const { count } = await anon
      .from("vote_entries")
      .select("id", { count: "exact", head: true })
      .eq("session_id", session_id);
    if (!count) return json({ error: "no_entries" }, 422);

    // التحديث النهائي بـ service role (تجاوز سياسة review)
    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );
    const { error: upErr } = await admin
      .from("count_sessions")
      .update({ status: "submitted", submitted_at: new Date().toISOString(), ended_at: new Date().toISOString() })
      .eq("id", session_id);
    if (upErr) return json({ error: upErr.message }, 500);

    await admin.rpc("log_audit", {
      p_action: "session.submit", p_entity: "count_sessions", p_entity_id: session_id, p_metadata: {},
    });
    return json({ submitted: true });
  } catch (e) {
    return json({ error: String(e) }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
}

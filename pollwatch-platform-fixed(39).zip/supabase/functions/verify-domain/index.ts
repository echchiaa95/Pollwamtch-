// ============================================================================
// Edge Function: verify-domain
// يتحقق من ملكية الدومين عبر سجل TXT (_pollwatch.<domain>) ثم يفعّله.
// POST { domain_id } — يتطلب صلاحية superadmin.
//
// حماية إضافية: استيراد node:dns يتم ديناميكياً داخل المعالج — إذا تعذّر
// على بيئة التشغيل لا تنهار الدالة عند الإقلاع، بل تُرجع JSON واضحاً.
// ============================================================================
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

function requiredEnv(name: string): string | null {
  const v = Deno.env.get(name);
  if (!v) console.error(`[verify-domain] متغير البيئة الناقص: ${name}`);
  return v ?? null;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ success: false, error: "method_not_allowed" }, 405);

  try {
    // 1) التحقق من إعدادات البيئة — بأسمائها الصريحة
    const url = requiredEnv("SUPABASE_URL");
    const anon = requiredEnv("SUPABASE_ANON_KEY");
    if (!url || !anon) {
      return json({ success: false, error: "متغير بيئة ناقص على الخادم: SUPABASE_URL و/أو SUPABASE_ANON_KEY" }, 500);
    }

    // 2) التحقق من Authorization والدور (is_superadmin RPC مُعرَّفة في schema)
    const authHeader = req.headers.get("Authorization") ?? "";
    const supabase = createClient(url, anon, { global: { headers: { Authorization: authHeader } } });
    const { data: isAdmin, error: rpcError } = await supabase.rpc("is_superadmin");
    if (rpcError) {
      console.error("[verify-domain] فشل RPC is_superadmin:", rpcError.message);
      return json({ success: false, error: `فشل التحقق من الصلاحية: ${rpcError.message}` }, 500);
    }
    if (!isAdmin) return json({ success: false, error: "forbidden: يتطلب صلاحية superadmin" }, 403);

    // 3) التحقق من body
    let body: { domain_id?: string };
    try { body = await req.json(); }
    catch { return json({ success: false, error: "body غير صالح (JSON مطلوب)" }, 400); }
    const domainId = String(body?.domain_id ?? "").trim();
    if (!domainId) return json({ success: false, error: "domain_id مطلوب" }, 400);

    const { data: domain, error } = await supabase
      .from("party_domains")
      .select("id, domain, verification_token")
      .eq("id", domainId)
      .maybeSingle();
    if (error) {
      console.error("[verify-domain] فشل القراءة من party_domains:", error.message);
      return json({ success: false, error: `فشل قراءة الدومين: ${error.message}` }, 400);
    }
    if (!domain) return json({ success: false, error: "not_found: الدومين غير موجود" }, 404);

    // 4) التحقق DNS — استيراد ديناميكي لا يعطّل إقلاع الدالة إن غابت الوحدة
    let records: string[] = [];
    try {
      const { verify } = await import("node:dns/promises");
      const txt = (await verify(`_pollwatch.${domain.domain}`, "TXT")) as unknown as string[][];
      records = txt.flat();
    } catch (dnsErr) {
      console.error("[verify-domain] تعذّر فحص DNS (سيُعامل كغير مُتحقق):", String(dnsErr));
      records = [];
    }

    if (!records.includes(domain.verification_token)) {
      return json({
        success: true,
        verified: false,
        hint: `أضف سجل TXT: _pollwatch.${domain.domain} = ${domain.verification_token}`,
      });
    }

    const { error: upErr } = await supabase
      .from("party_domains")
      .update({ verified_at: new Date().toISOString(), ssl_status: "issued" })
      .eq("id", domainId);
    if (upErr) {
      console.error("[verify-domain] فشل التحديث:", upErr.message);
      return json({ success: false, error: `فشل حفظ التحقق: ${upErr.message}` }, 500);
    }

    await supabase.rpc("log_audit", {
      p_action: "domain.verify", p_entity: "party_domains", p_entity_id: domainId,
      p_metadata: { domain: domain.domain },
    });
    return json({ success: true, verified: true });
  } catch (e) {
    console.error("[verify-domain] خطأ غير متوقع:", e);
    return json({ success: false, error: e instanceof Error ? e.message : String(e) }, 500);
  }
});

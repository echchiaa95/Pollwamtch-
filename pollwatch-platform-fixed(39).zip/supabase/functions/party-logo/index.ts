// رفع/تغيير شعار الحزب — superadmin فقط، عبر مفتاح الخدمة (يتجاوز RLS للتخزين)
import { createClient } from "jsr:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: Record<string, unknown>, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const { party_id, image_base64 } = await req.json();
    if (!party_id || !image_base64) return json({ error: "party_id و image_base64 مطلوبان" }, 400);
    if (image_base64.length > 1_500_000) return json({ error: "الصورة كبيرة جداً (الحد ~1MB بعد التقليص)" }, 400);

    // التحقق: superadmin فقط
    const userClient = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: me, error: meErr } = await userClient.auth.getUser();
    if (meErr || !me?.user) return json({ error: "غير مصرّح" }, 401);
    const { data: isAdmin } = await userClient.rpc("is_superadmin");
    if (!isAdmin) return json({ error: "صلاحيات غير كافية (superadmin فقط)" }, 403);

    // رفع الصورة عبر مفتاح الخدمة (لا RLS)
    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const binary = Uint8Array.from(atob(image_base64), (c) => c.charCodeAt(0));
    const path = `logos/${party_id}.jpg`;
    const { error: upErr } = await admin.storage.from("party-assets").upload(path, binary, {
      upsert: true, contentType: "image/jpeg", cacheControl: "60",
    });
    if (upErr) return json({ error: `فشل الرفع: ${upErr.message}` }, 400);

    const { data: urlData } = admin.storage.from("party-assets").getPublicUrl(path);
    const logoUrl = `${urlData.publicUrl}?v=${Date.now()}`;

    // حفظ المسار في جدول الأحزاب
    const { error: dbErr } = await admin.from("parties").update({ logo_path: logoUrl }).eq("id", party_id);
    if (dbErr) return json({ error: `فشل حفظ الشعار: ${dbErr.message}` }, 400);

    return json({ success: true, ok: true, data: { logo_url: logoUrl } });
  } catch (e) {
    return json({ error: e instanceof Error ? e.message : String(e) }, 500);
  }
});

# Edge Functions

| الدالة | الوصف | أدوات |
|---|---|---|
| `resolve-tenant` | حل الدومين → party_id (مكتملة) | Deno, service role |
| `verify-domain` | التحقق من TXT record عبر DNS (`node:dns`) ثم تعيين verified_at | Superadmin فقط |
| `create-party` | إنشاء حزب + دعوة رئيس الحزب + دومين pending | Superadmin فقط |
| `submit-count` | غلق الجلسة: تحقق من الاكتمال، تثبيت status=submitted، إشعار Realtime | المراقب |
| `export-report` | تصدير Excel/PDF (المرحلة 2) | party_admin |
| `request-erasure` | طلب حذف بيانات شخصية (حق النسيان، Law 09-08) | المالك |
| `purge-locations` | مناداة `purge_expired_locations()` عبر pg_cron | cron |

## التشغيل
```bash
supabase functions deploy resolve-tenant
supabase secrets set APP_DOMAIN=app.pollwatch.ma
```

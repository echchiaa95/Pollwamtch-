// ============================================================================
// Edge Function: resolve-tenant
// يُستدعى عند تسجيل الدخول. يستقبل Host header، يتحقق من الدومين،
// ويعيد party_id ليُضاف إلى JWT claims (raw_app_meta_data).
// ============================================================================
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const host = (req.headers.get("x-forwarded-host") ?? req.headers.get("host") ?? "")
    .toLowerCase().split(":")[0];
  const appDomain = Deno.env.get("APP_DOMAIN") ?? "app.pollwatch.ma";

  // الدومين الرئيسي للتطبيق → لا مستأجر (Superadmin فقط لاحقاً)
  if (host === appDomain || host === `www.${appDomain}`) {
    return json({ party_id: null, party: null });
  }

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,   // service role: قراءة خارج RLS
  );

  // دعم wildcard: www.parti.ma أو *.parti.ma
  const { data: domain } = await supabase
    .from("party_domains")
    .select("party_id, verified_at, wildcard, party:parties(id, name_ar, name_fr, slug, logo_path, colors, status)")
    .eq("verified_at", "not.is.null")
    .or(`domain.eq.${host},and(wildcard.eq.true,domain.eq.${baseDomain(host)})`)
    .maybeSingle();

  if (!domain || (domain.party as any).status !== "active") {
    return json({ error: "domain_not_found_or_unverified" }, 404);
  }

  return json({
    party_id: domain.party_id,
    party: domain.party,
  });
});

function baseDomain(host: string) {
  const parts = host.split(".");
  return parts.length > 2 ? parts.slice(-2).join(".") : host;
}

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

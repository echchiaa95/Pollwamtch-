create or replace function public.can_delete_reports(p_party uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.party_members pm join public.roles r on r.id = pm.role_id
    where pm.user_id = auth.uid() and pm.status = 'active'
      and (r.key = 'superadmin' or (r.key = 'party_admin' and pm.party_id = p_party))
  );
$$;
revoke all on function public.can_delete_reports(uuid) from anon;
grant execute on function public.can_delete_reports(uuid) to authenticated;

drop policy if exists reports_delete on public.reports;
create policy reports_delete on public.reports for delete to authenticated
using (public.can_delete_reports(party_id));

alter table public.assistants add column if not exists national_id_number text;
alter table public.assistants add column if not exists polling_station_id uuid references public.polling_stations(id) on delete set null;

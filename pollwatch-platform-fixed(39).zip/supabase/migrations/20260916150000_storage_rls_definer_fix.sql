-- ============================================================================
-- [5/5] إصلاح سياسات التخزين — دوال SECURITY DEFINER تتجاوز تداخل RLS
-- (الدوال العادية is_superadmin/my_role_key تفشل داخل WITH CHECK للتخزين
--  لأنها تستعلم party_members الخاضع لـ RLS بشكل متداخل)
-- ============================================================================

-- 1) دالة تحقق superadmin آمنة داخل سياسات التخزين
create or replace function public.is_superadmin_storage()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.party_members pm
    join public.roles r on r.id = pm.role_id
    where pm.user_id = auth.uid() and r.key = 'superadmin' and pm.status = 'active'
  );
$$;
revoke all on function public.is_superadmin_storage() from anon;
grant execute on function public.is_superadmin_storage() to authenticated;

-- 2) دالة تحقق وثائق الهوية: superadmin أو party_admin لنفس الحزب (المسار يبدأ بمعرف الحزب)
create or replace function public.can_manage_id_doc(p_name text)
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.party_members pm
    join public.roles r on r.id = pm.role_id
    where pm.user_id = auth.uid() and pm.status = 'active'
      and (r.key = 'superadmin'
           or (r.key = 'party_admin' and pm.party_id::text = (storage.foldername(p_name))[1]))
  );
$$;
revoke all on function public.can_manage_id_doc() from anon;
grant execute on function public.can_manage_id_doc(text) to authenticated;

-- 3) إعادة إنشاء سياسات الشعارات بالدوال الآمنة
drop policy if exists party_assets_insert on storage.objects;
create policy party_assets_insert on storage.objects for insert to authenticated
with check (bucket_id = 'party-assets' and public.is_superadmin_storage());
drop policy if exists party_assets_update on storage.objects;
create policy party_assets_update on storage.objects for update to authenticated
using (bucket_id = 'party-assets' and public.is_superadmin_storage())
with check (bucket_id = 'party-assets' and public.is_superadmin_storage());
drop policy if exists party_assets_delete on storage.objects;
create policy party_assets_delete on storage.objects for delete to authenticated
using (bucket_id = 'party-assets' and public.is_superadmin_storage());

-- 4) إعادة إنشاء سياسات البطاقات بالدوال الآمنة
drop policy if exists id_docs_insert on storage.objects;
create policy id_docs_insert on storage.objects for insert to authenticated
with check (bucket_id = 'id-documents' and public.can_manage_id_doc(name));
drop policy if exists id_docs_select on storage.objects;
create policy id_docs_select on storage.objects for select to authenticated
using (bucket_id = 'id-documents' and public.can_manage_id_doc(name));
drop policy if exists id_docs_delete on storage.objects;
create policy id_docs_delete on storage.objects for delete to authenticated
using (bucket_id = 'id-documents' and public.can_manage_id_doc(name));

-- 5) إعادة تحميل المخطط
select pg_notify('pgrst', 'reload schema');

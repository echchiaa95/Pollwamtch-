drop policy if exists reports_delete on public.reports;
create policy reports_delete on public.reports for delete to authenticated using (
  public.is_superadmin()
  or (public.my_role_key() = 'party_admin' and party_id = public.my_party_id())
);

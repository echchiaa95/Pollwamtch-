-- [8/8] إصلاح تريغر الفرز المعطوب (new.totals كان يشير لجدول vote_entries الخطأ)
create or replace function public.apply_vote_entry()
returns trigger language plpgsql security definer set search_path = public as $$
declare cur int;
begin
  select coalesce((cs.totals ->> new.candidate_code)::int, 0)
    into cur
  from public.count_sessions cs
  where cs.id = new.session_id
  for update;

  update public.count_sessions cs
  set totals = jsonb_set(
         cs.totals,
         array[new.candidate_code],
         to_jsonb(greatest(0, cur + case when new.action = 'add' then 1 else -1 end))
       )
  where cs.id = new.session_id;

  return new;
end $$;

-- ضمان وجود العمود (آمن للتكرار)
alter table public.count_sessions
  add column if not exists totals jsonb not null default '{}'::jsonb;

select pg_notify('pgrst', 'reload schema');

// ============================================================================
// عميل Supabase المركزي — الملف الوحيد الذي يحمل إعدادات الاتصال.
// مفتاح publishable مصمم للعرض العام (تفرض RLS الصلاحيات على مستوى الصفوف).
// لا يُستعمل أي import.meta.env أو process.env — يعمل مباشرة على GitHub Pages.
// ============================================================================
import { createClient } from "@supabase/supabase-js";

export const SUPABASE_URL = "https://luoqtqfioxusytqrgaph.supabase.co";

export const SUPABASE_ANON_KEY =
  "sb_publishable_H850oFBj527tfUgtxUYX1w_RWimwQ-s";

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    storageKey: "pollwatch-auth",
  },
});

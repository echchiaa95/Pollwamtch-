import { useEffect, useMemo, useState, type ReactNode } from "react";
import { useI18n } from "../../lib/i18n";
import * as api from "../../lib/api";
import { supabase, SUPABASE_URL, SUPABASE_ANON_KEY } from "../../lib/supabase";
import {
  Badge, Btn, Card, ConfirmDialog, Empty, ErrorBox, Field, Loading,
  Modal, SkeletonTable, StatCard, Toasts, TopBar, compressImage, inputCls, statusTone, useLoad, useToasts,
  type Toast,
} from "../../shared/ui";
import PartyDetailsModal from "./PartyDetailsModal";
import MapPicker, { isValidLat, isValidLng } from "./MapPicker";
import StationsMapTab from "./StationsMapTab";

type Tab = "parties" | "users" | "stations" | "map" | "diagnostics";
type Push = (title: string, opts?: { body?: string; tone?: Toast["tone"] }) => void;

export default function SuperadminApp({ logout }: { logout: ReactNode }) {
  const { t } = useI18n();
  const { toasts, push, dismiss } = useToasts();
  const [tab, setTab] = useState<Tab>("parties");
  const tabs: { key: Tab; label: string }[] = [
    { key: "parties", label: t("parties") },
    { key: "users", label: t("users") },
    { key: "stations", label: t("stations") },
    { key: "map", label: "الخريطة" },
    { key: "diagnostics", label: "تشخيص" },
  ];
  return (
    <div className="min-h-screen">
      <TopBar title={`${t("app_title")} — ${t("superadmin")}`} right={logout} />
      <div className="mx-auto max-w-6xl p-4">
        <div className="mb-4 flex flex-wrap gap-2">
          {tabs.map((x) => (
            <button key={x.key} onClick={() => setTab(x.key)}
              className={`rounded-xl px-4 py-2 text-sm font-semibold transition ${tab === x.key ? "bg-teal-600 text-white" : "bg-slate-800 text-slate-300 hover:bg-slate-700"}`}>
              {x.label}
            </button>
          ))}
        </div>
        {tab === "parties" && <PartiesTab push={push} />}
        {tab === "users" && <UsersTab push={push} />}
        {tab === "stations" && <StationsTab push={push} />}
        {tab === "map" && <StationsMapTab />}
        {tab === "diagnostics" && <DiagnosticsTab />}
      </div>
      <Toasts toasts={toasts} dismiss={dismiss} />
    </div>
  );
}

// ---------------------------------------------------------------------------
// الأحزاب + الدومينات
// ---------------------------------------------------------------------------
function PartiesTab({ push }: { push: Push }) {
  const { t, lang } = useI18n();
  const parties = useLoad(api.listParties);
  const domains = useLoad(api.listDomains);
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [email, setEmail] = useState("");
  const [fullName, setFullName] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [selectedParty, setSelectedParty] = useState<api.PartyRow | null>(null);
  const [confirm, setConfirm] = useState<{ kind: "delete" | "toggle"; party: api.PartyRow } | null>(null);

  const run = async (fn: () => Promise<unknown>, okMsg: string) => {
    setBusy(true);
    try {
      await fn();
      push(okMsg, { tone: "success" });
      parties.reload();
      domains.reload();
    } catch (e) {
      push(lang === "ar" ? "فشلت العملية" : "Échec", { body: e instanceof Error ? e.message : String(e), tone: "error" });
    } finally { setBusy(false); }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <StatCard label={t("parties")} value={parties.data?.length ?? "…"} />
        <StatCard label={t("domains")} value={domains.data?.length ?? "…"} tone="blue" />
      </div>

      {parties.error && <ErrorBox message={parties.error} onRetry={parties.reload} />}

      <Card>
        <h3 className="mb-3 font-bold">{t("add_party")}</h3>
        <div className="grid gap-3 md:grid-cols-3">
          <Field label="اسم الحزب"><input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} /></Field>
          <Field label="Slug">
            <input dir="ltr" className={inputCls} value={slug} onChange={(e) => setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ""))} placeholder="parti-exemple" />
            <p className="mt-1 text-xs text-slate-500">بالإنجليزية فقط، مثل: parti-independance</p>
          </Field>
          <Field label="الاسم الكامل لرئيس الحزب">
            <input className={inputCls} value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="الاسم الكامل" />
          </Field>
          <Field label="شعار الحزب (اختياري)" hint="يُقلَّص تلقائياً — يظهر في صفحة رئيس الحزب والحسابات المرتبطة">
            <input type="file" accept="image/*" className={inputCls} onChange={(e) => {
              const f = e.target.files?.[0] ?? null;
              setLogoFile(f);
              if (logoPreview) URL.revokeObjectURL(logoPreview);
              setLogoPreview(f ? URL.createObjectURL(f) : null);
            }} />
          </Field>
          {logoPreview && <img src={logoPreview} alt="" className="h-14 w-14 self-end rounded-xl border border-slate-700 object-cover" />}
          <Field label="بريد رئيس الحزب">
            <input type="email" dir="ltr" className={inputCls} value={email} onChange={(e) => setEmail(e.target.value)} placeholder="president@example.com" />
          </Field>
          <Field label="كلمة سر رئيس الحزب">
            <input type="password" dir="ltr" className={inputCls} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="8 أحرف على الأقل" />
          </Field>
          <div className="flex items-end">
            <Btn
              disabled={!name.trim() || !email.trim() || !fullName.trim() || password.length < 8 || busy}
              onClick={() => run(async () => {
                const finalSlug = (slug.trim() || `party-${Date.now().toString().slice(-6)}`).toLowerCase();
                // فحص مسبق قبل استدعاء الدالة — رسالة واضحة بدل خطأ 409
                if (parties.data?.some((p) => p.slug === finalSlug)) {
                  throw new Error(`الـ Slug «${finalSlug}» مستخدم مسبقاً — احذف الحزب القديم أو اختر اسماً آخر مثل: ${finalSlug}-2026`);
                }
                if (parties.data?.some((p) => p.name_ar === name.trim())) {
                  throw new Error(`يوجد حزب بنفس الاسم «${name.trim()}» — اختر اسماً آخر`);
                }
                await api.createParty({ name_ar: name.trim(), slug: finalSlug, email: email.trim(), full_name: fullName.trim(), password });
                // رفع الشعار بعد إنشاء الحزب (نlocateه عبر slug)
                if (logoFile) {
                  const created = (await api.listParties()).find((p) => p.slug === finalSlug);
                  if (created) {
                    const blob = await compressImage(logoFile, 800, 0.85);
                    const url = await api.uploadPartyLogo(created.id, blob);
                    await api.setPartyLogo(created.id, url);
                  }
                }
                setName(""); setSlug(""); setEmail(""); setFullName(""); setPassword(""); setLogoFile(null); setLogoPreview(null);
              }, lang === "ar" ? "تم إنشاء الحزب بنجاح" : "Parti créé")}
            >{busy ? "…" : t("save")}</Btn>
          </div>
        </div>
      </Card>

      {parties.loading ? <SkeletonTable rows={4} /> : (parties.data?.length ?? 0) === 0 ? (
        <Empty label={lang === "ar" ? "لا توجد أحزاب بعد" : "Aucun parti"} />
      ) : parties.data!.map((p) => (
        <Card key={p.id}>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              {p.logo_path ? (
                <img src={p.logo_path} alt="" className="h-10 w-10 rounded-xl border border-slate-700 object-cover" />
              ) : (
                <div className="flex h-10 w-10 items-center justify-center rounded-xl font-bold text-white"
                  style={{ background: p.colors?.primary ?? "#0f766e" }}>
                  {p.name_ar.slice(0, 1)}
                </div>
              )}
              <button type="button" className="text-start" onClick={() => setSelectedParty(p)} title="عرض تفاصيل الحزب">
                <div className="font-bold transition hover:text-teal-400">{p.name_ar} {p.name_fr && <span className="text-sm text-slate-400">({p.name_fr})</span>}</div>
                <div className="text-xs text-slate-500" dir="ltr">{p.slug}</div>
              </button>
            </div>
            <div className="flex items-center gap-2">
              <Badge tone={statusTone(p.status)}>{p.status}</Badge>
              {p.status !== "active"
                ? <Btn variant="success" className="!px-3 !py-1 text-xs" disabled={busy} onClick={() => setConfirm({ kind: "toggle", party: p })}>تفعيل</Btn>
                : <Btn variant="warn" className="!px-3 !py-1 text-xs" disabled={busy} onClick={() => setConfirm({ kind: "toggle", party: p })}>تعطيل</Btn>}
              <Btn variant="ghost" className="!px-3 !py-1 text-xs text-red-400" disabled={busy} onClick={() => setConfirm({ kind: "delete", party: p })}>حذف الحساب</Btn>
            </div>
          </div>
        </Card>
      ))}

      {selectedParty && (
        <PartyDetailsModal party={selectedParty} onClose={() => setSelectedParty(null)} onChanged={() => { parties.reload(); domains.reload(); }} />
      )}

      <ConfirmDialog
        open={!!confirm}
        onClose={() => setConfirm(null)}
        danger={confirm?.kind === "delete"}
        busy={busy}
        title={confirm?.kind === "delete" ? "حذف الحزب" : "تغيير حالة الحزب"}
        message={confirm ? (confirm.kind === "delete"
          ? `حذف الحزب ${confirm.party.name_ar} وحساب رئيسه نهائياً؟ لا يمكن التراجع.`
          : `${confirm.party.status === "active" ? "تعطيل" : "تفعيل"} الحزب ${confirm.party.name_ar}؟`) : ""}
        confirmLabel={confirm?.kind === "delete" ? "حذف نهائي" : "تأكيد"}
        onConfirm={() => {
          const c = confirm;
          setConfirm(null);
          if (!c) return;
          if (c.kind === "delete") run(() => api.deleteParty(c.party.id), "تم حذف الحزب");
          else run(() => api.setPartyStatus(c.party.id, c.party.status === "active" ? "suspended" : "active"), "تم تحديث حالة الحزب");
        }}
      />
    </div>
  );
}

// ---------------------------------------------------------------------------
// المستخدمون + الأدوار
// ---------------------------------------------------------------------------
function UserAccountModal({ member, onClose, push }: { member: api.MemberRow; onClose: () => void; push: Push }) {
  const [info, setInfo] = useState<{ email?: string | null; created_at?: string; last_sign_in_at?: string | null } | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [newPass, setNewPass] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let alive = true;
    api.adminUserAction({ action: "info", user_id: member.user_id })
      .then((r) => { if (alive) r?.error ? setErr(r.error) : setInfo(r); })
      .catch((e) => { if (alive) setErr(e instanceof Error ? e.message : String(e)); });
    return () => { alive = false; };
  }, [member.user_id]);

  return (
    <Modal open onClose={onClose} title={`حساب المستخدم: ${member.full_name}`}>
      <div className="space-y-3">
        {err && <ErrorBox message={err} />}
        <div className="rounded-xl bg-slate-800/60 p-3 text-sm">
          <div className="flex justify-between"><span className="text-slate-400">البريد الإلكتروني</span><b dir="ltr">{info?.email ?? "جارٍ التحميل…"}</b></div>
          <div className="mt-1 flex justify-between"><span className="text-slate-400">أول دخول</span><span>{info?.created_at ? new Date(info.created_at).toLocaleString("ar") : "—"}</span></div>
          <div className="mt-1 flex justify-between"><span className="text-slate-400">آخر دخول</span><span>{info?.last_sign_in_at ? new Date(info.last_sign_in_at).toLocaleString("ar") : "لم يسجّل بعد"}</span></div>
        </div>
        <Field label="كلمة سر جديدة (8+)" hint="سيُعاد تعيينها فورًا ويُفصَل الجهاز الحالي للمستخدم">
          <input type="password" dir="ltr" className={inputCls} value={newPass} onChange={(e) => setNewPass(e.target.value)} placeholder="8 أحرف على الأقل" />
        </Field>
        <div className="flex justify-end gap-2">
          <Btn variant="ghost" onClick={onClose}>إغلاق</Btn>
          <Btn variant="warn" disabled={busy || newPass.trim().length < 8} onClick={async () => {
            setBusy(true); setErr(null);
            try {
              const r = await api.adminUserAction({ action: "reset_password", user_id: member.user_id, new_password: newPass.trim() });
              if (r?.error) throw new Error(r.error);
              push("تم إعادة تعيين كلمة السر بنجاح", { tone: "success" });
              setNewPass("");
            } catch (e) { setErr(e instanceof Error ? e.message : String(e)); }
            finally { setBusy(false); }
          }}>{busy ? "جارٍ التنفيذ…" : "إعادة تعيين كلمة السر"}</Btn>
        </div>
      </div>
    </Modal>
  );
}

function UsersTab({ push }: { push: Push }) {
  const { t, lang } = useI18n();
  const members = useLoad(api.listMembers);
  const roles = useLoad(api.listRoles);
  const parties = useLoad(api.listParties);
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [selectedMember, setSelectedMember] = useState<api.MemberRow | null>(null);

  const roleKey = useMemo(() => {
    const m = new Map((roles.data ?? []).map((r) => [r.id, r.key]));
    return (id: string) => m.get(id) ?? "—";
  }, [roles.data]);
  const partyName = useMemo(() => {
    const m = new Map((parties.data ?? []).map((p) => [p.id, p.name_ar]));
    return (id: string | null) => (id ? (m.get(id) ?? "—") : "—");
  }, [parties.data]);

  const rows = (members.data ?? []).filter((m) => m.full_name.includes(q) || roleKey(m.role_id).includes(q));
  const toggle = async (m: api.MemberRow) => {
    setBusy(true); setErr(null);
    try { await api.setMemberStatus(m.id, m.status === "active" ? "suspended" : "active"); members.reload(); }
    catch (e) { setErr(e instanceof Error ? e.message : String(e)); }
    finally { setBusy(false); }
  };

  return (
    <Card>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <h3 className="font-bold">{t("users")}</h3>
        <input className={`${inputCls} max-w-xs`} placeholder={t("search")} value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      {members.error && <ErrorBox message={members.error} onRetry={members.reload} />}
      {err && <ErrorBox message={err} />}
      {members.loading ? <SkeletonTable rows={5} /> : rows.length === 0 ? <Empty label={lang === "ar" ? "لا يوجد مستخدمون" : "Aucun utilisateur"} /> : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-800 text-start text-slate-400">
                <th className="p-2 text-start">{t("name")}</th>
                <th className="p-2 text-start">الدور</th>
                <th className="p-2 text-start">الحزب</th>
                <th className="p-2 text-start">{t("status")}</th>
                <th className="p-2 text-start">{t("actions")}</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((m) => (
                <tr key={m.id} className="cursor-pointer border-b border-slate-800/60 transition hover:bg-slate-800/40" onClick={() => setSelectedMember(m)}>
                  <td className="p-2 font-medium">{m.full_name}</td>
                  <td className="p-2"><Badge tone={roleKey(m.role_id) === "superadmin" ? "violet" : "blue"}>{roleKey(m.role_id)}</Badge></td>
                  <td className="p-2 text-slate-400">{partyName(m.party_id)}</td>
                  <td className="p-2"><Badge tone={statusTone(m.status)}>{m.status}</Badge></td>
                  <td className="p-2">
                    <Btn variant="ghost" className="!px-3 !py-1 text-xs" disabled={busy} onClick={() => toggle(m)}>
                      {m.status === "active" ? "تعطيل" : "تفعيل"}
                    </Btn>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {selectedMember && <UserAccountModal member={selectedMember} onClose={() => setSelectedMember(null)} push={push} />}
    </Card>
  );
}

// ---------------------------------------------------------------------------
// مكاتب الاقتراع (كل الأحزاب) + نموذج الإضافة/التعديل مع خريطة
// ---------------------------------------------------------------------------
function StationsTab({ push }: { push: Push }) {
  const { t, lang } = useI18n();
  const stations = useLoad(() => api.listStations(null));
  const parties = useLoad(api.listParties);
  const allIds = useMemo(() => (stations.data ?? []).map((s) => s.id), [stations.data]);
  const assignCounts = useLoad(() => api.countAssignmentsByStation(allIds), [allIds]);
  const [q, setQ] = useState("");
  const [editing, setEditing] = useState<api.StationRow | "new" | null>(null);
  const [form, setForm] = useState({
    party_ids: [] as string[], station_number: "", name_ar: "", city: "", region: "",
    status: "planned", lat: null as number | null, lng: null as number | null,
  });
  const toggleParty = (id: string) => setForm((f) => ({
    ...f,
    party_ids: f.party_ids.includes(id) ? f.party_ids.filter((x) => x !== id) : [...f.party_ids, id],
  }));
  const toggleAllParties = () => setForm((f) => ({
    ...f,
    party_ids: f.party_ids.length === (parties.data?.length ?? 0) ? [] : (parties.data ?? []).map((pp) => pp.id),
  }));
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [confirmDel, setConfirmDel] = useState<api.StationRow | null>(null);

  const coordsValid = isValidLat(form.lat) && isValidLng(form.lng);
  const partyName = (id: string) => parties.data?.find((p) => p.id === id)?.name_ar ?? "—";

  const openNew = () => {
    setForm({ party_ids: [], station_number: "", name_ar: "", city: "", region: "", status: "planned", lat: null, lng: null });
    setEditing("new"); setErr(null);
  };
  const openEdit = (s: api.StationRow) => {
    setForm({ party_ids: [s.party_id], station_number: s.station_number, name_ar: s.name_ar, city: s.city ?? "", region: s.region ?? "", status: s.status, lat: s.lat, lng: s.lng });
    setEditing(s); setErr(null);
  };

  const save = async () => {
    if (!coordsValid) {
      setErr(lang === "ar" ? "حدّد موقعاً صحيحاً على الخريطة قبل الحفظ (خط العرض -90..90، خط الطول -180..180)" : "Choisissez un emplacement valide");
      return;
    }
    setBusy(true); setErr(null);
    try {
      if (editing === "new") {
        // منع التكرار: نفس رقم المكتب + نفس المدينة + نفس الحزب = تخطٍّ
        const existing = new Set(
          (stations.data ?? [])
            .filter((st) => st.station_number === form.station_number.trim() && (st.city ?? "") === form.city.trim())
            .map((st) => st.party_id)
        );
        let created = 0, skipped = 0;
        for (const pid of form.party_ids) {
          if (existing.has(pid)) { skipped++; continue; }
          await api.createStation({
            party_id: pid, station_number: form.station_number, name_ar: form.name_ar,
            city: form.city, region: form.region, status: form.status, lat: form.lat!, lng: form.lng!,
          });
          created++;
        }
        if (created === 0) throw new Error("المكتب موجود مسبقاً لكل الأحزاب المختارة (نفس الرقم والمدينة)");
        push(`تم إنشاء ${created} مكتب` + (skipped > 0 ? ` — تخطّي ${skipped} مكرر لنفس الرقم والمدينة` : ""), { tone: "success" });
      } else if (editing) {
        await api.updateStation(editing.id, {
          station_number: form.station_number, name_ar: form.name_ar, city: form.city,
          region: form.region, status: form.status, lat: form.lat, lng: form.lng,
        });
      }
      push(lang === "ar" ? "تم حفظ المكتب بنجاح" : "Bureau enregistré", { tone: "success" });
      setEditing(null);
      stations.reload(); // تحديث فوري للقائمة والخريطة دون إعادة تحميل الصفحة
      assignCounts.reload();
    } catch (e) {
      setErr(e instanceof Error ? e.message : String(e));
    } finally { setBusy(false); }
  };

  const rows = (stations.data ?? []).filter((s) =>
    s.station_number.includes(q) || s.name_ar.includes(q) || (s.city ?? "").includes(q));

  return (
    <div className="space-y-4">
      {stations.error && <ErrorBox message={stations.error} onRetry={stations.reload} />}
      {err && <ErrorBox message={err} />}

      <Card>
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <h3 className="font-bold">{t("stations")} ({stations.data?.length ?? "…"})</h3>
          <div className="flex gap-2">
            <input className={`${inputCls} max-w-xs`} placeholder={t("search")} value={q} onChange={(e) => setQ(e.target.value)} />
            <Btn onClick={openNew}>+ {t("add_station")}</Btn>
          </div>
        </div>
        {stations.loading ? <SkeletonTable rows={5} /> : rows.length === 0 ? (
          <Empty label={lang === "ar" ? "لا توجد مكاتب" : "Aucun bureau"} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="p-2 text-start">{t("station_number")}</th>
                  <th className="p-2 text-start">{t("name")}</th>
                  <th className="p-2 text-start">الحزب</th>
                  <th className="p-2 text-start">{t("city")}</th>
                  <th className="p-2 text-start">الإحداثيات</th>
                  <th className="p-2 text-start">{t("status")}</th>
                  <th className="p-2 text-start">{t("actions")}</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((s) => (
                  <tr key={s.id} className="border-b border-slate-800/60">
                    <td className="p-2 font-mono">{s.station_number}</td>
                    <td className="p-2">{s.name_ar}</td>
                    <td className="p-2 text-slate-400">{partyName(s.party_id)}</td>
                    <td className="p-2">{s.city} — {s.region}</td>
                    <td className="p-2 text-xs text-slate-500" dir="ltr">
                      {isValidLat(s.lat) && isValidLng(s.lng) ? `${s.lat}, ${s.lng}` : "⚠ بلا موقع"}
                    </td>
                    <td className="p-2"><Badge tone={statusTone(s.status)}>{s.status}</Badge></td>
                    <td className="p-2">
                      <div className="flex gap-1">
                        <Btn variant="ghost" className="!px-3 !py-1 text-xs" onClick={() => openEdit(s)}>تعديل</Btn>
                        <Btn variant="danger" className="!px-3 !py-1 text-xs" disabled={busy} onClick={() => setConfirmDel(s)}>حذف</Btn>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {editing && (
        <Card>
          <h3 className="mb-3 font-bold">{editing === "new" ? t("add_station") : `تعديل ${editing.station_number}`}</h3>
          <div className="grid gap-3 md:grid-cols-3">
            {editing === "new" && (
              <Field label="الأحزاب (اختيار متعدد)" hint="يُنشأ المكتب لكل حزب محدد — لا يُنشأ مكتب مكرر لنفس الرقم والمدينة لنفس الحزب">
                <div className="flex flex-wrap items-center gap-2">
                  <Btn variant="ghost" className="!px-3 !py-1 text-xs" onClick={toggleAllParties}>
                    {form.party_ids.length === (parties.data?.length ?? 0) ? "إلغاء تحديد الكل" : "تحديد الكل"}
                  </Btn>
                  {(parties.data ?? []).map((p) => (
                    <label key={p.id} className={`flex cursor-pointer items-center gap-1.5 rounded-xl border px-3 py-1.5 text-xs transition ${form.party_ids.includes(p.id) ? "border-teal-500 bg-teal-900/40 text-teal-200" : "border-slate-700 bg-slate-800/60 text-slate-300 hover:border-slate-600"}`}>
                      <input type="checkbox" className="accent-teal-500" checked={form.party_ids.includes(p.id)} onChange={() => toggleParty(p.id)} />
                      {p.name_ar}
                    </label>
                  ))}
                </div>
              </Field>
            )}
            <Field label={t("station_number")}>
              <input className={inputCls} value={form.station_number} onChange={(e) => setForm({ ...form, station_number: e.target.value })} />
            </Field>
            <Field label={t("name")}>
              <input className={inputCls} value={form.name_ar} onChange={(e) => setForm({ ...form, name_ar: e.target.value })} />
            </Field>
            <Field label={t("city")}>
              <input className={inputCls} value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
            </Field>
            <Field label={t("region")}>
              <input className={inputCls} value={form.region} onChange={(e) => setForm({ ...form, region: e.target.value })} />
            </Field>
            <Field label={t("status")}>
              <select className={inputCls} value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                {["planned", "open", "counting", "closed", "report_received"].map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </Field>
          </div>

          <div className="mt-3">
            <MapPicker
              lat={form.lat} lng={form.lng}
              onPick={(la, ln) => setForm({ ...form, lat: la, lng: ln })}
              stations={stations.data ?? []}
              partyName={partyName}
              assignCounts={assignCounts.data ?? {}}
            />
            {!coordsValid && (
              <p className="mt-1 text-xs text-amber-400">
                ⚠ {lang === "ar"
                  ? "حدّد موقع المكتب بالنقر على الخريطة، أو بالبحث عن العنوان، أو بزر «استخدام موقعي الحالي» — لا يمكن الحفظ بدون إحداثيات صحيحة."
                  : "Choisissez l'emplacement sur la carte — enregistrement impossible sans coordonnées valides."}
              </p>
            )}
          </div>

          <div className="mt-3 flex gap-2">
            <Btn disabled={busy || !form.station_number.trim() || !form.name_ar.trim() || form.party_ids.length === 0 || !coordsValid} onClick={save}>
              {busy ? "جارٍ الحفظ…" : t("save")}
            </Btn>
            <Btn variant="ghost" onClick={() => setEditing(null)}>{t("cancel")}</Btn>
          </div>
        </Card>
      )}

      <ConfirmDialog
        open={!!confirmDel}
        onClose={() => setConfirmDel(null)}
        danger
        busy={busy}
        title="حذف المكتب"
        message={confirmDel ? `حذف مكتب ${confirmDel.name_ar} (${confirmDel.station_number}) نهائياً؟ لا يمكن التراجع.` : ""}
        confirmLabel="حذف"
        onConfirm={async () => {
          const s = confirmDel;
          setConfirmDel(null);
          if (!s) return;
          setBusy(true);
          try {
            await api.deleteStation(s.id);
            push(lang === "ar" ? "تم حذف المكتب" : "Bureau supprimé", { tone: "success" });
            stations.reload(); assignCounts.reload();
          } catch (e) {
            push(lang === "ar" ? "فشل الحذف" : "Échec", { body: e instanceof Error ? e.message : String(e), tone: "error" });
          } finally { setBusy(false); }
        }}
      />
    </div>
  );
}

// ---------------------------------------------------------------------------
// التشخيص (كما هو — لا يغيّر بيانات)
// ---------------------------------------------------------------------------
function DiagnosticsTab() {
  const [running, setRunning] = useState(false);
  const [results, setResults] = useState<{ name: string; ok: boolean; detail: string }[]>([]);
  const [manualLat, setManualLat] = useState(33.8);
  const [manualLng, setManualLng] = useState(-7.2);

  const probeFunction = async (fnName: string, body: Record<string, unknown>) => {
    const invokeUrl = `${SUPABASE_URL}/functions/v1/${fnName}`;
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const token = sessionData?.session?.access_token ?? "";
      let res: Response;
      try {
        res = await fetch(invokeUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": token ? `Bearer ${token}` : "",
            "apikey": SUPABASE_ANON_KEY,
          },
          body: JSON.stringify(body),
        });
      } catch (fetchErr) {
        return { ok: false, text:
          `الدالة: ${fnName}\nالرابط: ${invokeUrl}\nفشل fetch (غالباً CORS preflight أو الدالة غير منشورة 404): ${fetchErr instanceof Error ? fetchErr.message : String(fetchErr)}\nتلميح: نفّذ "supabase functions deploy ${fnName}" ثم أعد الفحص` };
      }
      const rawText = await res.text();
      let pretty = rawText;
      try { pretty = JSON.stringify(JSON.parse(rawText), null, 2); } catch { /* ليس JSON */ }
      const reached = res.ok || res.status === 400;
      const statusNote = res.status === 400
        ? "الدالة متاحة؛ رفضت بيانات الاختبار الناقصة كما هو متوقع"
        : "";
      return {
        ok: reached,
        text: `الدالة: ${fnName}\nالرابط: ${invokeUrl}\nHTTP: ${res.status} ${res.statusText}\n${statusNote ? statusNote + "\n" : ""}رد Supabase: ${pretty || "(جسم فارغ)"}`,
      };
    } catch (e) {
      return { ok: false, text: `الدالة: ${fnName}\nالرابط: ${invokeUrl}\nاستثناء: ${e instanceof Error ? e.message : String(e)}` };
    }
  };

  const runDiagnostics = async () => {
    setRunning(true); setResults([]);
    const out: { name: string; ok: boolean; detail: string }[] = [];
    const add = (name: string, ok: boolean, detail: string) => out.push({ name, ok, detail });
    try {
      const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
      add("جلسة Supabase", !sessionError && !!sessionData?.session?.access_token,
        sessionError?.message ?? (sessionData?.session ? "جلسة صالحة والتوكن موجود" : "لا توجد جلسة نشطة"));
      if (sessionData?.session) {
        for (const name of ["my_role_key", "my_member_id", "my_party_id", "is_superadmin"]) {
          const { data, error } = await supabase.rpc(name);
          add(`RPC ${name}`, !error, error?.message ?? `النتيجة: ${JSON.stringify(data)}`);
        }
        const r1 = await probeFunction("create-party-admin", {});
        add("Edge: create-party-admin", r1.ok, r1.text);
        const r2 = await probeFunction("delete-party-admin", {});
        add("Edge: delete-party-admin", r2.ok, r2.text);
        const r3 = await probeFunction("verify-domain", {});
        add("Edge: verify-domain", r3.ok, r3.text);
      }
      const { error: partiesError } = await supabase.from("parties").select("id").limit(1);
      add("قراءة جدول parties", !partiesError, partiesError?.message ?? "نجحت القراءة");
      const { error: stationsError } = await supabase.from("stations_view").select("id").limit(1);
      add("قراءة stations_view", !stationsError, stationsError?.message ?? "نجحت القراءة");
    } catch (e) {
      add("خطأ عام", false, e instanceof Error ? e.message : String(e));
    }
    setResults(out); setRunning(false);
  };

  return <div className="space-y-4">
    <Card>
      <h3 className="mb-2 font-bold">تشخيص الاتصال والصلاحيات</h3>
      <p className="mb-3 text-sm text-slate-500">يرسل بيانات ناقصة إلى الدوال فقط لقياس الوصول والصلاحيات — لا يغيّر أي بيانات.</p>
      <Btn disabled={running} onClick={runDiagnostics}>{running ? "جارٍ الفحص…" : "بدء التشخيص"}</Btn>
      {results.length > 0 && <div className="mt-4 space-y-2">{results.map((r, i) => <div key={i} className={`rounded-xl p-3 text-sm ${r.ok ? "bg-green-950/40 text-green-200" : "bg-red-950/40 text-red-200"}`}><div className="font-bold">{r.ok ? "✓" : "✕"} {r.name}</div><div className="mt-1 whitespace-pre-wrap break-words font-mono text-xs">{r.detail}</div></div>)}</div>}
    </Card>
    <Card>
      <h3 className="mb-2 font-bold">اختبار إحداثيات الخريطة</h3>
      <p className="text-sm text-slate-500">إذا لم تستجب الخريطة، يمكنك استعمال هذه الإحداثيات مؤقتًا في نموذج المكتب. القيم الافتراضية تقريبية للمغرب.</p>
      <div className="mt-3 grid gap-3 md:grid-cols-2"><Field label="Latitude"><input className={inputCls} type="number" step="0.000001" value={manualLat} onChange={e => setManualLat(Number(e.target.value))} /></Field><Field label="Longitude"><input className={inputCls} type="number" step="0.000001" value={manualLng} onChange={e => setManualLng(Number(e.target.value))} /></Field></div>
      <div className="mt-3 rounded-xl bg-slate-800 p-3 text-sm" dir="ltr">{manualLat}, {manualLng}</div>
      <p className="mt-2 text-xs text-slate-500">التشخيص يسجل المشكلة فقط؛ لا يغيّر بيانات قاعدة البيانات.</p>
    </Card>
  </div>;
}

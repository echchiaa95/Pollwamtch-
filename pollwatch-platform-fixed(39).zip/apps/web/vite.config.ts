import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  // base نسبي: يعمل على GitHub Pages تحت أي مسار مشروع
  base: "./",
  plugins: [react()],
  server: { port: 5173 },
});

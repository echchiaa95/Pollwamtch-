#!/usr/bin/env bash
# فحص أمان الواجهة: نتحقق من غياب الأسرار والروابط الخاطئة،
# ونتحقق صراحةً من وجود استثناء Supabase داخل Service Worker.
set -euo pipefail
cd "$(dirname "$0")/.."

FAIL=0

check_absent() {
  local desc="$1"; shift
  if grep -rn "$@" >/dev/null 2>&1; then
    echo "✗ FAIL (يجب أن يكون غائباً): $desc"
    grep -rn "$@" | head -5
    FAIL=1
  else
    echo "✓ OK (غائب كما يجب): $desc"
  fi
}

check_present() {
  local desc="$1"; shift
  if grep -rn "$@" >/dev/null 2>&1; then
    echo "✓ OK (موجود كما يجب): $desc"
  else
    echo "✗ FAIL (يجب أن يكون موجوداً): $desc"
    FAIL=1
  fi
}

echo "=== فحص أسرار الواجهة ==="
check_absent "service_role JWT داخل apps/web/src"   "service_role" apps/web/src --include="*.ts" --include="*.tsx"
check_absent "SERVICE_ROLE_KEY داخل apps/web/src"   "SERVICE_ROLE_KEY" apps/web/src --include="*.ts" --include="*.tsx"
check_absent "VITE_SERVICE_ROLE_KEY في ملفات المشروع"   "VITE_SERVICE_ROLE_KEY" . --exclude-dir=node_modules --exclude-dir=.git --exclude-dir=dist --exclude-dir=scripts --exclude=.env.example
check_absent "الرابط الخاطئ /functions/v1/SERVICE_ROLE_KEY"   "functions/v1/SERVICE_ROLE_KEY" . --exclude-dir=node_modules --exclude-dir=.git --exclude-dir=scripts --exclude=.env.example
check_absent "مفتاح JWT سري داخل src"   "eyJhbGciOi" apps/web/src --include="*.ts" --include="*.tsx"

echo "=== فحص الحزمة المبنية dist ==="
if [ -d apps/web/dist ]; then
  check_absent "SERVICE_ROLE_KEY في dist" "SERVICE_ROLE_KEY" apps/web/dist
  check_absent "الرابط الخاطئ في dist" "functions/v1/SERVICE_ROLE_KEY" apps/web/dist
  check_absent "JWT سري في dist" "eyJhbGciOi" apps/web/dist
else
  echo "— dist غير موجود (شغّل npm run build أولاً)"
fi

echo "=== فحص Service Worker ==="
# هذا فحص وجود الاستبعاد، وليس فحص غيابه.
check_present "استبعاد supabase.co من الكاش"   'hostname.endsWith("supabase.co")' apps/web/public/sw.js

echo
if [ "$FAIL" -eq 0 ]; then
  echo "═══ كل الفحوصات ناجحة ═══"
else
  echo "═══ فشلت فحوصات — راجع الأعلى ═══"
  exit 1
fi

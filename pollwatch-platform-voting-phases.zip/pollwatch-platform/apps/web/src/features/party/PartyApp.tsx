import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
// إشعارات لحظية: في الإنتاج تُستبدل بـ Supabase Realtime (channels على reports/count_sessions)
import L from "leaflet";
import { useI18n } from "../../lib/i18n";
import { store } from "../../lib/store";
import type { Station } from "../../lib/types";
import { Badge, Btn, Card, Field, StatCard, TopBar, Toasts, inputCls, statusTone, timeAgo, useDB, type Toast } from "../../shared/ui";
import StatsTab from "./StatsTab";

type Tab = "dashboard" | "map" | "observers" | "assistants" | "reports" | "stats";

// حالة المكتب على الخريطة: أخضر=مراقب متصل، أصفر=تحديث قديم، أحمر=غير متصل، أزرق=تقرير مستلم
function markerColor(station: Station, lastPingMin: number | null, hasReport: boolean): string {
  if (hasReport || station.status === "report_received") return "#2563eb";
  if (lastPingMin === null) return "#dc2626";
  if (lastPingMin <= 5) return "#16a34a";
  if (lastPingMin <= 30) return "#d97706";
  return "#dc2626";
}

export default function PartyApp({ logout }: { logout: ReactNode }) {
  const { t, lang } = useI18n();
  const db = useDB();
  const [tab, setTab] = useState<Tab>("dashboard");
  const party = db.parties[0];

  // إشعارات لحظية عند وصول تقرير جديد أو محضر فرز (تحاكي Realtime في الوضع التجريبي)
  const [toasts, setToasts] = useState<Toast[]>([]);
  const prevCounts = useRef<{ reports: number; submitted: number } | null>(null);
  useEffect(() => {
    const submitted = db.sessions.filter((s) => s.status === "submitted").length;
    const cur = { reports: db.reports.length, submitted };
    if (prevCounts.current) {
      const fresh: Toast[] = [];
      if (cur.reports > prevCounts.current.reports) {
        fresh.push({
          id: Date.now(),
          title: lang === "ar" ? "تقرير ميداني جديد" : "Nouveau rapport de terrain",
          body: db.reports[0]?.author_name, tone: "info",
        });
      }
      if (cur.submitted > prevCounts.current.submitted) {
        fresh.push({
          id: Date.now() + 1,
          title: lang === "ar" ? "محضر فرز بانتظار المراجعة" : "PV en attente de révision",
          tone: "warn",
        });
      }
      if (fresh.length) {
        setToasts((ts) => [...ts, ...fresh]);
        fresh.forEach((nt) =>
          setTimeout(() => setToasts((ts) => ts.filter((x) => x.id !== nt.id)), 6000)
        );
      }
    }
    prevCounts.current = cur;
  }, [db, lang]);
  const tabs: { key: Tab; label: string }[] = [
    { key: "dashboard", label: t("dashboard") },
    { key: "map", label: t("map") },
    { key: "observers", label: t("observers") },
    { key: "assistants", label: t("assistants") },
    { key: "reports", label: t("reports") },
    { key: "stats", label: t("stats") },
  ];
  return (
    <div className="min-h-screen">
      <TopBar
        title={party ? `${party.name_ar} — ${t("dashboard")}` : t("dashboard")}
        right={<>
          <Badge tone="green">● Live</Badge>
          {logout}
        </>}
      />
      <div className="mx-auto max-w-6xl p-4">
        <div className="mb-4 flex flex-wrap gap-2">
          {tabs.map((x) => (
            <button
              key={x.key}
              onClick={() => setTab(x.key)}
              className={`rounded-xl px-4 py-2 text-sm font-semibold transition ${
                tab === x.key ? "text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300"
              }`}
              style={tab === x.key ? { background: party?.colors.primary } : undefined}
            >
              {x.label}
            </button>
          ))}
        </div>
        {tab === "dashboard" && <DashboardTab goMap={() => setTab("map")} />}
        {tab === "map" && <MapTab />}
        {tab === "observers" && <ObserversTab />}
        {tab === "assistants" && <AssistantsTab />}
        {tab === "reports" && <ReportsTab />}
        {tab === "stats" && <StatsTab />}
      </div>
      <Toasts toasts={toasts} dismiss={(id) => setToasts((ts) => ts.filter((x) => x.id !== id))} />
    </div>
  );
}

function useKpis() {
  const db = useDB();
  return useMemo(() => {
    const stations = db.stations;
    const assigned = new Set(db.assignments.map((a) => a.station_id)).size;
    const pings = new Map(db.pings.map((p) => [p.observer_id, p]));
    const connected = db.observers.filter((o) => {
      const p = pings.get(o.id);
      return p && Date.now() - new Date(p.recorded_at).getTime() < 5 * 60000;
    }).length;
    const sessions = db.sessions;
    const counting = new Set(sessions.filter((s) => s.status === "open").map((s) => s.station_id)).size;
    const supportVotes = sessions.reduce((acc, s) => acc + Object.values(s.totals).reduce((a, b) => a + b, 0), 0);
    const reportsReceived = db.reports.length;
    const reportsReviewed = db.reports.filter((r) => r.status === "reviewed").length;
    return {
      total: stations.length,
      assignedPct: stations.length ? Math.round((assigned / stations.length) * 100) : 0,
      observers: db.observers.length,
      connected,
      disconnected: db.observers.length - connected,
      counting,
      reportsReceived,
      reportsReviewed,
      supportVotes,
      assistantsActive: db.assistants.filter((a) => a.status === "active").length,
    };
  }, [db]);
}

function DashboardTab({ goMap }: { goMap: () => void }) {
  const { t, lang } = useI18n();
  const k = useKpis();
  const db = useDB();
  const pendingSessions = db.sessions.filter((s) => s.status === "submitted");
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <StatCard label={t("total_stations")} value={k.total} hint={`${t("coverage")}: ${k.assignedPct}%`} />
        <StatCard label={t("observers_count")} value={k.observers} hint={`${t("connected")}: ${k.connected} / ${t("disconnected")}: ${k.disconnected}`} tone="blue" />
        <StatCard label={t("counting_started")} value={k.counting} tone="amber" />
        <StatCard label={t("reports_received")} value={k.reportsReceived} hint={`${t("reports_reviewed")}: ${k.reportsReviewed}`} tone="violet" />
        <StatCard label={t("support_votes")} value={k.supportVotes} hint={t("official_vs_estimate")} tone="green" />
        <StatCard label={t("assistants_active")} value={k.assistantsActive} />
        <StatCard label={t("coverage")} value={`${k.assignedPct}%`} tone={k.assignedPct >= 80 ? "green" : "amber"} />
        <button onClick={goMap} className="text-start">
          <Card className="h-full transition hover:ring-2 hover:ring-brand">
            <div className="text-sm text-slate-500">{t("map")}</div>
            <div className="mt-1 text-xl font-bold text-brand">🗺 {lang === "ar" ? "فتح الخريطة الحية" : "Ouvrir la carte en direct"}</div>
          </Card>
        </button>
      </div>

      {pendingSessions.length > 0 && (
        <Card>
          <h3 className="mb-3 font-bold">{lang === "ar" ? "محاضر بانتظار المراجعة" : "PV en attente de révision"}</h3>
          <div className="space-y-2">
            {pendingSessions.map((s) => {
              const st = db.stations.find((x) => x.id === s.station_id);
              const obs = db.observers.find((x) => x.id === s.observer_id);
              return (
                <div key={s.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-slate-50 px-3 py-2 text-sm dark:bg-slate-800/60">
                  <span>{st?.name_ar} — {obs?.full_name} ({Object.values(s.totals).reduce((a, b) => a + b, 0)} {lang === "ar" ? "صوت" : "voix"})</span>
                  <div className="flex gap-2">
                    <Btn variant="success" className="!px-3 !py-1 text-xs" onClick={() => store.reviewSession(s.id, "validated")}>{t("validate")}</Btn>
                    <Btn variant="warn" className="!px-3 !py-1 text-xs" onClick={() => store.reviewSession(s.id, "returned")}>{t("reject")}</Btn>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      )}

      <Card>
        <h3 className="mb-3 font-bold">{lang === "ar" ? "آخر التقارير الميدانية" : "Derniers rapports de terrain"}</h3>
        <div className="space-y-2">
          {db.reports.slice(0, 5).map((r) => (
            <div key={r.id} className="rounded-xl bg-slate-50 px-3 py-2 text-sm dark:bg-slate-800/60">
              <div className="flex items-center justify-between">
                <span className="font-medium">{r.author_name}</span>
                <Badge tone={statusTone(r.status)}>{r.status}</Badge>
              </div>
              <p className="mt-1 text-slate-500">{r.body}</p>
              <div className="mt-1 text-xs text-slate-400">{timeAgo(r.submitted_at, lang)}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function MapTab() {
  const { t, lang } = useI18n();
  const db = useDB();
  const ref = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const layerRef = useRef<L.LayerGroup | null>(null);
  const [q, setQ] = useState("");
  const [selected, setSelected] = useState<Station | null>(null);
  const [zoom, setZoom] = useState(8); // لإعادة الحساب عند تغيّر مستوى التقريب (تجميع)

  const filtered = db.stations.filter((s) =>
    s.station_number.includes(q) || s.name_ar.includes(q) || (s.city ?? "").includes(q) || (s.region ?? "").includes(q)
  );

  useEffect(() => {
    if (!ref.current || mapRef.current) return;
    const map = L.map(ref.current).setView([33.8, -7.2], 8);
    L.tileLayer("https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png", {
      attribution: "© OpenStreetMap © CARTO",
      maxZoom: 19,
    }).addTo(map);
    layerRef.current = L.layerGroup().addTo(map);
    map.on("zoomend", () => setZoom(map.getZoom()));
    mapRef.current = map;
    return () => { map.remove(); mapRef.current = null; };
  }, []);

  useEffect(() => {
    const layer = layerRef.current;
    const map = mapRef.current;
    if (!layer || !map) return;
    layer.clearLayers();

    const stationMeta = (s: Station) => {
      const assign = db.assignments.find((a) => a.station_id === s.id);
      const obs = assign ? db.observers.find((o) => o.id === assign.observer_id) : undefined;
      const ping = obs ? db.pings.find((p) => p.observer_id === obs.id) : undefined;
      const lastMin = ping ? (Date.now() - new Date(ping.recorded_at).getTime()) / 60000 : null;
      const hasReport = db.reports.some((r) => r.station_id === s.id && r.status !== "draft");
      return { obs, lastMin, hasReport, color: markerColor(s, lastMin, hasReport) };
    };

    const addStationMarker = (s: Station) => {
      const { obs, lastMin, hasReport, color } = stationMeta(s);
      const icon = L.divIcon({
        className: "",
        html: `<div style="background:${color};width:18px;height:18px;border-radius:50%;border:3px solid white;box-shadow:0 1px 4px rgba(0,0,0,.4)"></div>`,
        iconSize: [18, 18],
        iconAnchor: [9, 9],
      });
      L.marker([s.lat, s.lng], { icon })
        .bindPopup(
          `<b>${s.name_ar}</b><br>${s.station_number} — ${s.city ?? ""}<br>` +
          `${lang === "ar" ? "المراقب" : "Observateur"}: ${obs?.full_name ?? "—"}<br>` +
          (lastMin !== null
            ? `${lang === "ar" ? "آخر تحديث" : "Dernière MAJ"}: ${Math.round(lastMin)} min`
            : (lang === "ar" ? "غير متصل" : "Hors ligne")) +
          (hasReport ? `<br>📄 ${lang === "ar" ? "تقرير مستلم" : "Rapport reçu"}` : "")
        )
        .on("click", () => setSelected(s))
        .addTo(layer);
    };

    const bounds: L.LatLngTuple[] = filtered.map((s) => [s.lat, s.lng]);

    // تجميع عند التصغير: خلايا شاشة 60px؛ النقر على عنقود يقرّب
    const CLUSTER_ZOOM = 11;
    if (filtered.length > 1 && zoom <= CLUSTER_ZOOM) {
      const cell = 60;
      const clusters = new Map<string, { x: number; y: number; items: Station[] }>();
      filtered.forEach((s) => {
        const pt = map.latLngToContainerPoint([s.lat, s.lng]);
        const key = `${Math.floor(pt.x / cell)},${Math.floor(pt.y / cell)}`;
        const c = clusters.get(key);
        if (c) { c.items.push(s); c.x = (c.x * (c.items.length - 1) + pt.x) / c.items.length; c.y = (c.y * (c.items.length - 1) + pt.y) / c.items.length; }
        else clusters.set(key, { x: pt.x, y: pt.y, items: [s] });
      });
      clusters.forEach((c) => {
        if (c.items.length === 1) { addStationMarker(c.items[0]); return; }
        const latlng = map.containerPointToLatLng([c.x, c.y]);
        const size = 30 + Math.min(20, c.items.length * 2);
        const icon = L.divIcon({
          className: "",
          html: `<div style="width:${size}px;height:${size}px;border-radius:50%;background:rgba(15,118,110,.9);border:3px solid white;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;box-shadow:0 2px 6px rgba(0,0,0,.35)">${c.items.length}</div>`,
          iconSize: [size, size],
          iconAnchor: [size / 2, size / 2],
        });
        L.marker(latlng, { icon })
          .on("click", () => map.setView(latlng, Math.min(zoom + 2, CLUSTER_ZOOM + 1)))
          .addTo(layer);
      });
    } else {
      filtered.forEach(addStationMarker);
    }

    if (bounds.length) map.fitBounds(bounds, { padding: [40, 40] });
  }, [filtered, db, lang, zoom]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <input className={`${inputCls} max-w-sm`} placeholder={`${t("search")} (${t("station_number")} / ${t("city")} / ${t("region")})`} value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="flex flex-wrap gap-3 text-xs text-slate-500">
          <span className="flex items-center gap-1"><i className="h-3 w-3 rounded-full bg-green-600 inline-block" /> {lang === "ar" ? "مراقب متصل" : "Observateur connecté"}</span>
          <span className="flex items-center gap-1"><i className="h-3 w-3 rounded-full bg-amber-600 inline-block" /> {lang === "ar" ? "تحديث قديم" : "MAJ ancienne"}</span>
          <span className="flex items-center gap-1"><i className="h-3 w-3 rounded-full bg-red-600 inline-block" /> {lang === "ar" ? "غير متصل" : "Hors ligne"}</span>
          <span className="flex items-center gap-1"><i className="h-3 w-3 rounded-full bg-blue-600 inline-block" /> {lang === "ar" ? "تقرير مستلم" : "Rapport reçu"}</span>
        </div>
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2 h-[480px] overflow-hidden p-0">
          <div ref={ref} className="h-full w-full" />
        </Card>
        <Card>
          <h3 className="mb-3 font-bold">{t("stations")} ({filtered.length})</h3>
          <div className="max-h-[420px] space-y-2 overflow-y-auto pe-1">
            {filtered.map((s) => {
              const assign = db.assignments.find((a) => a.station_id === s.id);
              const obs = assign ? db.observers.find((o) => o.id === assign.observer_id) : undefined;
              const ping = obs ? db.pings.find((p) => p.observer_id === obs.id) : undefined;
              return (
                <button key={s.id} onClick={() => setSelected(s)}
                  className={`w-full rounded-xl border p-3 text-start text-sm transition ${selected?.id === s.id ? "border-brand bg-brand/5" : "border-slate-200 hover:border-brand dark:border-slate-700"}`}>
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">{s.name_ar}</span>
                    <Badge tone={statusTone(s.status)}>{s.status}</Badge>
                  </div>
                  <div className="mt-1 text-xs text-slate-400">{s.station_number} — {s.city}</div>
                  <div className="mt-1 text-xs">
                    {obs ? `${t("observer")}: ${obs.full_name}` : (lang === "ar" ? "بدون مراقب" : "Sans observateur")}
                    {ping && <> · {t("last_sync")}: {timeAgo(ping.recorded_at, lang)}</>}
                  </div>
                </button>
              );
            })}
          </div>
        </Card>
      </div>
      {selected && <StationLiveDetails station={selected} />}
    </div>
  );
}

function StationLiveDetails({ station }: { station: Station }) {
  const { lang } = useI18n();
  const db = useDB();
  const assign = db.assignments.find((a) => a.station_id === station.id);
  const obs = assign ? db.observers.find((o) => o.id === assign.observer_id) : undefined;
  const session = db.sessions.find((s) => s.station_id === station.id);
  const ping = obs ? db.pings.find((p) => p.observer_id === obs.id) : undefined;
  const totalPeople = (session?.male_count ?? 0) + (session?.female_count ?? 0);
  return <Card>
    <div className="mb-3 flex items-center justify-between"><h3 className="font-bold">{lang === "ar" ? "المعطيات اللحظية للمكتب" : "Données en direct du bureau"}</h3><Badge tone="green">Live</Badge></div>
    <div className="grid gap-3 md:grid-cols-2 text-sm">
      <div><b>{station.station_number} — {station.name_ar}</b><div className="text-slate-500">{station.city} — {station.region}</div></div>
      <div><b>{lang === "ar" ? "المراقب" : "Observateur"}:</b> {obs?.full_name ?? "—"}<div className="text-slate-500">{ping ? `${lang === "ar" ? "آخر موقع" : "Dernière position"}: ${timeAgo(ping.recorded_at, lang)}` : "—"}</div></div>
    </div>
    {session && <div className="mt-3 grid grid-cols-3 gap-2 text-center"><div className="rounded-xl bg-slate-100 p-3 dark:bg-slate-800"><div className="text-xs">ذكر</div><b className="text-xl">{session.male_count}</b></div><div className="rounded-xl bg-slate-100 p-3 dark:bg-slate-800"><div className="text-xs">أنثى</div><b className="text-xl">{session.female_count}</b></div><div className="rounded-xl bg-brand/10 p-3"><div className="text-xs">المجموع</div><b className="text-xl text-brand">{totalPeople}</b></div></div>}
  </Card>;
}

function ObserversTab() {
  const { t, lang } = useI18n();
  const db = useDB();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [q, setQ] = useState("");
  const rows = db.observers.filter((o) => o.full_name.includes(q) || (o.phone ?? "").includes(q));
  return (
    <div className="space-y-4">
      <Card>
        <h3 className="mb-3 font-bold">{t("add_observer")}</h3>
        <div className="grid gap-3 md:grid-cols-3">
          <Field label={t("name")}><input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} /></Field>
          <Field label={lang === "ar" ? "الهاتف" : "Téléphone"}><input className={inputCls} value={phone} onChange={(e) => setPhone(e.target.value)} /></Field>
          <div className="flex items-end">
            <Btn disabled={!name} onClick={() => { store.addObserver(name, phone); setName(""); setPhone(""); }}>{t("save")}</Btn>
          </div>
        </div>
      </Card>
      <Card>
        <div className="mb-3"><input className={`${inputCls} max-w-xs`} placeholder={t("search")} value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <div className="space-y-2">
          {rows.map((o) => {
            const assign = db.assignments.find((a) => a.observer_id === o.id);
            const st = assign ? db.stations.find((s) => s.id === assign.station_id) : undefined;
            const ping = db.pings.find((p) => p.observer_id === o.id);
            return (
              <div key={o.id} className="flex flex-wrap items-center gap-3 rounded-xl border border-slate-200 p-3 text-sm dark:border-slate-700">
                <div className="flex-1">
                  <div className="font-semibold">{o.full_name}</div>
                  <div className="text-xs text-slate-400">{o.phone}</div>
                </div>
                <div className="w-48">
                  <select className={inputCls} value={st?.id ?? ""} onChange={(e) => e.target.value && store.assignObserver(o.id, e.target.value)}>
                    <option value="">{lang === "ar" ? "— تعيين لمكتب —" : "— Affecter à un bureau —"}</option>
                    {db.stations.map((s) => <option key={s.id} value={s.id}>{s.station_number} — {s.name_ar}</option>)}
                  </select>
                </div>
                {ping
                  ? <Badge tone={Date.now() - new Date(ping.recorded_at).getTime() < 5 * 60000 ? "green" : "amber"}>{t("last_sync")}: {timeAgo(ping.recorded_at, lang)}</Badge>
                  : <Badge tone="red">{t("not_connected_hint")}</Badge>}
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}

function AssistantsTab() {
  const { t, lang } = useI18n();
  const db = useDB();
  const [full_name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [city, setCity] = useState("");
  const [region, setRegion] = useState("");
  const [q, setQ] = useState("");
  const rows = db.assistants.filter((a) => a.full_name.includes(q) || (a.city ?? "").includes(q));
  return (
    <div className="space-y-4">
      <p className="rounded-xl bg-amber-50 px-3 py-2 text-xs text-amber-700 dark:bg-amber-900/30 dark:text-amber-300">
        {lang === "ar"
          ? "تُستخدم هذه البيانات للتنسيق الإداري فقط. يُمنع تسجيل أو استنتاج نية التصويت، ولا تُستخدم لاستهداف الناخبين (Law 09-08 / CNDP)."
          : "Données utilisées pour la coordination administrative uniquement. Interdit d'enregistrer ou déduire l'intention de vote (Loi 09-08 / CNDP)."}
      </p>
      <Card>
        <h3 className="mb-3 font-bold">{t("add_assistant")}</h3>
        <div className="grid gap-3 md:grid-cols-5">
          <Field label={t("name")}><input className={inputCls} value={full_name} onChange={(e) => setName(e.target.value)} /></Field>
          <Field label={lang === "ar" ? "الهاتف" : "Téléphone"}><input className={inputCls} value={phone} onChange={(e) => setPhone(e.target.value)} /></Field>
          <Field label={t("city")}><input className={inputCls} value={city} onChange={(e) => setCity(e.target.value)} /></Field>
          <Field label={t("region")}><input className={inputCls} value={region} onChange={(e) => setRegion(e.target.value)} /></Field>
          <div className="flex items-end">
            <Btn disabled={!full_name} onClick={() => { store.addAssistant({ full_name, phone, city, region, status: "active" }); setName(""); setPhone(""); setCity(""); setRegion(""); }}>{t("save")}</Btn>
          </div>
        </div>
      </Card>
      <Card>
        <div className="mb-3"><input className={`${inputCls} max-w-xs`} placeholder={t("search")} value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-slate-400 dark:border-slate-800">
                <th className="p-2 text-start">{t("name")}</th>
                <th className="p-2 text-start">{t("city")}</th>
                <th className="p-2 text-start">{t("region")}</th>
                <th className="p-2 text-start">{t("status")}</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((a) => (
                <tr key={a.id} className="border-b border-slate-100 dark:border-slate-800/60">
                  <td className="p-2 font-medium">{a.full_name}<div className="text-xs text-slate-400">{a.phone}</div></td>
                  <td className="p-2">{a.city}</td>
                  <td className="p-2 text-slate-500">{a.region}</td>
                  <td className="p-2"><Badge tone={statusTone(a.status)}>{a.status}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function ReportsTab() {
  const { t, lang } = useI18n();
  const db = useDB();
  return (
    <div className="space-y-4">
      <Card>
        <h3 className="mb-3 font-bold">{t("reports")} ({db.reports.length})</h3>
        <div className="space-y-2">
          {db.reports.map((r) => {
            const st = db.stations.find((s) => s.id === r.station_id);
            return (
              <div key={r.id} className="rounded-xl border border-slate-200 p-3 text-sm dark:border-slate-700">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <span className="font-semibold">{r.author_name}</span>
                    <span className="mx-2 text-slate-300">·</span>
                    <span className="text-slate-500">{st?.name_ar ?? "—"}</span>
                    <span className="mx-2 text-slate-300">·</span>
                    <Badge tone="blue">{r.kind}</Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge tone={statusTone(r.status)}>{r.status}</Badge>
                    {r.status === "submitted" && (
                      <>
                        <Btn variant="success" className="!px-3 !py-1 text-xs" onClick={() => store.reviewReport(r.id, "reviewed")}>{t("validate")}</Btn>
                        <Btn variant="warn" className="!px-3 !py-1 text-xs" onClick={() => store.reviewReport(r.id, "flagged")}>{t("reject")}</Btn>
                      </>
                    )}
                  </div>
                </div>
                <p className="mt-2 text-slate-600 dark:text-slate-300">{r.body}</p>
                <div className="mt-1 text-xs text-slate-400">{timeAgo(r.submitted_at, lang)}</div>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}

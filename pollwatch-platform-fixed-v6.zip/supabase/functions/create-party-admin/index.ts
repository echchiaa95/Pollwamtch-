import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, "Content-Type": "application/json" },
  });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const token = authHeader.replace(/^Bearer\s+/i, "").trim();
    if (!token) return json({ error: "يجب تسجيل الدخول أولاً" }, 401);

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? Deno.env.get("SERVICE_ROLE_KEY");
    if (!supabaseUrl || !anonKey || !serviceKey) return json({ error: "إعدادات Supabase السرية ناقصة" }, 500);

    // التحقق من صاحب الجلسة باستعمال JWT المرسل من الواجهة.
    const authClient = createClient(supabaseUrl, anonKey);
    const { data: userData, error: userError } = await authClient.auth.getUser(token);
    if (userError || !userData.user) return json({ error: "جلسة الدخول غير صالحة" }, 401);

    // استعمال service role لقراءة صلاحية المدير بدون الوقوع في RLS recursion.
    const admin = createClient(supabaseUrl, serviceKey);
    const { data: member, error: memberError } = await admin
      .from("party_members")
      .select("id, role_id, status, roles!inner(key)")
      .eq("user_id", userData.user.id)
      .eq("status", "active")
      .eq("roles.key", "superadmin")
      .limit(1)
      .maybeSingle();

    if (memberError) return json({ error: memberError.message }, 500);
    if (!member) return json({ error: "ليس لديك صلاحية المدير المركزي" }, 403);

    const body = await req.json();
    const name_ar = String(body.name_ar ?? "").trim();
    const slug = String(body.slug ?? "").trim().toLowerCase();
    const email = String(body.email ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");
    if (!name_ar || !slug || !email || password.length < 8) {
      return json({ error: "اسم الحزب وSlug والبريد وكلمة السر (8 أحرف على الأقل) مطلوبة" }, 400);
    }
    if (!/^[a-z0-9-]+$/.test(slug)) return json({ error: "Slug يجب أن يحتوي على أحرف إنجليزية وأرقام وشرطة فقط" }, 400);

    const { data: role, error: roleLookupError } = await admin
      .from("roles").select("id").eq("key", "party_admin").single();
    if (roleLookupError) return json({ error: roleLookupError.message }, 500);

    const { data: party, error: partyError } = await admin
      .from("parties").insert({ name_ar, slug, status: "pending" }).select("id").single();
    if (partyError) return json({ error: partyError.message }, 400);

    const { error: domainError } = await admin.from("party_domains").insert({
      party_id: party.id, domain: `www.${slug}.ma`, is_primary: true, wildcard: false,
      verification_token: crypto.randomUUID(), ssl_status: "pending",
    });
    if (domainError) {
      await admin.from("parties").delete().eq("id", party.id);
      return json({ error: domainError.message }, 400);
    }

    const { data: created, error: createUserError } = await admin.auth.admin.createUser({
      email, password, email_confirm: true,
      user_metadata: { full_name: name_ar, role: "party_admin", party_id: party.id },
    });
    if (createUserError || !created.user) {
      await admin.from("party_domains").delete().eq("party_id", party.id);
      await admin.from("parties").delete().eq("id", party.id);
      return json({ error: createUserError?.message ?? "تعذر إنشاء المستخدم" }, 400);
    }

    const { error: insertMemberError } = await admin.from("party_members").insert({
      party_id: party.id, user_id: created.user.id, role_id: role.id,
      full_name: name_ar, status: "active",
    });
    if (insertMemberError) {
      await admin.auth.admin.deleteUser(created.user.id);
      await admin.from("party_domains").delete().eq("party_id", party.id);
      await admin.from("parties").delete().eq("id", party.id);
      return json({ error: insertMemberError.message }, 400);
    }

    return json({ ok: true, party_id: party.id, user_id: created.user.id });
  } catch (e) {
    return json({ error: e instanceof Error ? e.message : String(e) }, 500);
  }
});

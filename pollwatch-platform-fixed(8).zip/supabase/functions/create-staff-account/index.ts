// فتح حساب دخول لمراقب/مساعد — يتطلب صلاحية superadmin أو party_admin لنفس الحزب
import { createClient } from "jsr:@supabase/supabase-js@2";

const json = (body: Record<string, unknown>, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204 });
  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const { party_id, role, record_id, full_name, email, password } = await req.json();
    if (!party_id || !role || !record_id || !full_name?.trim() || !email?.trim() || !password || password.length < 8) {
      return json({ error: "بيانات ناقصة (party_id, role, record_id, full_name, email, password≥8)" }, 400);
    }
    if (role !== "observer" && role !== "assistant") return json({ error: "role غير صالح" }, 400);

    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const userClient = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });

    // صلاحية المنفِّذ: superadmin أو party_admin لنفس الحزب
    const { data: me, error: meErr } = await userClient.auth.getUser();
    if (meErr || !me?.user) return json({ error: "غير مصرّح" }, 401);
    const { data: isAdmin } = await userClient.rpc("is_superadmin");
    if (!isAdmin) {
      const { data: rk } = await userClient.rpc("my_role_key");
      const { data: pid } = await userClient.rpc("my_party_id");
      if (rk !== "party_admin" || pid !== party_id) return json({ error: "صلاحيات غير كافية (party_admin لنفس الحزب فقط)" }, 403);
    }

    // السجل يجب أن يكون موجوداً وينتمي للحزب وليس له حساب بعد
    const table = role === "observer" ? "observers" : "assistants";
    const { data: rec, error: recErr } = await admin.from(table).select("id, party_id, user_id").eq("id", record_id).single();
    if (recErr || !rec) return json({ error: "السجل غير موجود" }, 404);
    if (rec.party_id !== party_id) return json({ error: "السجل لا ينتمي لهذا الحزب" }, 403);
    if (rec.user_id) return json({ error: "لهذا السجل حساب مفتوح مسبقاً" }, 409);

    // إنشاء مستخدم المصادقة
    const { data: created, error: uErr } = await admin.auth.admin.createUser({
      email: email.trim().toLowerCase(), password, email_confirm: true,
      user_metadata: { role, party_id, full_name: full_name.trim() },
    });
    if (uErr || !created.user) {
      return json({ error: uErr?.message?.includes("already") ? "البريد مسجّل مسبقاً" : `فشل إنشاء المستخدم: ${uErr?.message}` }, 400);
    }
    const userId = created.user.id;

    // ربط العضوية بالحزب والدور
    const { data: roleRow, error: roleErr } = await admin.from("roles").select("id").eq("key", role).single();
    if (roleErr || !roleRow) { await admin.auth.admin.deleteUser(userId); return json({ error: "الدور غير موجود في جدول roles" }, 500); }
    const { error: mErr } = await admin.from("party_members").insert({
      user_id: userId, party_id, role_id: roleRow.id, full_name: full_name.trim(), status: "active",
    });
    if (mErr) { await admin.auth.admin.deleteUser(userId); return json({ error: `فشل إنشاء العضوية: ${mErr.message}` }, 400); }

    // ربط الحساب بالسجل
    const { error: linkErr } = await admin.from(table).update({ user_id: userId }).eq("id", record_id);
    if (linkErr) {
      await admin.from("party_members").delete().eq("user_id", userId);
      await admin.auth.admin.deleteUser(userId);
      return json({ error: `فشل ربط الحساب: ${linkErr.message}` }, 400);
    }

    return json({ success: true, ok: true, data: { user_id: userId } });
  } catch (e) {
    return json({ error: e instanceof Error ? e.message : String(e) }, 500);
  }
});

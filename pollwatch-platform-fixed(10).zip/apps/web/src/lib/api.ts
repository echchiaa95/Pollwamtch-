// ============================================================================
// طبقة البيانات الإنتاجية — كل عملية أساسية تمر عبر Supabase (select/insert/
// update/delete/RPC). لا localStorage ولا mock هنا.
// الأسماء مطابقة لـ schema.sql حرفياً (تم التحقق منها سطراً سطراً).
// ============================================================================
import { supabase } from "./supabase";

// أسماء Edge Functions ثابتة ومطابقة تماماً لمجلدات supabase/functions/.
// لا تُقرأ أسماء الدوال من أي متغير بيئة — إطلاقاً. لا مفاتيح Supabase كأسماء دوال.
export const EDGE_FUNCTIONS = {
  createParty: "create-party-admin",
  deleteParty: "delete-party-admin",
  verifyDomain: "verify-domain",
  resolveTenant: "resolve-tenant",
  submitCount: "submit-count",
} as const;

// ---------- أنواع محلية للقراءة (من الجداول/ال views) ----------
export interface PartyRow {
  id: string; name_ar: string; name_fr: string | null; slug: string;
  status: string; colors: { primary: string; secondary: string };
  logo_path: string | null; profile: Record<string, unknown>;
  created_at: string; updated_at: string;
}
export interface DomainRow {
  id: string; party_id: string; domain: string; is_primary: boolean;
  wildcard: boolean; verification_token: string; verified_at: string | null; ssl_status: string;
}
export interface RoleRow { id: string; key: string; label_ar: string }
export interface MemberRow {
  id: string; party_id: string | null; user_id: string; role_id: string;
  full_name: string; phone: string | null; status: string;
}
export interface ObserverRow { id: string; party_id: string; full_name: string; phone: string | null; status: string; user_id: string | null }
export interface AssistantRow {
  id: string; party_id: string; full_name: string; phone: string | null;
  city: string | null; region: string | null; status: string; admin_notes: string | null;
  user_id: string | null; national_id_path: string | null;
}
export interface StationRow {
  id: string; party_id: string; station_number: string; name_ar: string;
  city: string | null; region: string | null; status: string;
  lat: number | null; lng: number | null; created_at: string;
}
export interface AssignmentRow {
  id: string; observer_id: string; polling_station_id: string; election_year_id: string;
  assigned_at: string;
}
export interface LocationRow {
  observer_id: string; lat: number; lng: number; recorded_at: string; expires_at: string;
}
export interface SessionRow {
  id: string; party_id: string; observer_id: string; polling_station_id: string;
  started_at: string; ended_at: string | null; status: string;
  totals: Record<string, number>;
  phase: string; male_count: number; female_count: number;
  voting_started_at: string | null; voting_ended_at: string | null;
  counting_started_at: string | null; counting_ended_at: string | null;
  updated_at: string;
}
export interface ReportRow {
  id: string; party_id: string; author_type: string; observer_id: string | null;
  polling_station_id: string | null; kind: string; body: string; status: string;
  submitted_at: string;
}
export interface ElectionYearRow { id: string; year: number; label_ar: string; is_active: boolean }

function err(e: unknown): Error {
  const anyE = e as { message?: string };
  return new Error(anyE?.message ?? "خطأ غير متوقع / Erreur inattendue");
}

// ============================================================================
// الأحزاب والدومينات (Superadmin)
// ============================================================================
export async function getParty(id: string): Promise<PartyRow | null> {
  const { data, error } = await supabase.from("parties").select("*").eq("id", id).maybeSingle();
  if (error) throw err(error);
  return (data as PartyRow | null) ?? null;
}
export async function listParties(): Promise<PartyRow[]> {
  const { data, error } = await supabase.from("parties").select("*").order("created_at");
  if (error) throw err(error);
  return data as PartyRow[];
}
// ============================================================================
// استدعاء Edge Functions — تقرير أخطاء كامل (اسم الدالة + HTTP status + نص الرد)
// ============================================================================
type EdgeResponse = { success?: boolean; ok?: boolean; error?: string; [k: string]: unknown };

async function describeInvokeError(fnName: string, e: unknown): Promise<Error> {
  const anyE = e as {
    message?: string;
    context?: Response & { body?: { error?: string } | string };
  };
  const status = anyE?.context?.status;
  let bodyText = "";

  // Supabase FunctionsHttpError exposes the raw Response in context.
  // Read a clone so the original response remains available to the caller.
  try {
    const response = anyE?.context;
    if (response && typeof response.clone === "function") {
      const raw = await response.clone().text();
      if (raw.trim()) {
        try {
          const parsed = JSON.parse(raw) as { error?: unknown; message?: unknown };
          bodyText = String(parsed?.error ?? parsed?.message ?? raw);
        } catch {
          bodyText = raw;
        }
      }
    } else if (response?.body) {
      bodyText = typeof response.body === "string"
        ? response.body
        : JSON.stringify(response.body);
    }
  } catch {
    // Keep the original error message if the response body cannot be read.
  }

  const parts = [
    `الدالة: ${fnName}`,
    status != null ? `HTTP ${status}` : null,
    bodyText ? `الرد: ${bodyText}` : null,
    anyE?.message,
  ].filter(Boolean);
  return new Error(parts.join(" — ") || "تعذر الاتصال بالدالة");
}

// ترويسات صريحة لكل استدعاء Edge Function: Authorization بتوكن جلسة المستخدم الحالية.
// (supabase-js يضيفها تلقائياً أيضاً، لكن التصريح هنا يلبي متطلبات التدقيق ويمنع أي التباس.)
async function edgeHeaders(): Promise<Record<string, string>> {
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  if (!token) throw new Error("لا توجد جلسة نشطة — سجّل الدخول أولاً");
  return { Authorization: `Bearer ${token}` };
}

function assertEdgeOk(fnName: string, data: unknown): EdgeResponse {
  const d = data as EdgeResponse | null;
  if (d && (d.success === false || d.error)) throw new Error(`${fnName}: ${String(d.error)}`);
  if (!d || !(d.success === true || d.ok === true)) {
    throw new Error(`${fnName}: استجابة غير صالحة من الدالة`);
  }
  return d;
}

export async function createParty(input: { name_ar: string; name_fr?: string; slug: string; email: string; password: string; full_name?: string }) {
  const fn = EDGE_FUNCTIONS.createParty; // "create-party-admin" — مطابق لمجلد supabase/functions/create-party-admin
  const { data, error } = await supabase.functions.invoke(fn, {
    body: {
      // الحقول الرسمية المطلوبة
      name: input.name_ar,
      slug: input.slug,
      president_email: input.email,
      president_password: input.password,
      // الاسم الكامل مطلوب من النسخة المنشورة من Edge Function
      full_name: input.full_name?.trim() || input.name_ar.trim(),
      // توافق خلفي مع الأسماء القديمة التي تقبلها الدالة أيضاً
      name_ar: input.name_ar,
      party_name: input.name_ar,
      name_fr: input.name_fr ?? null,
      email: input.email,
      password: input.password,
    },
    headers: await edgeHeaders(),
  });
  if (error) throw await describeInvokeError(fn, error);
  return assertEdgeOk(fn, data);
}

export async function deleteParty(id: string) {
  const fn = EDGE_FUNCTIONS.deleteParty; // "delete-party-admin" — مطابق لمجلد supabase/functions/delete-party-admin
  if (!id?.trim()) throw new Error("معرّف الحزب (party_id) مطلوب");
  const { data, error } = await supabase.functions.invoke(fn, {
    body: { party_id: id },
    headers: await edgeHeaders(),
  });
  if (error) throw await describeInvokeError(fn, error);
  return assertEdgeOk(fn, data); // قد يحوي data.partial=true — الواجهة تعرض الحالة بصدق
}

export async function setPartyStatus(id: string, status: string) {
  const { error } = await supabase.from("parties").update({ status }).eq("id", id);
  if (error) throw err(error);
}
export async function listDomains(): Promise<DomainRow[]> {
  const { data, error } = await supabase.from("party_domains").select("*").order("created_at");
  if (error) throw err(error);
  return data as DomainRow[];
}
export async function verifyDomain(domainId: string) {
  // حارس قبل الإرسال: لا طلب بلا domain_id صالح
  if (!domainId?.trim()) throw new Error("معرّف الدومين (domain_id) مطلوب");
  const { data, error } = await supabase.functions.invoke("verify-domain", {
    body: { domain_id: domainId.trim() },
    headers: await edgeHeaders(),
  });
  if (error) throw await describeInvokeError("verify-domain", error);
  return data as { success?: boolean; verified?: boolean; error?: string; hint?: string };
}

// ============================================================================
// الدومينات حسب الحزب + ربط دومين جديد
// (سياسات RLS على party_domains: الكتابة لـ superadmin فقط — لا تضعفها الواجهة)
// ============================================================================
export async function listDomainsByParty(partyId: string): Promise<DomainRow[]> {
  const { data, error } = await supabase.from("party_domains").select("*")
    .eq("party_id", partyId).order("created_at");
  if (error) throw err(error);
  return data as DomainRow[];
}

/** ربط دومين بحزب — يولّد verification_token محلياً (لا حاجة لأي مفتاح سري) */
export async function linkDomain(partyId: string, domain: string): Promise<{ id: string; verification_token: string }> {
  const clean = domain.trim().toLowerCase();
  if (!clean) throw new Error("الدومين فارغ");
  const { data, error } = await supabase.from("party_domains")
    .insert({
      party_id: partyId,
      domain: clean,
      verification_token: crypto.randomUUID(),
      is_primary: false,
      wildcard: false,
    })
    .select("id, verification_token")
    .single();
  if (error) throw err(error);
  return data as { id: string; verification_token: string };
}

/** عدد المراقبين المعيّنين لكل مكتب (استعلام واحد — تسمح RLS لـ superadmin/party_admin) */
export async function countAssignmentsByStation(stationIds: string[]): Promise<Record<string, number>> {
  if (!stationIds.length) return {};
  const { data, error } = await supabase.from("observer_assignments")
    .select("polling_station_id")
    .in("polling_station_id", stationIds);
  if (error) throw err(error);
  const m: Record<string, number> = {};
  (data as { polling_station_id: string }[]).forEach((r) => {
    m[r.polling_station_id] = (m[r.polling_station_id] ?? 0) + 1;
  });
  return m;
}

// ============================================================================
// المستخدمون والأدوار (Superadmin)
// ============================================================================
export async function listRoles(): Promise<RoleRow[]> {
  const { data, error } = await supabase.from("roles").select("id, key, label_ar");
  if (error) throw err(error);
  return data as RoleRow[];
}
export async function listMembers(): Promise<MemberRow[]> {
  const { data, error } = await supabase.from("party_members").select("*").order("created_at");
  if (error) throw err(error);
  return data as MemberRow[];
}
export async function setMemberStatus(id: string, status: string) {
  const { error } = await supabase.from("party_members").update({ status }).eq("id", id);
  if (error) throw err(error);
}

// ============================================================================
// مكاتب الاقتراع (party_admin / superadmin) — عبر stations_view
// ============================================================================
export async function listStations(partyId?: string | null): Promise<StationRow[]> {
  let q = supabase.from("stations_view").select("*").order("station_number");
  if (partyId) q = q.eq("party_id", partyId);
  const { data, error } = await q;
  if (error) throw err(error);
  return data as StationRow[];
}
export async function createStation(input: {
  party_id: string; station_number: string; name_ar: string;
  city?: string; region?: string; status?: string; lat?: number; lng?: number;
}) {
  const { data, error } = await supabase
    .from("polling_stations")
    .insert({
      party_id: input.party_id,
      station_number: input.station_number,
      name_ar: input.name_ar,
      city: input.city ?? null,
      region: input.region ?? null,
      status: input.status ?? "planned",
    })
    .select("id")
    .single();
  if (error) throw err(error);
  const id = (data as { id: string }).id;
  if (input.lat != null && input.lng != null) {
    const { error: lErr } = await supabase.rpc("set_station_location", {
      p_station: id, p_lat: input.lat, p_lng: input.lng,
    });
    if (lErr) throw err(lErr);
  }
  return id;
}
export async function updateStation(id: string, fields: {
  station_number?: string; name_ar?: string; city?: string; region?: string; status?: string;
  lat?: number | null; lng?: number | null;
}) {
  const { lat, lng, ...rest } = fields;
  const hasText = Object.values(rest).some((v) => v !== undefined);
  if (hasText) {
    const { error } = await supabase.from("polling_stations").update(rest).eq("id", id);
    if (error) throw err(error);
  }
  if (lat != null && lng != null) {
    const { error } = await supabase.rpc("set_station_location", { p_station: id, p_lat: lat, p_lng: lng });
    if (error) throw err(error);
  }
}
export async function deleteStation(id: string) {
  const { error } = await supabase.from("polling_stations").delete().eq("id", id);
  if (error) throw err(error);
}

// ============================================================================
// المراقبون والتعيينات
// ============================================================================
export async function listObservers(partyId: string): Promise<ObserverRow[]> {
  const { data, error } = await supabase.from("observers").select("*").eq("party_id", partyId).order("full_name");
  if (error) throw err(error);
  return data as ObserverRow[];
}
export async function createObserver(partyId: string, full_name: string, phone?: string): Promise<string> {
  const { data, error } = await supabase.from("observers").insert({ party_id: partyId, full_name, phone: phone ?? null }).select("id").single();
  if (error) throw err(error);
  return (data as { id: string }).id;
}
export async function listAssignments(partyId: string): Promise<AssignmentRow[]> {
  const { data, error } = await supabase.from("observer_assignments").select("*").eq("party_id", partyId);
  if (error) throw err(error);
  return data as AssignmentRow[];
}
export async function getActiveElectionYear(): Promise<ElectionYearRow | null> {
  const { data, error } = await supabase.from("election_years").select("*").eq("is_active", true).limit(1).maybeSingle();
  if (error) throw err(error);
  return (data as ElectionYearRow | null) ?? null;
}
/** تعيين مراقب لمكتب: upsert على unique(observer_id, election_year_id) */
export async function assignObserver(partyId: string, observerId: string, stationId: string, electionYearId: string) {
  const { error } = await supabase.from("observer_assignments").upsert(
    { party_id: partyId, observer_id: observerId, polling_station_id: stationId, election_year_id: electionYearId },
    { onConflict: "observer_id,election_year_id" }
  );
  if (error) throw err(error);
}
export async function unassignObserver(observerId: string, electionYearId: string) {
  const { error } = await supabase.from("observer_assignments")
    .delete()
    .eq("observer_id", observerId)
    .eq("election_year_id", electionYearId);
  if (error) throw err(error);
}

// ============================================================================
// المساعدون
// ============================================================================
export async function listAssistants(partyId: string): Promise<AssistantRow[]> {
  const { data, error } = await supabase.from("assistants").select("*").eq("party_id", partyId).order("created_at");
  if (error) throw err(error);
  return data as AssistantRow[];
}
export async function createAssistant(partyId: string, a: { full_name: string; phone?: string; city?: string; region?: string; admin_notes?: string }): Promise<string> {
  const { data, error } = await supabase.from("assistants").insert({
    party_id: partyId, full_name: a.full_name, phone: a.phone ?? null,
    city: a.city ?? null, region: a.region ?? null, admin_notes: a.admin_notes ?? null,
  }).select("id").single();
  if (error) throw err(error);
  return (data as { id: string }).id;
}
export async function setAssistantStatus(id: string, status: string) {
  const { error } = await supabase.from("assistants").update({ status }).eq("id", id);
  if (error) throw err(error);
}

// ============================================================================
// جلسات التصويت (المراقب) — المراحل والعدادات
// ============================================================================
export async function getMySession(observerId: string): Promise<SessionRow | null> {
  const { data, error } = await supabase
    .from("count_sessions")
    .select("*")
    .eq("observer_id", observerId)
    .in("status", ["open", "submitted"])
    .order("started_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (error) throw err(error);
  return (data as SessionRow | null) ?? null;
}
export async function listPartySessions(partyId: string): Promise<SessionRow[]> {
  const { data, error } = await supabase
    .from("count_sessions").select("*").eq("party_id", partyId)
    .order("started_at", { ascending: false }).limit(500);
  if (error) throw err(error);
  return data as SessionRow[];
}
/** بدء التصويت: إنشاء الجلسة (RLS: مراقب نفسه فقط) */
export async function startVoting(input: {
  partyId: string; observerId: string; stationId: string; electionYearId: string | null;
}) {
  const { data, error } = await supabase.from("count_sessions").insert({
    party_id: input.partyId,
    observer_id: input.observerId,
    polling_station_id: input.stationId,
    election_year_id: input.electionYearId,
    status: "open",
    phase: "voting",
    voting_started_at: new Date().toISOString(),
  }).select("id").single();
  if (error) throw err(error);
  return (data as { id: string }).id;
}
/** إنهاء التصويت = الانتقال لمرحلة الفرز */
export async function endVoting(sessionId: string) {
  const { error } = await supabase.from("count_sessions").update({
    phase: "counting",
    voting_ended_at: new Date().toISOString(),
    counting_started_at: new Date().toISOString(),
  }).eq("id", sessionId);
  if (error) throw err(error);
}
/** بدء الفرز صراحة (إن لم يبدأ تلقائياً) */
export async function startCounting(sessionId: string) {
  const { error } = await supabase.from("count_sessions").update({
    phase: "counting",
    counting_started_at: new Date().toISOString(),
  }).eq("id", sessionId);
  if (error) throw err(error);
}
/** إنهاء الفرز + إرسال المحضر */
export async function endCounting(sessionId: string) {
  const { error } = await supabase.from("count_sessions").update({
    phase: "done",
    counting_ended_at: new Date().toISOString(),
    ended_at: new Date().toISOString(),
    status: "submitted",
    submitted_at: new Date().toISOString(),
  }).eq("id", sessionId);
  if (error) throw err(error);
}
export async function reviewSession(sessionId: string, status: "validated" | "returned") {
  const { error } = await supabase.from("count_sessions").update({ status }).eq("id", sessionId);
  if (error) throw err(error);
}
/** عداد ذري عبر RPC (يفرض ملكية الجلسة ومرحلة التصويت داخل قاعدة البيانات) */
export async function incrementCounter(sessionId: string, which: "male" | "female") {
  const { error } = await supabase.rpc("increment_counter", { p_session: sessionId, p_which: which });
  if (error) throw err(error);
}

// ============================================================================
// إدخالات الأصوات (idempotent عبر client_id + trigger يحدّث totals)
// ============================================================================
export async function addVote(sessionId: string, candidateCode: string, clientId: string) {
  const { error } = await supabase.from("vote_entries").insert({
    session_id: sessionId, candidate_code: candidateCode, action: "add", client_id: clientId,
  });
  if (error && (error as { code?: string }).code !== "23505") throw err(error); // تجاهل التكرار
}
export async function revertVote(sessionId: string) {
  // آخر إدخال 'add' ثم سجل revert (لا حذف أبداً — سجل تدقيق كامل)
  const { data, error } = await supabase.from("vote_entries")
    .select("candidate_code")
    .eq("session_id", sessionId)
    .eq("action", "add")
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (error) throw err(error);
  if (!data) return;
  const { error: iErr } = await supabase.from("vote_entries").insert({
    session_id: sessionId,
    candidate_code: (data as { candidate_code: string }).candidate_code,
    action: "revert",
    client_id: crypto.randomUUID(),
  });
  if (iErr) throw err(iErr);
}

// ============================================================================
// مواقع المراقبين (بموافقة سارية — تفرضها RLS على الإدراج)
// ============================================================================
export async function sendLocation(input: {
  partyId: string; observerId: string; sessionId: string | null; lat: number; lng: number;
}) {
  const { error } = await supabase.rpc("insert_observer_location", {
    p_observer: input.observerId,
    p_session: input.sessionId,
    p_party: input.partyId,
    p_lat: input.lat,
    p_lng: input.lng,
    p_expires: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(),
  });
  if (error) throw err(error);
}
export async function grantLocationConsent(partyId: string | null, userId: string, observerId: string) {
  const { error } = await supabase.from("consent_records").insert({
    party_id: partyId, user_id: userId, subject_type: "observer", subject_id: observerId,
    consent_type: "location_tracking", granted: true, consent_text_version: "v1",
  });
  // تجاهل تكرار الموافقة
  if (error && (error as { code?: string }).code !== "23505") throw err(error);
}
export async function listLatestLocations(partyId: string): Promise<LocationRow[]> {
  const { data, error } = await supabase.from("observer_locations_latest").select("*").eq("party_id", partyId);
  if (error) throw err(error);
  return data as LocationRow[];
}

// ============================================================================
// التقارير ومحاضر الفرز
// ============================================================================
export async function listReports(partyId: string): Promise<ReportRow[]> {
  const { data, error } = await supabase.from("reports")
    .select("id, party_id, author_type, observer_id, polling_station_id, kind, body, status, submitted_at")
    .eq("party_id", partyId)
    .order("submitted_at", { ascending: false })
    .limit(200);
  if (error) throw err(error);
  return data as ReportRow[];
}
export async function createReport(input: {
  partyId: string; observerId: string; stationId: string; kind: string; body: string;
}) {
  const { error } = await supabase.from("reports").insert({
    party_id: input.partyId,
    author_type: "observer",
    author_id: input.observerId,
    observer_id: input.observerId,
    polling_station_id: input.stationId,
    kind: input.kind,
    body: input.body,
    status: "submitted",
  });
  if (error) throw err(error);
}
export async function reviewReport(id: string, status: "reviewed" | "flagged") {
  const { error } = await supabase.from("reports").update({ status }).eq("id", id);
  if (error) throw err(error);
}
/** أسماء المراقبين/المكاتب لأغراض العرض (استعلامات منفصلة — لا embedding افتراضي) */
export async function observerNameMap(partyId: string): Promise<Record<string, string>> {
  const rows = await listObservers(partyId);
  return Object.fromEntries(rows.map((o) => [o.id, o.full_name]));
}
export async function stationMap(partyId: string): Promise<Record<string, StationRow>> {
  const rows = await listStations(partyId);
  return Object.fromEntries(rows.map((s) => [s.id, s]));
}

// ============================================================================
// فتح حساب دخول لمراقب/مساعد — Edge Function create-staff-account
// (superadmin أو party_admin لنفس الحزب فقط — يتحقق من ذلك داخل الدالة)
// ============================================================================
export async function createStaffAccount(input: {
  party_id: string; role: "observer" | "assistant"; record_id: string;
  full_name: string; email: string; password: string;
}): Promise<{ success?: boolean; error?: string; user_id?: string }> {
  if (!input.email?.trim() || !input.password || input.password.length < 8) {
    throw new Error("البريد وكلمة السر (8 أحرف على الأقل) مطلوبان");
  }
  const { data, error } = await supabase.functions.invoke("create-staff-account", {
    body: { ...input, email: input.email.trim().toLowerCase() },
    headers: await edgeHeaders(),
  });
  if (error) throw await describeInvokeError("create-staff-account", error);
  return data as { success?: boolean; error?: string; user_id?: string };
}

// رفع صورة البطاقة الوطنية — bucket خاص id-documents
// المسار يبدأ بمعرف الحزب: {party_id}/{assistant_id}.jpg — تفرضه سياسات storage (RLS)
export async function uploadIdDocument(path: string, blob: Blob): Promise<void> {
  const { error } = await supabase.storage.from("id-documents").upload(path, blob, { upsert: true, contentType: "image/jpeg" });
  if (error) throw err(error);
}

export async function setAssistantIdDocument(id: string, path: string): Promise<void> {
  const { error } = await supabase.from("assistants").update({ national_id_path: path }).eq("id", id);
  if (error) throw err(error);
}

export async function getIdDocumentUrl(path: string, expiresIn = 3600): Promise<string> {
  const { data, error } = await supabase.storage.from("id-documents").createSignedUrl(path, expiresIn);
  if (error) throw err(error);
  return data.signedUrl;
}
